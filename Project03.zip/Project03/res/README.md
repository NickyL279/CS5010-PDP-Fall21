# CS5010-Project3: Dungeon Model

Create a dungeon, a network of tunnels and caves that are interconnected so that player can explore
the entire world by traveling from cave to cave through the tunnels that connect them.

## Overview:

The world for our game consists of a dungeon, a network of tunnels and caves that are interconnected
so that player can explore the entire world by traveling from cave to cave through the tunnels that
connect them.

## Features:

- The dungeon is represented on a 2-D grid.
- There is a path from every cave in the dungeon to every other cave in the dungeon.
- Each dungeon is constructed with a degree of interconnectivity. We define an interconnectivity = 0
  when there is exactly one path from every cave in the dungeon to every other cave in the dungeon.
  Increasing the degree of interconnectivity increases the number of paths between caves.
- Not all dungeons "wrap" from one side to the other (as defined above). There are wrapped and
  non-wrapped dungeons. Both wrapping and non-wrapping dungeons to be created with different degrees
  of interconnectivity.
- One cave is randomly selected as the start and one cave is randomly selected to be the end. The
  path between the start and the end locations should be at least of length 5.
- Treasure to be added to a specified percentage of caves. For example, the client should be able to
  ask the model to add treasure to 20% of the caves and the model should add a random treasure to at
  least 20% of the caves in the dungeon. A cave can have more than one treasure. A player to pick up
  treasure that is located in their same location.
- Provided a description of the player that, at a minimum, includes a description of what treasure
  the player has collected. Provided a description of the player's location that at the minimum
  includes a description of treasure in the room and the possible moves (north, east, south, west)
  that the player can make from their current location.
- A player to enter the dungeon at the start and move from their current location.

## How to:

The program will follow the steps of the above function and ask the user to enter multiple
instructions to move around the dungeon.

To run this program, please run the driver file and put in option following the instruction.

## How to Use the Program:

This program is interactive, open the Project03.jar in your IDE, and run it. Then follow the
instruction to interact.

## Description of Examples:

This program navigates a player move around a dungeon. Please refer to the features section for a
step-by-step guide on how the program works.

Run 1 -- run1-nonwrap.txt:

1. initialize the dungeon.
2. move player around and pick up treasures.
3. move to the end point.

Run 2 -- run2-wrap.txt:

1. initialize the dungeon.
2. move player around and pick up treasures.
3. move to the end point.

Run 3 -- run3-allRooms.txt:

1. initialize the dungeon.
2. move player around and pick up treasures.
3. move to all rooms in the dungeon.
4. move to the end point.

## Design/Model Changes:

I made some changes to the original UML, but changed a few classes.

I reorganized the methods in the class, so the methods can get information from the class. I added
many getters to the abstract dungeon and play classes, so I can get this information in the driver.

I also removed two enums to the design, so I don't have those redundancies.

I also added a function to print the dungeon as a map contains cells and direction.

## Assumptions:

I assume that the player starts at a certain point which is more than 5 cells away from the end
point.

I assume that there are two types of dungeons.

## Limitations:

This program only support three types of treasures and four directions. And the program requires
user to navigate in the dungeon.

## Citations:

CSDN, https://www.csdn.net/. 
Stack Overflow, https://stackoverflow.com/.
Geeksforgeeks, https://www.geeksforgeeks.org/. Google, https://www.google.com/.