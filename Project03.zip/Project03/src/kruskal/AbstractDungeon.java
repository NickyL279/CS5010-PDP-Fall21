package kruskal;

import dungeon.Cell;
import dungeon.Cells;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * An abstract class that contains all the code that is shared by all types of dungeons.
 * It supports the getters in the dungeon and also generate, generate the dungeon graph.
 *
 */
abstract class AbstractDungeon implements KruskalDungeon {
  private final int rows;
  private final int cols;
  private final int interconnectivity;
  private final List<int[]> allPath;
  private final Cells[][] cellMap;
  private final List<int[]> treasure;

  /**
   * Protected constructor for use by subclasses. Constructs a dungeon with given rows
   * and column and interconnectivity.
   *
   * @param rows              row number of this dungeon
   * @param cols              column number of this dungeon
   * @param interconnectivity interconnectivity number of this dungeon
   * @throws IllegalArgumentException If the dungeon's size is invalid
   */
  public AbstractDungeon(int rows, int cols, int interconnectivity) {
    if (rows * cols < 5) {
      throw new IllegalArgumentException("Bad size of dungeon! Should be larger than 4 cells!");
    }
    if (rows <= 0 || cols <= 0) {
      throw new IllegalArgumentException("Bad size of dungeon! Column"
              + " or row should be larger than 0!");
    }
    this.rows = rows;
    this.cols = cols;
    this.interconnectivity = interconnectivity;
    this.cellMap = new Cell[rows][cols];
    allPath = new ArrayList<>();
    treasure = new ArrayList<>();
    int id = 0;
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        Cell room = new Cell(new int[]{i, j});
        room.setId(id);
        this.cellMap[i][j] = room;
        id += 1;
      }
    }
    for (int i = 0; i < rows - 1; i++) {
      for (int j = 0; j < cols - 1; j++) {
        this.allPath.add(new int[]{i, j, i, j + 1});
        this.allPath.add(new int[]{i, j, i + 1, j});
      }
    }
    for (int k = 0; k < cols - 1; k++) {
      this.allPath.add(new int[]{rows - 1, k, rows - 1, k + 1});
    }
    for (int l = 0; l < rows - 1; l++) {
      this.allPath.add(new int[]{l, cols - 1, l + 1, cols - 1});
    }
  }

  @Override
  public int getRowNum() {
    return this.rows;
  }

  @Override
  public int getColNum() {
    return this.cols;
  }

  @Override
  public int getInterconnectivity() {
    return this.interconnectivity;
  }

  @Override
  public void addTreasure(int percentage) {
    if (percentage < 0 || percentage < 20 || percentage > 100) {
      throw new IllegalArgumentException("Bad percentage! Should between 20% to 100%");
    }
    Random random = new Random();
    random.setSeed(4252);
    double per = (double) percentage / 100;
    int treasureRoomNum = (int) (per * this.rows * this.cols);
    while (treasure.size() < treasureRoomNum) {
      int i = random.nextInt(this.rows);
      int j = random.nextInt(this.cols);
      int size = cellMap[i][j].getDirections().size();
      if (size > 2) {
        treasure.add(new int[]{i, j});
        cellMap[i][j].setTreasure();
      }
    }
  }

  @Override
  public List<int[]> getTreasure() {
    List<int[]> treasureReturn = treasure;
    return treasureReturn;
  }

  @Override
  public List<int[]> getAllPath() {
    List<int[]> allPathReturn = allPath;
    return allPathReturn;
  }

  private List<Set<Integer>> setHelper() {
    List<Set<Integer>> cellSet = new ArrayList<>();
    for (int i = 0; i < this.rows; i++) {
      for (int j = 0; j < this.cols; j++) {
        Set<Integer> tmpSet = new HashSet<>();
        tmpSet.add(this.getCellMap()[i][j].getId());
        cellSet.add(tmpSet);
      }
    }
    return cellSet;
  }

  private void connectHelper() {
    Random random = new Random();
    random.setSeed(46);
    int interCounter = interconnectivity;
    while (interCounter > 0) {
      int[] tempPath = this.allPath.get(random.nextInt(this.allPath.size()));
      Cells remainOne = this.cellMap[tempPath[0]][tempPath[1]];
      Cells remainTwo = this.cellMap[tempPath[2]][tempPath[3]];
      this.allPath.remove(tempPath);
      if (tempPath[0] < tempPath[2] || tempPath[0] > tempPath[2]) {
        remainOne.setSouth(remainTwo);
        remainTwo.setNorth(remainOne);
      } else {
        remainOne.setEast(remainTwo);
        remainTwo.setWest(remainOne);
      }
      interCounter--;
    }
  }

  @Override
  public void generateDungeonGraph(List<int[]> allPath, int interconnectivity) {
    if (allPath == null) {
      throw new IllegalArgumentException("All path list cannot be null!");
    }
    Random random = new Random();
    random.setSeed(46);
    List<Set<Integer>> cellSet = setHelper();
    int cnt = 0;
    while (cnt < (this.rows * this.cols - 1)) {
      int[] tempPath = this.allPath.get(random.nextInt(this.allPath.size()));
      Cells tmpOne = this.cellMap[tempPath[0]][tempPath[1]];
      Cells tmpTwo = this.cellMap[tempPath[2]][tempPath[3]];
      Set<Integer> tmpSetOne = cellSet.get(tmpOne.getId());
      Set<Integer> tmpSetTwo = cellSet.get(tmpTwo.getId());
      if (!(tmpSetOne.equals(tmpSetTwo))) {
        tmpSetOne.addAll(tmpSetTwo);
        for (Integer index : tmpSetOne) {
          cellSet.set(index, tmpSetOne);
        }
        this.allPath.remove(tempPath);
        cnt++;
        if (tempPath[0] < tempPath[2] || tempPath[0] > tempPath[2]) {
          tmpOne.setSouth(tmpTwo);
          tmpTwo.setNorth(tmpOne);
        } else {
          tmpOne.setEast(tmpTwo);
          tmpTwo.setWest(tmpOne);
        }
      }
    }
    connectHelper();
  }

  @Override
  public Cells[][] getCellMap() {
    Cells[][] cellMapReturn = cellMap;
    return cellMapReturn;
  }
}
