package dungeon;

import java.util.List;

/**
 * This interface represents all the operations to be supported by a cell.
 * A cell has id, location and all of its neighbor cells.
 */
public interface Cells {
  /**
   * Return the location of this cell.
   *
   * @return the location of this cell
   */
  int[] getLocation();

  /**
   * Return the id of this cell.
   *
   * @return the id of this cell
   */
  int getId();

  /**
   * Set the id of this cell.
   *
   * @param id the id of this cell
   */
  void setId(int id);

  /**
   * Return the north cell of this cell.
   *
   * @return the north cell of this cell
   */
  Cells getNorth();

  /**
   * Set the north cell of this cell.
   *
   * @param north the north cell of this cell
   */
  void setNorth(Cells north);

  /**
   * Return the south cell of this cell.
   *
   * @return the south cell of this cell
   */
  Cells getSouth();

  /**
   * Set the south cell of this cell.
   *
   * @param south the south cell of this cell
   */
  void setSouth(Cells south);

  /**
   * Return the west cell of this cell.
   *
   * @return the west cell of this cell
   */
  Cells getWest();

  /**
   * Set the west cell of this cell.
   *
   * @param west the west cell of this cell
   */
  void setWest(Cells west);

  /**
   * Return the east cell of this cell.
   *
   * @return the east cell of this cell
   */
  Cells getEast();

  /**
   * Set the east cell of this cell.
   *
   * @param east the east cell of this cell
   */
  void setEast(Cells east);

  /**
   * Return the surrounding cells of this cell.
   *
   * @return the surrounding cells of this cell
   */
  List<String> getDirections();

  /**
   * Set the treasure of this cell.
   *
   */
  void setTreasure();

  /**
   * Return the diamond Number of this cell.
   *
   * @return the diamond Number
   */
  int getDiamondNum();

  /**
   * Set the diamond Number of this cell.
   *
   * @param diamondNum the diamond Number of this cell
   */
  void setDiamondNum(int diamondNum);

  /**
   * Return the rubies Number of this cell.
   *
   * @return the rubies Number
   */
  int getRubiesNum();

  /**
   * Set the rubies Number of this cell.
   *
   * @param rubiesNum the rubies Number of this cell
   */
  void setRubiesNum(int rubiesNum);

  /**
   * Return the sapphires Number of this cell.
   *
   * @return the sapphires Number
   */
  int getSapphiresNum();

  /**
   * Set the sapphires Number of this cell.
   *
   * @param sapphiresNum the sapphires Number of this cell
   */
  void setSapphiresNum(int sapphiresNum);

  /**
   * Return the graph of this cell.
   *
   * @return the graph of this cell
   */
  String cellGraphHelper();
}
