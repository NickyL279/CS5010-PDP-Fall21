package dungeon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * This class represents a cell room. A cell has treasures, directions and id.
 * A cell has id, location and all of its neighbor cells.
 */
public class Cell implements Cells {
  private final int[] location;
  private int id;
  private int diamondNum;
  private int rubiesNum;
  private int sapphiresNum;
  private Cells north;
  private Cells south;
  private Cells west;
  private Cells east;

  /**
   * Construct a cell object that has the provided location.
   *
   * @param location the location of this cell in a dungeon.
   * @throws IllegalArgumentException if location is invalid.
   */
  public Cell(int[] location) {
    if (location[0] < 0 || location[1] < 0) {
      throw new IllegalArgumentException("Bad cell.");
    }
    this.diamondNum = 0;
    this.rubiesNum = 0;
    this.sapphiresNum = 0;
    this.location = location;
    this.north = null;
    this.south = null;
    this.west = null;
    this.east = null;
  }

  @Override
  public int[] getLocation() {
    return this.location;
  }

  @Override
  public int getId() {
    return this.id;
  }

  @Override
  public void setId(int id) {
    if (id < 0) {
      throw new IllegalArgumentException("Id cannot be smaller than 0!");
    }
    this.id = id;
  }

  @Override
  public Cells getNorth() {
    return this.north;
  }

  @Override
  public void setNorth(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.north = cell;
  }

  @Override
  public Cells getSouth() {
    return this.south;
  }

  @Override
  public void setSouth(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.south = cell;
  }

  @Override
  public Cells getWest() {
    return this.west;
  }

  @Override
  public void setWest(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.west = cell;
  }

  @Override
  public Cells getEast() {
    return this.east;
  }

  @Override
  public void setEast(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.east = cell;
  }

  @Override
  public List<String> getDirections() {
    List<String> directions = new ArrayList<>();
    if (this.north != null) {
      directions.add("north");
    }
    if (this.south != null) {
      directions.add("south");
    }
    if (this.west != null) {
      directions.add("west");
    }
    if (this.east != null) {
      directions.add("east");
    }
    return directions;
  }

  @Override
  public void setTreasure() {
    Random random = new Random();
    random.setSeed(25425);
    boolean flag = false;
    while (!flag) {
      this.setDiamondNum(random.nextInt(2));
      this.setRubiesNum(random.nextInt(2));
      this.setSapphiresNum(random.nextInt(2));
      if (!(diamondNum == 0 && rubiesNum == 0 && sapphiresNum == 0)) {
        flag = true;
      }
    }
  }

  @Override
  public int getDiamondNum() {
    return diamondNum;
  }

  @Override
  public void setDiamondNum(int diamondNum) {
    this.diamondNum = diamondNum;
  }

  @Override
  public int getRubiesNum() {
    return rubiesNum;
  }

  @Override
  public void setRubiesNum(int rubiesNum) {
    this.rubiesNum = rubiesNum;
  }

  @Override
  public int getSapphiresNum() {
    return sapphiresNum;
  }

  @Override
  public void setSapphiresNum(int sapphiresNum) {
    this.sapphiresNum = sapphiresNum;
  }

  @Override
  public String toString() {
    return String.format("* %s %s. Has %d dia, %d rub, %d sap. *",
            Arrays.toString(location), this.getDirections().toString(),
            this.diamondNum, this.rubiesNum, this.sapphiresNum);
  }

  @Override
  public String cellGraphHelper() {
    String s = String.join(" ", this.getDirections());
    switch (s) {
      case "north":
        return String.format("  |  \n %d %d \n     ", location[0], location[1]);
      case "south":
        return String.format("     \n %d %d \n  |  ", location[0], location[1]);
      case "east":
        return String.format("     \n %d %d-\n     ", location[0], location[1]);
      case "west":
        return String.format("     \n-%d %d \n     ", location[0], location[1]);
      case "north south":
        return String.format("  |  \n %d %d \n  |  ", location[0], location[1]);
      case "west east":
        return String.format("     \n-%d %d-\n     ", location[0], location[1]);
      case "north east":
        return String.format("  |  \n %d %d-\n     ", location[0], location[1]);
      case "north west":
        return String.format("  |  \n-%d %d \n     ", location[0], location[1]);
      case "south west":
        return String.format("     \n-%d %d \n  |  ", location[0], location[1]);
      case "south east":
        return String.format("     \n %d %d-\n  |  ", location[0], location[1]);
      case "north west east":
        return String.format("  |  \n-%d %d-\n     ", location[0], location[1]);
      case "south west east":
        return String.format("     \n-%d %d-\n  |  ", location[0], location[1]);
      case "north south west":
        return String.format("  |  \n-%d %d \n  |  ", location[0], location[1]);
      case "north south east":
        return String.format("  |  \n %d %d-\n  |  ", location[0], location[1]);
      case "north south west east":
        return String.format("  |  \n-%d %d-\n  |  ", location[0], location[1]);
      default:
        return "";
    }
    //    if (this.getDirections().contains("north") && !this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("  |  \n %d %d \n     ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("     \n %d %d \n  |  ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && !this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("     \n %d %d-\n     ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && !this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("     \n-%d %d \n     ", location[0], location[1]);
    //    } else if (this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("  |  \n %d %d \n  |  ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && !this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("     \n-%d %d-\n     ", location[0], location[1]);
    //    } else if (this.getDirections().contains("north")
    //    && !this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("  |  \n %d %d-\n     ", location[0], location[1]);
    //    } else if (this.getDirections().contains("north")
    //    && !this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("  |  \n-%d %d \n     ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("     \n-%d %d \n  |  ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("     \n %d %d-\n  |  ", location[0], location[1]);
    //    } else if (this.getDirections().contains("north")
    //    && !this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("  |  \n-%d %d-\n     ", location[0], location[1]);
    //    } else if (!this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("     \n-%d %d-\n  |  ", location[0], location[1]);
    //    } else if (this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && !this.getDirections().contains("east")
    //            && this.getDirections().contains("west")) {
    //      return String.format("  |  \n-%d %d \n  |  ", location[0], location[1]);
    //    } else if (this.getDirections().contains("north")
    //    && this.getDirections().contains("south")
    //            && this.getDirections().contains("east")
    //            && !this.getDirections().contains("west")) {
    //      return String.format("  |  \n %d %d-\n  |  ", location[0], location[1]);
    //    } else {
    //      return String.format("  |  \n-%d %d-\n  |  ", location[0], location[1]);
    //    }
  }
}
