package dungeon;

/**
 * This interface represents all the operations to be supported by player. A player
 * has three kind of treasure with different amount of them.
 */
public interface Players {
  /**
   * Return the number of diamonds of this player.
   *
   * @return the number of diamonds
   */
  int getDiamondNum();

  /**
   * Set the number of diamonds of this player.
   *
   * @param diamondNum the number of diamonds
   */
  void setDiamondNum(int diamondNum);

  /**
   * Return the number of rubies of this player.
   *
   * @return the number of rubies
   */
  int getRubiesNum();

  /**
   * Set the number of rubies of this player.
   *
   * @param rubiesNum the number of rubies
   */
  void setRubiesNum(int rubiesNum);

  /**
   * Return the number of Sapphires of this player.
   *
   * @return the number of Sapphires
   */
  int getSapphiresNum();

  /**
   * Set the number of sapphires of this player.
   *
   * @param sapphiresNum the number of sapphires
   */
  void setSapphiresNum(int sapphiresNum);

  /**
   * Pick up treasures in a given cell.
   *
   * @param cell the cell player is in
   */
  void pickTreasure(Cells cell);
}
