package dungeon;

import java.util.List;

/**
 * This interface represents all the operations to be supported by dungeon. A dungeon has
 * a start point, end point and player's current point.
 * It also supports to show the graph of this dungeon.
 */
public interface Dungeons {
  /**
   * Return the start point of this dungeon.
   *
   * @return the start point
   */
  int[] getStart();

  /**
   * Return the end point of this dungeon.
   *
   * @return the end point
   */
  int[] getEnd();

  /**
   * Return the player's location in this dungeon.
   *
   * @return the player's location
   */
  int[] getLoc();

  /**
   * Return the player's diamond number in this dungeon.
   *
   * @return the player's diamond number
   */
  int getCurrentDia();

  /**
   * Return the player's ruby number in this dungeon.
   *
   * @return the player's ruby number
   */
  int getCurrentRub();

  /**
   * Return the player's sapphires number in this dungeon.
   *
   * @return the player's sapphires number
   */
  int getCurrentSap();

  /**
   * Return the player's possible move direction in this dungeon.
   *
   * @return the player's possible move direction
   */
  List<String> getPosDirections();

  /**
   * Move the player to the desired direction in this dungeon.
   *
   * @param movement the player's move direction
   */
  void move(String movement);

  /**
   * Player picks up the treasure in current location.
   *
   */
  void pick();

  /**
   * Return whether the player has reached the goal point.
   *
   * @return whether the player has reached the goal point
   */
  boolean checkWin();

  /**
   * Return a graphic map of the dungeon.
   *
   * @return a graphic map of the dungeon
   */
  String graphBuilder();
}
