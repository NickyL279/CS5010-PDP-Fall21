package dungeon;

/**
 * This class represents a player. A player has three treasures.
 */
public class Player implements Players {
  private int diamondNum;
  private int rubiesNum;
  private int sapphiresNum;

  /**
   * Construct a player object that has the provided diamond, rubies and sapphires.
   *
   */
  public Player() {
    this.diamondNum = 0;
    this.rubiesNum = 0;
    this.sapphiresNum = 0;
  }

  @Override
  public int getDiamondNum() {
    int dNum = diamondNum;
    return dNum;
  }

  @Override
  public void setDiamondNum(int diamondNum) {
    this.diamondNum += diamondNum;
  }

  @Override
  public int getRubiesNum() {
    int rNum = rubiesNum;
    return rNum;
  }

  @Override
  public void setRubiesNum(int rubiesNum) {
    this.rubiesNum += rubiesNum;
  }

  @Override
  public int getSapphiresNum() {
    int sNum = sapphiresNum;
    return sNum;
  }

  @Override
  public void setSapphiresNum(int sapphiresNum) {
    this.sapphiresNum += sapphiresNum;
  }

  @Override
  public void pickTreasure(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    if (cell.getDiamondNum() == 0 && cell.getRubiesNum() == 0 && cell.getSapphiresNum() == 0) {
      throw new IllegalArgumentException("No treasure to pick!");
    }
    this.setDiamondNum(cell.getDiamondNum());
    cell.setDiamondNum(0);
    this.setRubiesNum(cell.getRubiesNum());
    cell.setRubiesNum(0);
    this.setSapphiresNum(cell.getSapphiresNum());
    cell.setSapphiresNum(0);
  }
}
