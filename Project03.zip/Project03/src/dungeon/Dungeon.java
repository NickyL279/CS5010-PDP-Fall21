package dungeon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * This class represents a dungeon. A dungeon has a start point, an end point.
 * It also supports to show the graph of this dungeon.
 */
public class Dungeon implements Dungeons {
  private final int[] start;
  private final Cells[][] cellMap;
  private final int rows;
  private final int cols;
  private final int[] end;
  private final Player player;
  private int[] playerLocation;
  private boolean winFlag;

  /**
   * Construct a dungeon object that has the provided rows, columns and cellMap.
   *
   * @param cellMap the map to all cells to be given to this dungeon
   * @throws IllegalArgumentException if start/end point is invalid
   */
  public Dungeon(Cells[][] cellMap) {
    if (cellMap == null) {
      throw new IllegalArgumentException("Cell map cannot be null!");
    }
    this.winFlag = false;
    this.rows = cellMap.length;
    this.cols = cellMap[0].length;
    Random random = new Random();
    int randRows = random.nextInt(rows);
    int randCols = random.nextInt(cols);
    //  endRowList = new ArrayList<>();
    //  endColList = new ArrayList<>();
    //  private List<Integer> endRowList;
    //  private List<Integer> endColList;
    List<int[]> endList = new ArrayList<>();
    start = new int[]{randRows, randCols};
    //while (endRowList.size() < rows && endColList.size() < cols) {
    while (endList.size() < Math.max(rows, cols)) {
      int randRows1 = random.nextInt(rows);
      int randCols1 = random.nextInt(cols);
      if (Math.abs(randRows1 - randRows) + Math.abs(randCols1 - randCols) > 5) {
        //        endRowList.add(randRows1);
        //        endColList.add(randCols1);
        endList.add(new int[]{randRows1, randCols1});
      }
    }
    //    end = new int[]{endRowList.get(random.nextInt(endRowList.size())),
    //            endColList.get(random.nextInt(endColList.size()))};
    end = endList.get(random.nextInt(endList.size()));
    if (start[0] < 0 || start[0] >= cellMap.length
            || start[1] < 0 || start[1] >= cellMap[0].length) {
      throw new IllegalArgumentException("Bad start.");
    }
    if (end[0] < 0 || end[0] >= cellMap.length
            || end[1] < 0 || end[1] >= cellMap[0].length) {
      throw new IllegalArgumentException("Bad end.");
    }
    this.player = new Player();
    this.playerLocation = start;
    this.cellMap = cellMap;
  }

  @Override
  public int[] getStart() {
    return start;
  }

  @Override
  public int[] getEnd() {
    return end;
  }

  /**
   * Get player's location.
   */
  @Override
  public int[] getLoc() {
    return this.playerLocation;
  }

  /**
   * Get player's current gold.
   */
  @Override
  public int getCurrentDia() {
    return this.player.getDiamondNum();
  }

  @Override
  public int getCurrentRub() {
    return this.player.getRubiesNum();
  }

  @Override
  public int getCurrentSap() {
    return this.player.getSapphiresNum();
  }

  @Override
  public List<String> getPosDirections() {
    List<String> directionReturn =
            this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getDirections();
    return directionReturn;
  }

  @Override
  public void move(String movement) {
    if (!this.getPosDirections().contains(movement)) {
      throw new IllegalArgumentException("Bad input! Cannot move to this position!");
    }
    Cells cur = this.cellMap[this.getLoc()[0]][this.getLoc()[1]];
    Cells nxt = null;
    switch (movement) {
      case "north":
        nxt = cur.getNorth();
        break;
      case "south":
        nxt = cur.getSouth();
        break;
      case "west":
        nxt = cur.getWest();
        break;
      case "east":
        nxt = cur.getEast();
        break;
      default:
        break;
    }
    //    if (Objects.equals(movement, "north")) {
    //      nxt = cur.getNorth();
    //    } else if (Objects.equals(movement, "south")) {
    //      nxt = cur.getSouth();
    //    } else if (Objects.equals(movement, "west")) {
    //      nxt = cur.getWest();
    //    } else if (Objects.equals(movement, "east")) {
    //      nxt = cur.getEast();
    //    } else {
    //      throw new IllegalArgumentException("Bad input! Cannot move to this position!");
    //    }
    if (nxt == null) {
      throw new IllegalArgumentException("Next move cannot be null!");
    }
    this.playerLocation = nxt.getLocation();
    if (this.playerLocation[0] == this.end[0] && this.playerLocation[1] == this.end[1]) {
      this.winFlag = true;
    }
  }

  @Override
  public void pick() {
    if (this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getDiamondNum() != 0
            || this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getRubiesNum() != 0
            || this.cellMap[this.playerLocation[0]][this.playerLocation[1]]
            .getSapphiresNum() != 0) {
      this.player.pickTreasure(cellMap[playerLocation[0]][playerLocation[1]]);
    }
  }

  /**
   * Check player arrived the finish point or not.
   */
  @Override
  public boolean checkWin() {
    return this.winFlag;
  }

  @Override
  public String toString() {
    List<String> tmpCellMap = new ArrayList<>();
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        tmpCellMap.add(cellMap[i][j].toString());
      }
      tmpCellMap.add("\n");
    }
    return String.join("", tmpCellMap);
  }

  @Override
  public String graphBuilder() {
    List<String[]> s2 = new ArrayList<>();
    String[] s3 = new String[]{"", "", ""};
    String[] s5 = new String[rows];
    Arrays.fill(s5, "");
    for (int i = 0; i < rows; i++) {
      String s4 = "";
      for (int j = 0; j < cols; j++) {
        String[] s1 = cellMap[i][j].cellGraphHelper().split("\n");
        s3[0] = s3[0] + s1[0];
        s3[1] = s3[1] + s1[1];
        s3[2] = s3[2] + s1[2];
      }
      s4 = String.join("\n", s3);
      s5[i] = s4;
      s3 = new String[]{"", "", ""};
    }
    return String.join("\n", s5);
  }
}

