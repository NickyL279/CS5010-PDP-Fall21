package test;

import org.junit.Before;
import org.junit.Test;
import dungeon.Dungeon;
import dungeon.Dungeons;
import dungeon.Player;
import kruskal.KruskalDungeon;
import kruskal.UnwrappedDungeon;
import kruskal.WrappedDungeon;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the player.
 */
public class PlayerTest {
  Player player;
  Dungeons d1;
  KruskalDungeon kd1;
  Dungeons d2;
  KruskalDungeon kd2;

  @Before
  public void setUp() {
    player = new Player();
    kd1 = new WrappedDungeon(4, 6, 12);
    kd1.generate();
    d1 = new Dungeon(kd1.getCellMap());
    kd2 = new UnwrappedDungeon(6, 8, 16);
    kd2.generate();
    d2 = new Dungeon(kd2.getCellMap());
  }

  @Test
  public void testGetDiamond() {
    assertEquals(0, player.getDiamondNum());
    player.setDiamondNum(3);
    assertEquals(3, player.getDiamondNum());
  }

  @Test
  public void testGetRub() {
    assertEquals(0, player.getRubiesNum());
    player.setRubiesNum(3);
    assertEquals(3, player.getRubiesNum());
  }

  @Test
  public void testGetSap() {
    assertEquals(0, player.getSapphiresNum());
    player.setSapphiresNum(3);
    assertEquals(3, player.getSapphiresNum());
  }

  @Test
  public void testPickTreasure() {
    kd1.addTreasure(100);
    player.pickTreasure(kd1.getCellMap()[3][2]);
    assertEquals(1, player.getDiamondNum());
    assertEquals(1, player.getRubiesNum());
    assertEquals(1, player.getSapphiresNum());
  }

  @Test (expected = IllegalArgumentException.class)
  public void testPickTreasure1() {
    kd1.addTreasure(20);
    player.pickTreasure(kd1.getCellMap()[3][5]);
  }
}
