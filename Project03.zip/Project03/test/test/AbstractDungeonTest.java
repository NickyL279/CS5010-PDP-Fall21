package test;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import dungeon.Dungeon;
import dungeon.Dungeons;
import kruskal.KruskalDungeon;
import kruskal.UnwrappedDungeon;
import kruskal.WrappedDungeon;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the Abstract Dungeon.
 */
public class AbstractDungeonTest {
  Dungeons d1;
  KruskalDungeon kd1;
  Dungeons d2;
  KruskalDungeon kd2;

  @Before
  public void setUp() {
    kd1 = new WrappedDungeon(4, 6, 12);
    kd1.generate();
    d1 = new Dungeon(kd1.getCellMap());
    kd2 = new UnwrappedDungeon(6, 8, 16);
    kd2.generate();
    d2 = new Dungeon(kd2.getCellMap());
  }

  @Test
  public void getRowNumTest() {
    assertEquals(4, kd1.getRowNum());
    assertEquals(6, kd2.getRowNum());
  }

  @Test
  public void getColNum() {
    assertEquals(6, kd1.getColNum());
    assertEquals(8, kd2.getColNum());
  }

  @Test
  public void getInterconnectivity() {
    assertEquals(12, kd1.getInterconnectivity());
    assertEquals(16, kd2.getInterconnectivity());
  }

  @Test
  public void getTreasure() {
    kd1.addTreasure(50);
    kd2.addTreasure(50);
    assertEquals(6, Arrays.toString(kd1.getTreasure().get(0)).length());
    assertEquals(6, Arrays.toString(kd2.getTreasure().get(0)).length());
  }

  @Test(expected = IllegalArgumentException.class)
  public void getTreasure1() {
    kd1.addTreasure(12);
    kd2.addTreasure(12);
  }

  @Test(expected = IllegalArgumentException.class)
  public void getTreasure2() {
    kd1.addTreasure(102);
    kd2.addTreasure(201);
  }

  @Test
  public void getAllPath() {
    assertEquals(48, kd1.getAllPathSize());
    assertEquals(82, kd2.getAllPathSize());
  }

  @Test
  public void testGenerate() {
    assertEquals(12, Arrays.toString(kd1.getAllPath().get(0)).length());
    assertEquals(12, Arrays.toString(kd2.getAllPath().get(0)).length());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGenerate1() {
    KruskalDungeon kd3 = new WrappedDungeon(2, 2, 8);
    KruskalDungeon kd4 = new UnwrappedDungeon(2, 2, 8);
    kd3.generateDungeonGraph(null, 12);
    kd4.generateDungeonGraph(null, 12);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate() {
    KruskalDungeon kd3 = new WrappedDungeon(2, 2, 8);
    KruskalDungeon kd4 = new UnwrappedDungeon(2, 2, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate1() {
    KruskalDungeon kd3 = new WrappedDungeon(-1, 2, 8);
    KruskalDungeon kd4 = new UnwrappedDungeon(-2, 2, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate2() {
    KruskalDungeon kd3 = new WrappedDungeon(4, -2, 8);
    KruskalDungeon kd4 = new UnwrappedDungeon(4, -2, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate3() {
    KruskalDungeon kd3 = new WrappedDungeon(4, 6, 45);
    KruskalDungeon kd4 = new UnwrappedDungeon(4, 6, 36);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate4() {
    KruskalDungeon kd3 = new WrappedDungeon(4, 6, -45);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate5() {
    KruskalDungeon kd4 = new UnwrappedDungeon(4, 6, -36);
  }
}