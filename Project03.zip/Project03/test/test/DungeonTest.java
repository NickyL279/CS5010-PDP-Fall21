package test;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import dungeon.Dungeon;
import dungeon.Dungeons;
import kruskal.KruskalDungeon;
import kruskal.UnwrappedDungeon;
import kruskal.WrappedDungeon;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Class that tests the dungeon.
 */
public class DungeonTest {
  Dungeons d1;
  KruskalDungeon kd1;
  Dungeons d2;
  KruskalDungeon kd2;

  @Before
  public void setUp() {
    kd1 = new WrappedDungeon(4, 6, 12);
    kd1.generate();
    d1 = new Dungeon(kd1.getCellMap());
    kd2 = new UnwrappedDungeon(6, 8, 16);
    kd2.generate();
    d2 = new Dungeon(kd2.getCellMap());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 6, 12);
    KruskalDungeon kd4 = new WrappedDungeon(4, 6, 12);
    Dungeons d1 = new Dungeon(null);
    Dungeons d2 = new Dungeon(null);
  }

  @Test
  public void testGetStart() {
    assertEquals(6, Arrays.toString(d1.getStart()).length());
    assertEquals(6, Arrays.toString(d2.getStart()).length());
  }

  @Test
  public void testGetEnd() {
    assertEquals(6, Arrays.toString(d1.getEnd()).length());
    assertEquals(6, Arrays.toString(d2.getEnd()).length());
  }

  @Test
  public void testGetPlayerLocation() {
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
    assertEquals(6, Arrays.toString(d2.getLoc()).length());
  }

  @Test
  public void testGetTreasure() {
    assertEquals(0, d1.getCurrentDia());
    assertEquals(0, d2.getCurrentDia());
    assertEquals(0, d1.getCurrentRub());
    assertEquals(0, d2.getCurrentRub());
    assertEquals(0, d1.getCurrentSap());
    assertEquals(0, d2.getCurrentSap());
  }

  @Test
  public void getPossibleMove() {
    boolean flagOne = d1.getPosDirections().size() > 0;
    assertTrue(flagOne);
    boolean flagTwo = d2.getPosDirections().size() > 0;
    assertTrue(flagTwo);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMove() {
    d1.move("out");
    d2.move("in");
  }

  @Test
  public void testMove() {
    d1.move("north");
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
  }

  @Test (expected = IllegalArgumentException.class)
  public void testMove1() {
    d1.move("south");
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
  }

  @Test(expected = AssertionError.class)
  public void testGetTreasure1() {
    kd1.addTreasure(60);
    d1.pick();
    kd2.addTreasure(60);
    d2.pick();
    assertEquals(1, d1.getCurrentDia());
    assertEquals(1, d2.getCurrentDia());
    assertEquals(1, d1.getCurrentRub());
    assertEquals(1, d2.getCurrentRub());
    assertEquals(1, d1.getCurrentSap());
    assertEquals(1, d2.getCurrentSap());
  }
}
