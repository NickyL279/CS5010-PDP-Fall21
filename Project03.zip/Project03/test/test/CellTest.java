package test;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import dungeon.Cell;
import dungeon.Cells;
import dungeon.Player;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the cell.
 */
public class CellTest {
  Cells c1;
  Player p;

  @Before
  public void setUp() {
    c1 = new Cell(new int[]{1, 2});
    p = new Player();
  }

  @Test(expected = IllegalArgumentException.class)
  public void createInvalid() {
    Cells c2 = new Cell(new int[]{-1, 2});
  }

  @Test
  public void getLocation() {
    assertEquals("[1, 2]", Arrays.toString(c1.getLocation()));
  }

  @Test
  public void getId() {
    c1.setId(1);
    assertEquals(1, c1.getId());
  }

  @Test(expected = IllegalArgumentException.class)
  public void getId1() {
    c1.setId(-1);
  }

  @Test
  public void getDirection() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("* [0, 0] []. Has 0 dia, 0 rub, 0 sap. *", c1.getNorth().toString());
    assertEquals("* [0, 1] []. Has 0 dia, 0 rub, 0 sap. *", c1.getSouth().toString());
    assertEquals("* [0, 2] []. Has 0 dia, 0 rub, 0 sap. *", c1.getEast().toString());
    assertEquals("* [0, 3] []. Has 0 dia, 0 rub, 0 sap. *", c1.getWest().toString());
    assertEquals("north south west east", String.join(" ", c1.getDirections()));
  }

  @Test(expected = IllegalArgumentException.class)
  public void getDirection1() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(null);
    c1.setSouth(null);
    c1.setEast(null);
    c1.setWest(null);
  }

  @Test
  public void getTreasure() {
    c1.setTreasure();
    assertEquals(1, c1.getDiamondNum());
    assertEquals(1, c1.getRubiesNum());
    assertEquals(1, c1.getSapphiresNum());
  }

  @Test
  public void toStringTest() {
    assertEquals("* [1, 2] []. Has 0 dia, 0 rub, 0 sap. *", c1.toString());
    c1.setTreasure();
    assertEquals("* [1, 2] []. Has 1 dia, 1 rub, 1 sap. *", c1.toString());
    p.pickTreasure(c1);
    assertEquals("* [1, 2] []. Has 0 dia, 0 rub, 0 sap. *", c1.toString());
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("* [1, 2] [north, south, west, east]. Has 0 dia, 0 rub, 0 sap. *", c1.toString());
  }

  @Test
  public void testGraph() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("  |  \n" +
            "-1 2-\n" +
            "  |  ", c1.cellGraphHelper());
  }
}
