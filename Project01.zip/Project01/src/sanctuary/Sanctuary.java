package sanctuary;

import housing.Enclosure;
import housing.Housing;
import housing.Isolation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import primate.Food;
import primate.Primate;
import primate.Species;

/**
 * Sanctuary class that can hold isolations and enclosures.
 */
public class Sanctuary implements Sanctuaries {
  private final int maxIsolationAmount;
  private final int maxEnclosureAmount;
  private List<Primate> addedMonkeys;
  private List<Housing> isolations;
  private List<Housing> enclosures;
  private int isolationAmount;
  private int enclosureAmount;

  /**
   * Creates a sanctuary object with the information about the sanctuary.
   *
   * @param enclosureAmount The amount of isolations.
   * @param isolationAmount The amount of enclosures.
   * @param enclosureMaxAmount The max amount of enclosures.
   * @param isolationMaxAmount The max amount of isolations.
   * @throws IllegalArgumentException If housing amount is negative.
   * @throws IllegalArgumentException If id is housing amount exceeded the max amount.
   */
  public Sanctuary(int enclosureAmount, int isolationAmount, int enclosureMaxAmount,
                   int isolationMaxAmount) throws IllegalArgumentException {
    if (enclosureAmount <= 0 || isolationAmount <= 0 || enclosureMaxAmount <= 0
            || isolationMaxAmount <= 0) {
      throw new IllegalArgumentException("housing amount should be greater than 0");
    }
    if (enclosureAmount > enclosureMaxAmount || isolationAmount > isolationMaxAmount) {
      throw new IllegalArgumentException("housing amount shouldn't exceed the max amount");
    }
    this.maxIsolationAmount = isolationMaxAmount;
    this.maxEnclosureAmount = enclosureMaxAmount;
    this.isolationAmount = isolationAmount;
    this.enclosureAmount = enclosureAmount;
    this.addedMonkeys = new ArrayList<>();
    this.isolations = isolationHelper(isolationAmount, maxIsolationAmount);
    this.enclosures = enclosureHelper(enclosureAmount, maxEnclosureAmount);
  }

  private List<Housing> isolationHelper(int isolationAmount, int maxIsolationAmount)
          throws IllegalArgumentException {
    List<Housing> isoTemp = new ArrayList<>();
    if (isolationAmount > maxIsolationAmount) {
      throw new IllegalArgumentException("isolation number exceeded");
    }
    for (int i = 0; i < isolationAmount; i++) {
      Isolation iso = new Isolation("isolation" + String.valueOf(i));
      isoTemp.add(iso);
    }
    return isoTemp;
  }

  private Species randomPick() {
    return Species.values()[new Random().nextInt(Species.values().length)];
  }

  private List<Housing> enclosureHelper(int enclosureAmount, int maxEnclosureAmount)
          throws IllegalArgumentException {
    List<Housing> encTemp = new ArrayList<>();
    int defaultArea = 30;
    if (enclosureAmount > maxEnclosureAmount) {
      throw new IllegalArgumentException("enclosure number exceeded");
    }
    Species speciesTemp = randomPick();
    for (int i = 0; i < enclosureAmount; i++) {
      Enclosure enc = new Enclosure("enclosure" + String.valueOf(i), defaultArea, null);
      encTemp.add(enc);
    }
    return encTemp;
  }

  @Override
  public void addMonkey(Primate primate) throws IllegalArgumentException {
    boolean flag = false;
    for (Housing isolation : isolations) {
      if (isolation.checkAvailability(primate)) {
        isolation.addAnimal(primate);
        addedMonkeys.add(primate);
        flag = true;
        break;
      }
    }
    if (!flag) {
      throw new IllegalArgumentException("isolation is full");
    }
  }

  private Housing houseHelper(String id) {
    Housing houseTemp = null;
    for (Housing enclosure : enclosures) {
      if (id.equals(enclosure.getId())) {
        houseTemp = enclosure;
      }
    }
    for (Housing isolation : isolations) {
      if (id.equals(isolation.getId())) {
        houseTemp = isolation;
      }
    }
    return houseTemp;
  }

  @Override
  public void exchangeMonkey(Primate primate) {
    houseHelper(primate.getLocation()).removeAnimal(primate);
    addedMonkeys.remove(primate);
  }

  @Override
  public void moveMonkey(String dest, Primate primate) {
    int defaultArea = 30;
    boolean flag = false;
    for (Housing enclosure : enclosures) {
      if (enclosure.getId().equals(dest)) {
        if (houseHelper(dest).checkAvailability(primate)) {
          houseHelper(primate.getLocation()).removeAnimal(primate);
          addedMonkeys.remove(primate);
          enclosure.addAnimal(primate);
          addedMonkeys.add(primate);
          flag = true;
          break;
        }
      }
    }
    for (Housing isolation : isolations) {
      if (isolation.getId().equals(dest)) {
        if (houseHelper(dest).checkAvailability(primate)) {
          houseHelper(primate.getLocation()).removeAnimal(primate);
          addedMonkeys.remove(primate);
          isolation.addAnimal(primate);
          addedMonkeys.add(primate);
          flag = true;
          break;
        }
      }
    }
    if (!flag) {
      throw new IllegalArgumentException("cannot be housed");
    }
  }

  @Override
  public HashMap<Species, String> getSpecies() {
    HashMap<Species, String> allSpeciesReport = new HashMap<>();
    for (Housing isolation : isolations) {
      if (isolation.getSpecies() != null) {
        if (allSpeciesReport.get(isolation.getSpecies()) == null) {
          allSpeciesReport.put(isolation.getSpecies(), isolation.getId());
        } else {
          allSpeciesReport.put(isolation.getSpecies(), allSpeciesReport.get(isolation.getSpecies())
                  + isolation.getId());
        }
      }
    }
    for (Housing enclosure : enclosures) {
      if (enclosure.getSpecies() != null) {
        if (allSpeciesReport.get(enclosure.getSpecies()) == null) {
          allSpeciesReport.put(enclosure.getSpecies(), enclosure.getId());
        } else {
          allSpeciesReport.put(enclosure.getSpecies(), allSpeciesReport.get(enclosure.getSpecies())
                  + enclosure.getId());
        }
      }
    }
    return allSpeciesReport;
  }

  @Override
  public List<String> getTheSpecies(Species species) {
    List<String> speciesLocation = new ArrayList<>();
    for (Housing isolation : isolations) {
      if (species == isolation.getSpecies()) {
        speciesLocation.add(species.toString() + " " + isolation.getId());
      }
    }
    for (Housing enclosure : enclosures) {
      if (species == enclosure.getSpecies()) {
        speciesLocation.add(species.toString() + " " + enclosure.getId());
      }
    }
    return speciesLocation;
  }

  @Override
  public List<String> getAnimals() {
    List<String> allAnimals = new ArrayList<>();
    for (Primate primate : addedMonkeys) {
      allAnimals.add(primate.getName() + " " + primate.getLocation());
    }
    Collections.sort(allAnimals);
    return allAnimals;
  }

  private int foodHelper(int size) {
    int foodAmount = 0;
    if (size < 10) {
      foodAmount = 100;
    } else if (size > 10 && size < 20) {
      foodAmount = 250;
    } else {
      foodAmount = 500;
    }
    return foodAmount;

  }

  @Override
  public HashMap<Food, Integer> getShoppingList() {
    HashMap<Food, Integer> shoppingList = new HashMap<>();
    for (Primate primate : addedMonkeys) {
      if (shoppingList.get(primate.getFavFood()) == null) {
        shoppingList.put(primate.getFavFood(), foodHelper(primate.getSize()));
      } else {
        shoppingList.put(primate.getFavFood(), shoppingList.get(primate.getFavFood())
                + foodHelper(primate.getSize()));
      }
    }
    return shoppingList;
  }

  @Override
  public void expandIsolationNum() throws IllegalArgumentException {
    if (isolationAmount >= maxIsolationAmount - 1) {
      throw new IllegalArgumentException("Habitat has reached it's max.");
    }
    isolationAmount += 1;
    Isolation iso = new Isolation("isolation" + String.valueOf(isolationAmount - 1));
    isolations.add(iso);
  }

  @Override
  public void expandEnclosureNum() {
    if (enclosureAmount >= maxEnclosureAmount - 1) {
      throw new IllegalArgumentException("Habitat has reached it's max.");
    }
    enclosureAmount += 1;
    Enclosure enc = new Enclosure("enclosure" + String.valueOf(enclosureAmount - 1), 30, null);
    enclosures.add(enc);
  }

  @Override
  public List<String> printSign(String enclosureId) {
    List<String> signList = new ArrayList<>();
    for (Primate primate : addedMonkeys) {
      if (primate.getLocation().equals(enclosureId)) {
        signList.add(primate.getName() + " " + primate.getSex() + " " + primate.getFavFood()
                .toString());
      }
    }
    return signList;
  }

  @Override
  public String print() {
    List<String> monkeyTemp = new ArrayList<>();
    List<String> isoTemp = new ArrayList<>();
    List<String> encTemp = new ArrayList<>();
    for (Primate monkey : addedMonkeys) {
      monkeyTemp.add(monkey.toString() + ".");
    }
    for (Housing isolation : isolations) {
      isoTemp.add(isolation.getId() + ";");
    }
    for (Housing enclosure : enclosures) {
      encTemp.add(enclosure.getId() + ";");
    }
    Species spTemp = randomPick();
    if (monkeyTemp.isEmpty()) {
      return String.format("There are %d isolations (%s) and %d enclosures (%s). ", isolationAmount,
              String.join(" ", isoTemp), enclosureAmount, String.join(" ", encTemp));
    }
    return String.format("There are %d isolations (%s) and %d enclosures (%s). ", isolationAmount,
            String.join(" ", isoTemp), enclosureAmount, String.join(" ", encTemp))
            + "The monkeys are " + String.join(" ", monkeyTemp);
  }

}
