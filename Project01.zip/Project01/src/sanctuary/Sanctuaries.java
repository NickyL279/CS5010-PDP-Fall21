package sanctuary;

import java.util.HashMap;
import java.util.List;
import primate.Food;
import primate.Primate;
import primate.Species;

/**
 * An interface called Sanctuaries.
 */
public interface Sanctuaries {
  /**
   * move a monkey to another housing.
   */
  void moveMonkey(String dest, Primate primate);

  /**
   * add a monkey to isolation.
   */
  void addMonkey(Primate primate);

  /**
   * exchange a monkey to other sanctuaries.
   */
  void exchangeMonkey(Primate primate);

  /**
   * Report the species that are currently being housed in alphabetical order.
   */
  HashMap<Species, String> getSpecies();

  /**
   * Look up where a particular species is currently housed.
   */
  List<String> getTheSpecies(Species species);

  /**
   * Produce an alphabetical list (by name) of all of the monkeys housed in the Sanctuary.
   */
  List<String> getAnimals();

  /**
   * Produce a shopping list of the favorite foods of the inhabitants of the Sanctuary.
   */
  HashMap<Food, Integer> getShoppingList();

  /**
   * print a string for assert.
   */
  String print();

  /**
   * expand the isolation numbers.
   */
  void expandIsolationNum();

  /**
   * expand the enclosure numbers.
   */
  void expandEnclosureNum();

  /**
   * print a sign for a given enclosure.
   */
  List<String> printSign(String enclosureId);
}
