import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import primate.Food;
import primate.Monkey;
import primate.Primate;
import primate.Species;
import sanctuary.Sanctuaries;
import sanctuary.Sanctuary;

/**
 * Driver Class for the sanctuary project.
 */
public class SanctuaryDriver {
  /**
   * Main function to drive the project.
   */
  public static void main(String[] args) {
    Sanctuaries sanctuaryN = new Sanctuary(3, 3, 5, 5);
    Primate monkey0 = new Monkey("cKingKong", Species.DRILL, "male", " ", 50, 25, 1, Food.FRUIT, 0);
    Primate monkey1 = new Monkey("bKingKong1", Species.DRILL, "female", " ",
            25, 15, 1, Food.EGGS, 1);
    Primate monkey2 = new Monkey("aKingKong2", Species.GUEREZA, "male", " ",
            50, 10, 1, Food.TREESAP, 2);
    Primate monkey3 = new Monkey("dKingKong3", Species.SAKI, "male", " ", 50,
            3, 1, Food.SEEDS, 3);
    Primate monkey4 = new Monkey("eKingKong4", Species.HOWLER, "male", " ", 50,
            4, 1, Food.INSECTS, 4);
    Primate monkey5 = new Monkey("aKingKong5", Species.GUEREZA, "male", " ", 50,
            10, 1, Food.TREESAP, 5);
    Primate monkey6 = new Monkey("bKingKong6", Species.SAKI, "female", " ", 50,
            3, 1, Food.NUTS, 6);

    System.out.println("Sanctuary Nick's Rescue created");
    System.out.println(sanctuaryN.print());
    System.out.println("------------------------------");
    sanctuaryN.addMonkey(monkey0);
    sanctuaryN.moveMonkey("enclosure0", monkey0);
    sanctuaryN.addMonkey(monkey1);
    sanctuaryN.moveMonkey("enclosure0", monkey1);
    sanctuaryN.addMonkey(monkey2);
    sanctuaryN.moveMonkey("enclosure1", monkey2);
    sanctuaryN.addMonkey(monkey3);
    sanctuaryN.addMonkey(monkey4);
    System.out.println("------------------------------");
    System.out.println("\nAdded 5 monkeys to sanctuary");
    System.out.println("\nReport all species");
    printHelper(sanctuaryN.getSpecies());
    System.out.println("\nReport one species");
    System.out.println(sanctuaryN.getTheSpecies(Species.DRILL));
    System.out.println(sanctuaryN.getTheSpecies(Species.GUEREZA));
    System.out.println(sanctuaryN.getTheSpecies(Species.SAKI));
    System.out.println(sanctuaryN.getTheSpecies(Species.HOWLER));
    System.out.println("\nReport all animals");
    System.out.println(sanctuaryN.getAnimals());
    System.out.println("\nReport the shopping list");
    System.out.println(sanctuaryN.getShoppingList());
    System.out.println("\nProduce a sign for enclosure");
    System.out.println(sanctuaryN.printSign("enclosure0"));
    System.out.println(sanctuaryN.printSign("enclosure1"));
    System.out.println("------------------------------");
    System.out.println("\nExpand the isolation to receive more monkey");
    sanctuaryN.expandIsolationNum();
    System.out.println(sanctuaryN.print());
    System.out.println(sanctuaryN.getAnimals());
    sanctuaryN.addMonkey(monkey5);
    System.out.println(sanctuaryN.getAnimals());
    System.out.println(sanctuaryN.print());
    System.out.println(sanctuaryN.getAnimals());
    System.out.println("\nMonkey 5 is exchanged to another sanctuary(medical condition)");
    sanctuaryN.exchangeMonkey(monkey5);
    System.out.println(sanctuaryN.getAnimals());
    System.out.println("\nExpand the enclosure to receive more monkey");
    sanctuaryN.expandEnclosureNum();
    System.out.println(sanctuaryN.print());
    System.out.println("------------------------------");
    System.out.println("\nExpand the isolation to receive more monkey");
    sanctuaryN.addMonkey(monkey6);
    sanctuaryN.moveMonkey("enclosure2", monkey4);
    sanctuaryN.moveMonkey("enclosure3", monkey6);
    System.out.println("\nReport all species");
    printHelper(sanctuaryN.getSpecies());
    System.out.println("\nReport one species");
    System.out.println(sanctuaryN.getTheSpecies(Species.DRILL));
    System.out.println(sanctuaryN.getTheSpecies(Species.GUEREZA));
    System.out.println(sanctuaryN.getTheSpecies(Species.SAKI));
    System.out.println(sanctuaryN.getTheSpecies(Species.HOWLER));
    System.out.println("\nReport all animals");
    System.out.println(sanctuaryN.getAnimals());
    System.out.println("\nReport the shopping list");
    System.out.println(sanctuaryN.getShoppingList());
    System.out.println("\nProduce a sign for enclosure");
    System.out.println(sanctuaryN.printSign("enclosure0"));
    System.out.println(sanctuaryN.printSign("enclosure1"));
    System.out.println(sanctuaryN.printSign("enclosure2"));
    System.out.println(sanctuaryN.printSign("enclosure3"));
    System.out.println("------------------------------");
    System.out.println("\nAnimal is injured, need to move back to isolation");
    sanctuaryN.moveMonkey("isolation1", monkey6);
    System.out.println("\nReport all species");
    printHelper(sanctuaryN.getSpecies());
    System.out.println("\nReport one species");
    System.out.println(sanctuaryN.getTheSpecies(Species.DRILL));
    System.out.println(sanctuaryN.getTheSpecies(Species.GUEREZA));
    System.out.println(sanctuaryN.getTheSpecies(Species.SAKI));
    System.out.println(sanctuaryN.getTheSpecies(Species.HOWLER));
    System.out.println("\nReport all animals");
    System.out.println(sanctuaryN.getAnimals());
    System.out.println("\nReport the shopping list");
    System.out.println(sanctuaryN.getShoppingList());
    System.out.println("\nProduce a sign for enclosure");
    System.out.println(sanctuaryN.printSign("enclosure0"));
    System.out.println(sanctuaryN.printSign("enclosure1"));
    System.out.println(sanctuaryN.printSign("enclosure2"));
    System.out.println(sanctuaryN.printSign("enclosure3"));
    System.out.println("------------------------------");
  }

  private static void printHelper(HashMap<Species, String> speciesMap) {
    TreeMap<Species, String> sorted = new TreeMap<>(speciesMap);

    for (Map.Entry<Species, String> entry : sorted.entrySet()) {
      System.out.println("Species is: " + entry.getKey()
              + ", Located at: " + entry.getValue());
    }

  }
}
