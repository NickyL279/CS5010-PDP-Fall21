package housing;

import primate.Primate;
import primate.Species;

/**
 * Isolation class that can hold one monkey.
 */
public class Isolation implements Housing {
  private final String isolationId;
  private Boolean canAccommodate = true;
  private Species species;

  /**
   * Creates a isolation object with the information about the isolation.
   *
   * @param id The id of the isolation.
   * @throws IllegalArgumentException If id is null.
   */
  public Isolation(String id) throws IllegalArgumentException {
    if (id == null) {
      throw new IllegalArgumentException("Isolation id cannot be null");
    }
    this.isolationId = id;
  }

  /**
   * Adds an animal to the isolation.
   *
   * @param primate The monkey object.
   * @throws IllegalArgumentException If animal is null.
   */
  @Override
  public void addAnimal(Primate primate) {
    if (primate == null) {
      throw new IllegalArgumentException("We don't take in null values.");
    }
    primate.setLocation(isolationId);
    canAccommodate = false;
    this.species = primate.getSpecies();
  }

  /**
   * remove an animal to the isolation.
   *
   * @param primate The monkey object.
   * @throws IllegalArgumentException If animal is null.
   */
  @Override
  public void removeAnimal(Primate primate) {
    if (primate == null) {
      throw new IllegalArgumentException("We don't take in null values.");
    }
    primate.setLocation(null);
    canAccommodate = true;
    this.species = null;
  }

  @Override
  public Boolean checkAvailability(Primate primate) {
    return canAccommodate;
  }

  @Override
  public Species getSpecies() {
    return this.species;
  }

  @Override
  public String getId() {
    return isolationId;
  }

  @Override
  public String printer() {
    if (species == null) {
      return String.format("this %s contains no animal", isolationId);
    }
    return String.format("this %s contains a %s", isolationId, species.toString());
  }
}
