package housing;

import primate.Primate;
import primate.Species;

/**
 * An interface called Housing.
 */
public interface Housing {
  /**
   * Adds a monkey.
   */
  void addAnimal(Primate primate);

  /**
   * remove a monkey.
   */
  void removeAnimal(Primate primate);

  /**
   * check housing availability.
   */
  Boolean checkAvailability(Primate primate);

  /**
   * get housing representing species.
   */
  Species getSpecies();

  /**
   * get housing id.
   */
  String getId();

  /**
   * print a String.
   */
  String printer();
}
