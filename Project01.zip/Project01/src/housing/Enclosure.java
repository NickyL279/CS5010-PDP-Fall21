package housing;

import java.util.ArrayList;
import java.util.List;
import primate.Primate;
import primate.Species;

/**
 * Enclosure class that can hold one troop.
 */
public class Enclosure implements Housing {
  private final String enclosureId;
  private Species species;
  private List<Primate> animals;
  private int enclosureSize;
  private int requireArea = 0;
  private Boolean canAccommodate = true;

  /**
   * Creates a enclosure object with the information about the enclosure.
   *
   * @param enclosureId The id of the enclosure.
   * @param area The room of the enclosure.
   * @param species The species of the enclosure.
   * @throws IllegalArgumentException If area is negative.
   */
  public Enclosure(String enclosureId, int area, Species species) throws IllegalArgumentException {
    if (enclosureId == null) {
      throw new IllegalArgumentException("id cannot be null");
    }
    if (area <= 0) {
      throw new IllegalArgumentException("housing amount greater than 0");
    }
    this.species = species;
    this.enclosureSize = area;
    this.animals = new ArrayList<>();
    this.enclosureId = enclosureId;
  }

  private int sizeHelper(Primate primate) {
    int size = primate.getSize();
    if (size < 10) {
      requireArea = 1;
    } else if (size > 10 && size < 20) {
      requireArea = 5;
    } else {
      requireArea = 10;
    }
    return requireArea;
  }

  @Override
  public void addAnimal(Primate primate) {
    if (checkAvailability(primate)) {
      animals.add(primate);
      enclosureSize -= sizeHelper(primate);
      primate.setLocation(enclosureId);
    }
  }

  @Override
  public void removeAnimal(Primate primate) {
    animals.remove(primate);
    enclosureSize += sizeHelper(primate);
    primate.setLocation(null);
    if (enclosureSize == 30) {
      this.species = null;
    }
  }

  @Override
  public Boolean checkAvailability(Primate primate) {
    requireArea = sizeHelper(primate);
    if ((primate.getSpecies() == this.species) && ((enclosureSize - requireArea) >= 0)) {
      canAccommodate = true;
    } else if ((primate.getSpecies() != this.species) && enclosureSize == 30) {
      this.species = primate.getSpecies();
      canAccommodate = true;
    } else if ((enclosureSize - requireArea) < 0) {
      canAccommodate = false;
    }
    return canAccommodate;
  }

  @Override
  public Species getSpecies() {
    return this.species;
  }

  @Override
  public String getId() {
    return enclosureId;
  }

  @Override
  public String printer() {
    if (species == null) {
      return String.format("this %s contains no animal", enclosureId);
    }
    return String.format("this %s contains %s species", enclosureId, species.toString());
  }

}
