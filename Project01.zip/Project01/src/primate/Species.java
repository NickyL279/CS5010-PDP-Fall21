package primate;

/**
 * Species class that contains all the species.
 */
public enum Species {
  DRILL,
  GUEREZA,
  HOWLER,
  MANGABEY,
  SAKI,
  SPIDER,
  SQUIRREL,
  TAMARIN;
}
