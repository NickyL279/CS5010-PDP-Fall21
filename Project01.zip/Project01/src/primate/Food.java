package primate;

/**
 * Food class that contains all the favorite foods.
 */
public enum Food {
  EGGS,
  FRUIT,
  INSECTS,
  LEAVES,
  NUTS,
  SEEDS,
  TREESAP;
}
