package primate;

/**
 * An interface called Primate.
 */
public interface Primate {
  /**
   * get name.
   */
  String getName();

  /**
   * get species.
   */
  Species getSpecies();

  /**
   * get sex.
   */
  String getSex();

  /**
   * get size.
   */
  int getSize();

  /**
   * get weight.
   */
  int getWeight();

  /**
   * get age.
   */
  int getAge();

  /**
   * get favorite food.
   */
  Food getFavFood();

  /**
   * get monkey location.
   */
  String getLocation();

  /**
   * set location.
   */
  void setLocation(String location);

  /**
   * get monkey id.
   */
  int getMonkeyId();

}
