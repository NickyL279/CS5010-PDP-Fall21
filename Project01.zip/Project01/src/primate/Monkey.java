package primate;

/**
 * Monkey class that contains all the monkey's information.
 */
public class Monkey implements Primate {
  private final String name;
  private final Species species;
  private final String sex;
  private final int weight;
  private final int size;
  private final int age;
  private final Food food;
  private final int monkeyId;
  private String location;

  /**
   * Creates a monkey object with the information about the monkey.
   *
   * @param name The name of the monkey.
   * @param species The species of the monkey.
   * @param sex The sex of the monkey.
   * @param location The location of the monkey.
   * @param weight The weight of the monkey.
   * @param size The size of the monkey.
   * @param age The age of the monkey.
   * @param food The food of the monkey.
   * @param monkeyId The monkeyId of the monkey.
   * @throws IllegalArgumentException If monkey's information is missing.
   * @throws IllegalArgumentException If monkey's information is empty.
   * @throws IllegalArgumentException If weight is lesser than 0.
   * @throws IllegalArgumentException If size is invalid.
   * @throws IllegalArgumentException If age is invalid.
   */
  public Monkey(String name, Species species, String sex, String location, int weight, int size,
                int age, Food food, int monkeyId) throws IllegalArgumentException {
    if (name == null || species == null || sex == null || location == null) {
      throw new IllegalArgumentException("info missing");
    }
    if (name.isEmpty() || sex.isEmpty() || location.isEmpty()) {
      throw new IllegalArgumentException("info is empty");
    }
    if (weight <= 0) {
      throw new IllegalArgumentException("weight invalid");
    }
    if (size <= 0 || size > 100) {
      throw new IllegalArgumentException("size invalid");
    }
    if (age < 0 || age > 62) {
      throw new IllegalArgumentException("age invalid");
    }
    this.name = name;
    this.species = species;
    this.sex = sex;
    this.location = location;
    this.weight = weight;
    this.size = size;
    this.age = age;
    this.food = food;
    this.monkeyId = monkeyId;
  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public Species getSpecies() {
    return this.species;
  }

  @Override
  public String getSex() {
    return this.sex;
  }

  @Override
  public int getSize() {
    return this.size;
  }

  @Override
  public int getWeight() {
    return this.weight;
  }

  @Override
  public int getAge() {
    return this.age;
  }

  @Override
  public Food getFavFood() {
    return food;
  }

  @Override
  public String getLocation() {
    return this.location;
  }

  @Override
  public void setLocation(String location) {
    this.location = location;
  }

  @Override
  public int getMonkeyId() {
    return monkeyId;
  }

  @Override
  public String toString() {
    return String.format("the %s, a monkey is a %s %s in %s."
                    + " It is %d big, weight %d, %d old"
                    + " Its favorite food is %s",
            name, sex, species.toString(), location, size, weight, age, food.toString());
  }
}