package test;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import primate.Food;
import primate.Monkey;
import primate.Primate;
import primate.Species;

/**
 * Test monkey class.
 */
public class MonkeyTest {
  private Primate kingKong;

  /**
   * setup monkeys.
   */
  @Before
  public void setUp() {
    kingKong = setMonkey("kingKong1", Species.DRILL, "male", "isolation1", 50, 15, 1, Food.SEEDS,
            0);
  }

  /**
   * This method is providing short-hand way of creating instances of a new Monkey object.
   *
   * @param name     The name of the monkey.
   * @param species  The species of the monkey.
   * @param sex      The sex of the monkey.
   * @param location The location of the monkey.
   * @param weight   The weight of the monkey.
   * @param size     The size of the monkey.
   * @param age      The age of the monkey.
   * @param food     The food of the monkey.
   * @param monkeyId The monkeyId of the monkey.
   */
  protected Primate setMonkey(String name, Species species, String sex, String location, int weight,
                              int size, int age, Food food, int monkeyId) {
    return new Monkey(name, species, sex, location, weight, size, age, food, monkeyId);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNull() {
    setMonkey(null, Species.DRILL, "male", "isolation1", 50, 15, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", null, "male", "isolation1", 50, 15, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, null, "isolation1", 50, 15, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "male", null, 50, 15, 1, Food.SEEDS, 0);
    setMonkey("", Species.DRILL, "male", "isolation1", 50, 15, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "", "isolation1", 50, 15, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "male", "", 50, 15, 1, Food.SEEDS, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalid() {
    setMonkey("kingKong1", Species.DRILL, "male", "isolation1", 50, -1, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "male", "isolation1", 50, 101, 1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "male", "isolation1", 50, 15, -1, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "male", "isolation1", 50, 15, 67, Food.SEEDS, 0);
    setMonkey("kingKong1", Species.DRILL, "male", "isolation1", -1, 15, 67, Food.SEEDS, 0);
  }

  @Test
  public void testGetName() {
    assertEquals("kingKong1", kingKong.getName());
  }

  @Test
  public void testGetSpecies() {
    assertEquals(Species.DRILL, kingKong.getSpecies());
  }

  @Test
  public void testGetSex() {
    assertEquals("male", kingKong.getSex());
  }

  @Test
  public void testGetSize() {
    assertEquals(15, kingKong.getSize());
  }

  @Test
  public void testGetWeight() {
    assertEquals(50, kingKong.getWeight());
  }

  @Test
  public void testGetAge() {
    assertEquals(1, kingKong.getAge());
  }

  @Test
  public void testGetFavoriteFood() {
    assertEquals(Food.SEEDS, kingKong.getFavFood());
  }

  @Test
  public void testGetLocation() {
    assertEquals("isolation1", kingKong.getLocation());
  }

  @Test
  public void testGetId() {
    assertEquals(0, kingKong.getMonkeyId());
  }
}
