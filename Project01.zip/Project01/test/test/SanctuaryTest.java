package test;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import primate.Food;
import primate.Monkey;
import primate.Primate;
import primate.Species;
import sanctuary.Sanctuaries;
import sanctuary.Sanctuary;

/**
 * Test sanctuary class.
 */
public class SanctuaryTest {
  private Sanctuaries sanctuaryN;
  private Primate kingKong;
  private Primate kingKong1;
  private Primate kingKong2;
  private Primate kingKong3;

  /**
   * setup sanctuary and monkeys.
   */
  @Before
  public void setUp() {
    sanctuaryN = setSanctuary(3, 3, 5, 5);
    kingKong = setMonkey("kingKong1", Species.DRILL, "male", " ", 50, 15, 1, Food.SEEDS,
            0);
    kingKong1 = setMonkey("kingKong2", Species.DRILL, "male", " ", 50, 30, 1, Food.SEEDS,
            0);
    kingKong2 = setMonkey("kingKong3", Species.GUEREZA, "female", " ", 20, 30, 1, Food.TREESAP,
            0);
    kingKong3 = setMonkey("kingKong4", Species.GUEREZA, "female", " ", 20, 30, 1, Food.TREESAP,
            0);
  }

  /**
   * This method is providing short-hand way of creating instances of a new Monkey object.
   *
   * @param enclosureAmount    The enclosure amount.
   * @param isolationAmount    The isolation amount.
   * @param enclosureMaxAmount The max enclosure amount.
   * @param isolationMaxAmount The max isolation amount.
   */
  protected Sanctuaries setSanctuary(int enclosureAmount, int isolationAmount,
                                     int enclosureMaxAmount, int isolationMaxAmount) {
    return new Sanctuary(enclosureAmount, isolationAmount, enclosureMaxAmount, isolationMaxAmount);
  }

  /**
   * This method is providing short-hand way of creating instances of a new Monkey object.
   *
   * @param name     The name of the monkey.
   * @param species  The species of the monkey.
   * @param sex      The sex of the monkey.
   * @param location The location of the monkey.
   * @param weight   The weight of the monkey.
   * @param size     The size of the monkey.
   * @param age      The age of the monkey.
   * @param food     The food of the monkey.
   * @param monkeyId The monkeyId of the monkey.
   */
  protected Primate setMonkey(String name, Species species, String sex, String location, int weight,
                              int size, int age, Food food, int monkeyId) {
    return new Monkey(name, species, sex, location, weight, size, age, food, monkeyId);
  }

  @Test
  public void testSanctuary() {
    assertEquals("There are 3 isolations (isolation0; isolation1; isolation2;) and 3 "
            + "enclosures (enclosure0; enclosure1; enclosure2;). ", sanctuaryN.print());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidSanctuary() {
    setSanctuary(0, 3, 5, 5);
    setSanctuary(3, 0, 5, 5);
    setSanctuary(3, 3, 0, -1);
    setSanctuary(6, 3, 5, 5);
  }

  @Test
  public void testExpand() {
    sanctuaryN.expandIsolationNum();
    assertEquals("There are 4 isolations (isolation0; isolation1; isolation2; isolation3;) "
                    + "and 3 enclosures (enclosure0; enclosure1; enclosure2;). "
            , sanctuaryN.print());
    sanctuaryN.expandEnclosureNum();
    assertEquals("There are 4 isolations (isolation0; isolation1; isolation2; isolation3;) "
                    + "and 4 enclosures (enclosure0; enclosure1; enclosure2; enclosure3;). ",
            sanctuaryN.print());
  }

  @Test
  public void testAddMonkey() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    sanctuaryN.addMonkey(kingKong2);
    assertEquals("There are 3 isolations (isolation0; isolation1; isolation2;) and "
            + "3 enclosures (enclosure0; enclosure1; enclosure2;). The monkeys "
            + "are the kingKong1, a monkey is a male DRILL in isolation0. It is "
            + "15 big, weight 50, 1 old Its favorite food is SEEDS. the kingKong2"
            + ", a monkey is a male DRILL in isolation1. It is 30 big, weight "
            + "50, 1 old Its favorite food is SEEDS. the kingKong3, a monkey is a female "
            + "GUEREZA in isolation2. It is 30 big, weight 20, 1 old Its "
            + "favorite food is TREESAP.", sanctuaryN.print());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidAdding() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    sanctuaryN.addMonkey(kingKong2);
    sanctuaryN.addMonkey(kingKong3);
  }

  @Test
  public void testExchangeMonkey() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.exchangeMonkey(kingKong);
    assertEquals("There are 3 isolations (isolation0; isolation1; isolation2;) and "
                    + "3 enclosures (enclosure0; enclosure1; enclosure2;). ",
            sanctuaryN.print());
  }

  @Test
  public void testMoveMonkey() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.moveMonkey("enclosure1", kingKong);
    assertEquals("There are 3 isolations (isolation0; isolation1; isolation2;) and 3 enclosures"
                    + " (enclosure0; enclosure1; enclosure2;). The monkeys are the kingKong1,"
                    + " a monkey is a male DRILL in enclosure1. It is 15 big, weight 50,"
                    + " 1 old Its favorite food is SEEDS.",
            sanctuaryN.print());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoving() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    sanctuaryN.addMonkey(kingKong2);
    sanctuaryN.addMonkey(kingKong3);
    sanctuaryN.moveMonkey("enclosure20", kingKong);
    sanctuaryN.moveMonkey("enclosure0", kingKong);
    sanctuaryN.moveMonkey("enclosure0", kingKong1);
    sanctuaryN.moveMonkey("enclosure0", kingKong2);
    sanctuaryN.moveMonkey("enclosure0", kingKong3);
  }

  @Test
  public void testMoveBackToIso() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.moveMonkey("enclosure1", kingKong);
    sanctuaryN.moveMonkey("isolation2", kingKong);
    assertEquals("There are 3 isolations (isolation0; isolation1; isolation2;) and "
                    + "3 enclosures (enclosure0; enclosure1; enclosure2;). The monkeys are "
                    + "the kingKong1, a monkey is a male DRILL in isolation2. It is 15 big, "
                    + "weight 50, 1 old Its favorite food is SEEDS.",
            sanctuaryN.print());
  }

  @Test
  public void testGetSpecies() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    sanctuaryN.moveMonkey("enclosure1", kingKong1);
    assertEquals("{DRILL=isolation0enclosure1}", sanctuaryN.getSpecies().toString());
  }

  @Test
  public void testGetTheSpecies() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    assertEquals("[DRILL isolation0, DRILL isolation1]",
            sanctuaryN.getTheSpecies(Species.DRILL).toString());

  }

  @Test
  public void testGetAnimals() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    assertEquals("[kingKong1 isolation0, kingKong2 isolation1]", sanctuaryN.getAnimals()
            .toString());
  }

  @Test
  public void testGetShoppingList() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    assertEquals("{SEEDS=750}", sanctuaryN.getShoppingList().toString());
  }

  @Test
  public void testGetSign() {
    sanctuaryN.addMonkey(kingKong);
    sanctuaryN.addMonkey(kingKong1);
    sanctuaryN.moveMonkey("enclosure1", kingKong);
    sanctuaryN.moveMonkey("enclosure1", kingKong1);
    assertEquals("[kingKong1 male SEEDS, kingKong2 male SEEDS]", sanctuaryN
            .printSign("enclosure1").toString());

  }
}
