package test;

import org.junit.Before;
import org.junit.Test;

import housing.Housing;
import housing.Isolation;
import primate.Food;
import primate.Monkey;
import primate.Primate;
import primate.Species;
import sanctuary.Sanctuaries;
import sanctuary.Sanctuary;

import static org.junit.Assert.assertEquals;

/**
 * Class for testing the Isolation class.
 */
public class IsolationTest {
  private Housing isolation1;
  private Primate kingKong;
  private Primate kingKong2;

  /**
   * setup isolations.
   */
  @Before
  public void setUp() {
    Sanctuaries sanctuaryN = setSanctuary(3, 3, 5, 5);
    kingKong = setMonkey("kingKong1", Species.DRILL, "male", " ", 50, 15, 1, Food.SEEDS,
            0);
    kingKong2 = setMonkey("kingKong3", Species.GUEREZA, "female", " ", 20, 10, 1, Food.TREESAP,
            0);
    isolation1 = setIsolation("isolation0");
  }

  /**
   * This method is providing short-hand way of creating instances of a new sanctuary object.
   *
   * @param enclosureAmount    the enclosure amount
   * @param isolationAmount    the isolation amount
   * @param enclosureMaxAmount the enclosure max amount
   * @param isolationMaxAmount the isolation max amount
   * @return a new instance of a sanctuary object
   */
  protected Sanctuaries setSanctuary(int enclosureAmount, int isolationAmount,
                                     int enclosureMaxAmount, int isolationMaxAmount) {
    return new Sanctuary(enclosureAmount, isolationAmount, enclosureMaxAmount, isolationMaxAmount);
  }

  /**
   * This method is providing short-hand way of creating instances of a new Enclosure object.
   *
   * @param isolationId the isolation id
   * @return a new instance of a Isolation object
   */
  protected Housing setIsolation(String isolationId) {
    return new Isolation(isolationId);
  }

  /**
   * This method is providing short-hand way of creating instances of a new Monkey object.
   *
   * @param name     The name of the monkey.
   * @param species  The species of the monkey.
   * @param sex      The sex of the monkey.
   * @param location The location of the monkey.
   * @param weight   The weight of the monkey.
   * @param size     The size of the monkey.
   * @param age      The age of the monkey.
   * @param food     The food of the monkey.
   * @param monkeyId The monkeyId of the monkey.
   */
  protected Primate setMonkey(String name, Species species, String sex, String location, int weight,
                              int size, int age, Food food, int monkeyId) {
    return new Monkey(name, species, sex, location, weight, size, age, food, monkeyId);
  }

  @Test
  public void testAddAnimal() {
    isolation1.addAnimal(kingKong);
    assertEquals("this isolation0 contains a DRILL", isolation1.printer());
  }

  @Test
  public void testRemoveAnimal() {
    isolation1.addAnimal(kingKong);
    isolation1.removeAnimal(kingKong);
    assertEquals("this isolation0 contains no animal", isolation1.printer());
  }

  @Test
  public void testGetSpecies() {
    isolation1.addAnimal(kingKong2);
    assertEquals("this isolation0 contains a GUEREZA", isolation1.printer());
  }
}
