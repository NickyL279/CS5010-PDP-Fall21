CS5010_Project1
=
Creates a sanctuary program for the Jungle Friends Sanctuary.

Overview:
-
The Jungle Friends Primate Sanctuary (Links to an external site.) provides a permanent home and
high-quality sanctuary care for New World primates who have been cast-off from the pet trade,
retired from research, or confiscated by authorities. They are seeking to replace all of their paper
records with computer records where they can keep track of the individual animals that are in their
care.

Features:
-
Generate n isolations and m enclosures Print a list of the enclosure and isolation names in the
sanctuary Add monkeys to the sanctuary, first the monkey stays in an isolation and then move it to
enclosure or exchange it If an enclosure is empty and can be repurposed to house a different species
then you can do that Generates a report of the monkeys in the sanctuary with their Name and Species
Generates a report of a given species of monkey with its locations Generates a report of the
shopping list for the monkeys with the weight of each monkeys favorite food in grams Generates a
sign of the monkeys in an enclosuree, specifically their name, sex and favorite food

How To Run:
-
This program is not interactive, so simply open the Project_01.jar in your IDE, and run it.

How to Use the Program
-
This program is not interactive, so simply open the Project_01.jar in your IDE, and run it.

Description of Examples
-
Run 1 -- ExampleRun1.txt:

1. initialize sanctuary
2. add monkeys to sanctuary and move them around
3. print all the reports

Design/Model Changes
-
I re-design my most of my project compared with the original design. When I create my initial
design, there are many parts we were not introduced. We did not have many materials regarding this
project. So I did not design it well and got some deduction on the first design. My current design
still have ENUM types, the reason of them I introduced in my assumption part. After analyzing the
description thoroughly, I made my final design and implemented it.

Assumptions
-
In this project, I assume that there are n isolation and m enclosures in the sanctuary. When we get
a monkey, it will be add to isolation first (if isolations are full, we cannot receive it). Then if
there is room in an enclosure, we can move the monkey there
(monkey will be maually move to enclosure since we cannot determine when the monkey should get out
isolation.). In addition, I assume the isolations and enclosures names are correct as they are
documented by professionals. And the Monkeys do not have duplicate name since it will be hard for
workers to identify them. And The food and species are enum since I don't think they should be easy
to change for users, the foods are limited for monkeys, if we give new food without identifying, it
could cause fetal damage to monkeys. For the species, I don't think we can easily add new species as
well. The sanctuary has limited experience, so I only kept those species.

Limitations
-
This program limits the number of possible enclosures or isolations by setting the max amount since
sanctuary has limited power. This program limits the species and food, I explained the reason above.

Citations
-
CSDN, https://www.csdn.net/. Stack Overflow, https://stackoverflow.com/.
Geeksforgeeks, https://www.geeksforgeeks.org/. Google, https://www.google.com/.
