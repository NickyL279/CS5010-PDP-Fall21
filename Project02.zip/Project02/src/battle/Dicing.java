package battle;

/**
 * This interface represents a dicing process in a turn-based game.
 */
public interface Dicing {
  int randomNum(int min, int max);

  int randomNumSeeded(int min, int max, int seed);

  int randomNumSingle(int min, int max);

  int randomNumSingleSeeded(int min, int max, int seed);
}
