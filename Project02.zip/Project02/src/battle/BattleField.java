package battle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import character.Characters;
import gear.Gear;
import weapon.Weapon;
import weapon.WeaponType;

/**
 * This class represents a battlefield in a turn-based game. It offers all the operations
 * mandated by the battle interface.
 */
public class BattleField implements Battle {
  private final Characters firstPlayer;
  private final Characters secondPlayer;
  private final int maxHeadGear;
  private final int maxFootWear;
  private final int maxBelt;
  private final int maxPotion;
  private final List<Gear> headGears;
  private final List<Gear> footWears;
  private final List<Gear> belts;
  private final List<Gear> potions;
  private final List<Gear> gearBag;
  private List<Weapon> armory;
  private List<Weapon> weaponBag;
  private int round;
  private List<String> hitRecords;
  private String hitRecord;
  private String status;
  private String healthStatus;
  private boolean battleFlag;
  private int notHitCount;

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param playerOne   player one
   * @param playerTwo   player two
   * @param maxHeadGear max amount of head gear
   * @param maxBelt     max amount of belt gear
   * @param maxFootWear max amount of foot gear
   * @param maxPotion   max amount of potion gear
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public BattleField(Characters playerOne, Characters playerTwo, int maxHeadGear,
                     int maxFootWear, int maxBelt, int maxPotion) throws IllegalArgumentException {
    this.maxHeadGear = maxHeadGear;
    this.maxFootWear = maxFootWear;
    this.maxBelt = maxBelt;
    this.maxPotion = maxPotion;
    this.status = "No winner yet";
    this.healthStatus = "";
    if (playerOne == null || playerTwo == null) {
      throw new IllegalArgumentException("Characters can't be null");
    }
    if (maxHeadGear < 5) {
      throw new IllegalArgumentException("Head's minimum number is 5.");
    }
    if (maxFootWear < 5) {
      throw new IllegalArgumentException("Foot's minimum number is 5.");
    }
    if (maxBelt < 15) {
      throw new IllegalArgumentException("Belt's minimum number is 15.");
    }
    if (maxPotion < 15) {
      throw new IllegalArgumentException("Potion's minimum number is 15.");
    }
    if (playerOne.getCharisma() >= playerTwo.getCharisma()) {
      firstPlayer = playerOne;
      secondPlayer = playerTwo;
    } else {
      firstPlayer = playerTwo;
      secondPlayer = playerOne;
    }
    this.round = 0;
    headGears = new ArrayList<>();
    footWears = new ArrayList<>();
    belts = new ArrayList<>();
    potions = new ArrayList<>();
    gearBag = new ArrayList<>();
    armory = new ArrayList<>();
    weaponBag = new ArrayList<>();
    hitRecords = new ArrayList<>();
    hitRecord = "";
    this.battleFlag = false;
    this.notHitCount = 0;
  }

  @Override
  public boolean getBattleFlag() {
    return battleFlag;
  }

  @Override
  public void addHeadGear(Gear headGear) {
    if (headGears.size() == maxHeadGear) {
      throw new IllegalArgumentException("Max amount of head gears reached");
    }
    headGears.add(headGear);
  }

  @Override
  public void addFootWear(Gear o) {
    if (footWears.size() == maxFootWear) {
      throw new IllegalArgumentException("Max amount of head gears reached");
    }
    footWears.add(o);
  }

  @Override
  public void addBelt(Gear o) {
    if (belts.size() == maxBelt) {
      throw new IllegalArgumentException("Max amount of head gears reached");
    }
    belts.add(o);
  }

  @Override
  public void addPotion(Gear o) {
    if (potions.size() == maxPotion) {
      throw new IllegalArgumentException("Max amount of head gears reached");
    }
    potions.add(o);
  }

  @Override
  public void addWeapon(Weapon weapon) {
    armory.add(weapon);
  }

  @Override
  public List<Gear> getHeadList() {
    return headGears;
  }

  @Override
  public List<Gear> getFootList() {
    return footWears;
  }

  @Override
  public List<Gear> getPotionList() {
    return potions;
  }

  @Override
  public List<Gear> getBeltList() {
    return belts;
  }


  @Override
  public Characters getCurPlayer() {
    if (round % 2 == 0) {
      return firstPlayer;
    }
    return secondPlayer;
  }

  @Override
  public Characters getNextPlayer() {
    if (round % 2 == 0) {
      return secondPlayer;
    }
    return firstPlayer;
  }

  @Override
  public void attack() throws IllegalArgumentException {
    Characters curPlayer = getCurPlayer();
    Characters nextPlayer = getNextPlayer();
    healthStatus = "";
    if (notHitCount >= 300 && round >= 400) {
      throw new IllegalArgumentException("This is a draw");
    }
    if (!battleFlag) {
      //hit
      if (curPlayer.getStrikingPower() > nextPlayer.getAvoidance()) {
        hitRecord = "Round" + (round + 1) + " " + curPlayer.getName() + " " + "hit";
        if ((curPlayer.getPotentialDamage() - nextPlayer.getFinalConstitution()) > 0) {
          nextPlayer.getRealTimeHealth(curPlayer.getPotentialDamage()
                  - nextPlayer.getFinalConstitution());
          healthStatus = nextPlayer.getName() + " " + nextPlayer.getCurHealth()
                  + " (" + nextPlayer.getHealth() + ")";
          if (nextPlayer.getCurHealth() <= 0) {
            nextPlayer.setLifeFlag(false);
          }
        } else {
          healthStatus = nextPlayer.getName() + " " + nextPlayer.getCurHealth()
                  + " (" + nextPlayer.getHealth() + ")";
        }
      } else { //not hit
        hitRecord = "Round" + (round + 1) + " " + curPlayer.getName() + " " + "not hit";
        healthStatus = nextPlayer.getName() + " " + nextPlayer.getCurHealth() + " ("
                + nextPlayer.getHealth() + ")";
        notHitCount++;
      }
      hitRecords.add(hitRecord);
      status = this.getWinner(curPlayer, nextPlayer);
      round++;
    } else {
      status = this.getWinner(curPlayer, nextPlayer);
    }
  }

  @Override
  public String getHitRecords() {
    return hitRecords.get(round - 1);
  }

  @Override
  public String getStatus() {
    return status;
  }

  @Override
  public String getHealthStatus() {
    return healthStatus;
  }

  @Override
  public void setUpRematch(boolean b) {
    if (b) {
      firstPlayer.rematch();
      secondPlayer.rematch();
      round = 0;
      hitRecords.clear();
      battleFlag = false;
      firstPlayer.setLifeFlag(true);
      secondPlayer.setLifeFlag(true);
      notHitCount = 0;
    }
  }

  @Override
  public String getWinner(Characters curPlayer, Characters nextPlayer) {
    if (!curPlayer.getLifeFlag()) {
      battleFlag = true;
      return nextPlayer.getName() + " wins";
    } else if (!nextPlayer.getLifeFlag()) {
      battleFlag = true;
      return curPlayer.getName() + " wins";
    }
    return "No winner yet";
  }

  @Override
  public int getRound() {
    return round;
  }

  @Override
  public void buildArmory() throws IllegalArgumentException {
    if (armory.size() == 0) {
      throw new IllegalArgumentException("Armory cannot be empty");
    }
    boolean swordFlag = false;
    boolean axesFlag = false;
    boolean flailsFlag = false;
    for (Weapon w : armory) {
      if (w.getWeaponType() == WeaponType.SWORDS) {
        swordFlag = true;
      } else if (w.getWeaponType() == WeaponType.AXES) {
        axesFlag = true;
      } else if (w.getWeaponType() == WeaponType.FLAILS) {
        flailsFlag = true;
      }
    }
    if (!swordFlag) {
      throw new IllegalArgumentException("No swords");
    }
    if (!axesFlag) {
      throw new IllegalArgumentException("No axes");
    }
    if (!flailsFlag) {
      throw new IllegalArgumentException("No flails");
    }
    weaponBag.clear();
    weaponBag.addAll(armory);
  }

  @Override
  public void buildGearBag() throws IllegalArgumentException {
    if (headGears.size() < 5) {
      throw new IllegalArgumentException("Minimum number of head gears not added");
    }
    if (footWears.size() < 5) {
      throw new IllegalArgumentException("Minimum number of foot gears not added");
    }
    if (belts.size() < 15) {
      throw new IllegalArgumentException("Minimum number of belts not added");
    }
    if (potions.size() < 15) {
      throw new IllegalArgumentException("Minimum number of potions not added");
    }
    gearBag.clear();
    gearBag.addAll(headGears);
    gearBag.addAll(potions);
    gearBag.addAll(belts);
    gearBag.addAll(footWears);
    Collections.sort(gearBag);
  }

  @Override
  public List<Gear> getGearBag() {
    return gearBag;
  }

  @Override
  public List<Weapon> getArmory() {
    return armory;
  }

  @Override
  public void dressPlayer() {
    int gearAmount = 0;
    int weaponAmount = 0;
    Random rand = new Random();
    while (gearAmount < 20) {
      int which = rand.nextInt(gearBag.size());
      firstPlayer.gearUp(gearBag.get(which));
      gearBag.remove(gearBag.get(which));
      gearAmount++;
    }
    while (weaponAmount < armory.size()) {
      int which = rand.nextInt(armory.size());
      firstPlayer.weaponUp(armory.get(which), firstPlayer);
      armory.remove(armory.get(which));
      weaponAmount++;
    }
  }

  @Override
  public void dressSecondPlayer() {
    int gearAmount = 0;
    int weaponAmount = 0;
    Random rand = new Random();
    while (gearAmount < 20) {
      int which = rand.nextInt(gearBag.size());
      secondPlayer.gearUp(gearBag.get(which));
      gearBag.remove(gearBag.get(which));
      gearAmount++;
    }
    while (weaponAmount < armory.size()) {
      int which = rand.nextInt(armory.size());
      secondPlayer.weaponUp(armory.get(which), secondPlayer);
      armory.remove(armory.get(which));
      weaponAmount++;
    }
  }
}

