package battle;

import java.util.List;

import character.Characters;
import gear.Gear;
import weapon.Weapon;

/**
 * This interface represents a battle in a turn-based game.
 */
public interface Battle {
  /**
   * Adds head gear to battle.
   *
   * @param o headgear object
   */
  void addHeadGear(Gear o);

  /**
   * Adds hand gear to battle.
   *
   * @param o footgear object
   */
  void addFootWear(Gear o);

  /**
   * Adds belt to battle.
   *
   * @param o belt object
   */
  void addBelt(Gear o);

  /**
   * Adds potion to battle.
   *
   * @param o potion object
   */
  void addPotion(Gear o);

  void addWeapon(Weapon weapon);

  Characters getCurPlayer();

  Characters getNextPlayer();

  void attack();

  String getWinner(Characters curPlayer, Characters nextPlayer);

  List<Gear> getHeadList();

  List<Gear> getFootList();

  List<Gear> getPotionList();

  List<Gear> getBeltList();

  List<Gear> getGearBag();

  void buildGearBag();

  List<Weapon> getArmory();

  void buildArmory();

  void dressPlayer();

  void dressSecondPlayer();

  int getRound();

  String getHitRecords();

  String getStatus();

  String getHealthStatus();

  void setUpRematch(boolean b);

  boolean getBattleFlag();
}
