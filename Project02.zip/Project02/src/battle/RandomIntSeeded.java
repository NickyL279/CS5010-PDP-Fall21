package battle;

import java.util.Arrays;
import java.util.Random;

/**
 * This class represents a dicing process in a turn-based game. It offers all the operations
 * mandated by the dicing interface.
 */
public class RandomIntSeeded implements Dicing {
  private int min = 0;
  private int max = 0;
  private Random ran = new Random();
  private int seed;

  /**
   * The constructor of random number class.
   */
  public RandomIntSeeded() {
  // This constructor don't need to do anything! The class offers different kind of random numbers.
  }

  @Override
  public int randomNum(int min, int max) {
    int r1 = min + ran.nextInt(max - min);
    int r2 = min + ran.nextInt(max - min);
    int r3 = min + ran.nextInt(max - min);
    int r4 = min + ran.nextInt(max - min);
    int[] roll = {r1, r2, r3, r4};
    Arrays.sort(roll);
    return roll[3] + roll[2] + roll[1];
  }

  @Override
  public int randomNumSeeded(int min, int max, int seed) {
    int r1 = min + ran.nextInt(max - min);
    int r2 = min + ran.nextInt(max - min);
    int r3 = min + ran.nextInt(max - min);
    int r4 = min + ran.nextInt(max - min);
    ran.setSeed(seed);
    int[] roll = {r1, r2, r3, r4};
    Arrays.sort(roll);
    return roll[3] + roll[2] + roll[1];
  }

  @Override
  public int randomNumSingle(int min, int max) {
    return min + ran.nextInt(max - min);
  }

  @Override
  public int randomNumSingleSeeded(int min, int max, int seed) {
    ran.setSeed(seed);
    return min + ran.nextInt(max - min);
  }
}

