package character;

import gear.Gear;
import weapon.Weapon;

/**
 * This interface represents a character in a turn-based game.
 */
public interface Characters {

  String getName();

  int getStrength();

  int getConstitution();

  int getDexterity();

  int getCharisma();

  int getHealth();

  int getStrikingPower();

  int getAvoidance();

  int getPotentialDamage();

  void gearUp(Gear gear);

  void weaponUp(Weapon weapon, Characters characters);

  int getFinalStrength();

  int getFinalConstitution();

  int getFinalDexterity();

  int getFinalCharisma();

  int getCurHealth();

  void getRealTimeHealth(int damage);

  void rematch();

  boolean getLifeFlag();

  void setLifeFlag(boolean b);
}
