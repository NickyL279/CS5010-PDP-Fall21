package character;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import battle.Dicing;
import battle.RandomIntSeeded;
import gear.AbstractGear;
import gear.Belt;
import gear.FootWear;
import gear.Gear;
import gear.HeadGear;
import gear.Potion;
import weapon.Weapon;

/**
 * This class represents a character in a turn-based game. It offers all the operations
 * mandated by the characters interface.
 */
public class Character implements Characters {
  private final String name;
  private final int strength;
  private final int constitution;
  private final int dexterity;
  private final int charisma;
  Dicing r1 = new RandomIntSeeded();
  boolean weaponFlag = false;
  boolean lifeFlag = true;
  private List<AbstractGear> headGears;
  private List<AbstractGear> potions;
  private List<AbstractGear> belts;
  private List<AbstractGear> footWears;
  private List<Weapon> weapons;
  private int finalStrength;
  private int finalConstitution;
  private int finalDexterity;
  private int finalCharisma;
  private int beltSpace;
  private int potentialDamage;
  private int health;
  private int curHealth;
  private int damage;

  /**
   * The constructor of the Character class.
   *
   * @param name         character name
   * @param constitution the character's constitution
   * @param charisma     the character's charisma
   * @param strength     the character's strength
   * @param dexterity    the character's dexterity
   * @throws IllegalArgumentException if the character name is null.
   * @throws IllegalArgumentException if the character name is empty.
   * @throws IllegalArgumentException if the character's attributes are all 0.
   */
  public Character(String name, int strength, int dexterity, int constitution, int charisma)
          throws IllegalArgumentException {
    this.strength = strength;
    this.constitution = constitution;
    this.dexterity = dexterity;
    this.charisma = charisma;
    this.finalStrength = strength;
    this.finalConstitution = constitution;
    this.finalDexterity = dexterity;
    this.finalCharisma = charisma;
    this.beltSpace = 10;
    this.health = finalStrength + finalDexterity + finalCharisma + finalConstitution;
    this.curHealth = health;
    headGears = new ArrayList<>();
    potions = new ArrayList<>();
    belts = new ArrayList<>();
    footWears = new ArrayList<>();
    weapons = new ArrayList<>();
    this.damage = 0;
    if (name == null) {
      throw new IllegalArgumentException("Character name is null");
    }
    if (name.trim().isEmpty()) {
      throw new IllegalArgumentException("Character name is empty");
    }
    if (strength <= 0 || constitution <= 0 || charisma <= 0 || dexterity <= 0) {
      throw new IllegalArgumentException("Character's attribute is invalid");
    }
    this.name = name.trim().toLowerCase();
  }

  /**
   * The constructor of the Character class.
   *
   * @param name         character name
   * @throws IllegalArgumentException if the character name is null.
   * @throws IllegalArgumentException if the character name is empty.
   * @throws IllegalArgumentException if the character's attributes are all 0.
   */
  public Character(String name) throws IllegalArgumentException {
    this.strength = r1.randomNum(2, 6);
    this.constitution = r1.randomNum(2, 6);
    this.dexterity = r1.randomNum(2, 6);
    this.charisma = r1.randomNum(2, 6);
    this.finalStrength = strength;
    this.finalConstitution = constitution;
    this.finalDexterity = dexterity;
    this.finalCharisma = charisma;
    this.beltSpace = 10;
    this.health = finalStrength + finalDexterity + finalCharisma + finalConstitution;
    this.curHealth = health;
    headGears = new ArrayList<>();
    potions = new ArrayList<>();
    belts = new ArrayList<>();
    footWears = new ArrayList<>();
    weapons = new ArrayList<>();
    this.damage = 0;
    if (name == null) {
      throw new IllegalArgumentException("Character name is null");
    }
    if (name.trim().isEmpty()) {
      throw new IllegalArgumentException("Character name is empty");
    }
    if (strength <= 0 || constitution <= 0 || charisma <= 0 || dexterity <= 0) {
      throw new IllegalArgumentException("Character's attribute is invalid");
    }
    this.name = name.trim().toLowerCase();
  }

  /**
   * Returns the name of the character.
   *
   * @return name
   */
  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getStrength() {
    return strength;
  }

  @Override
  public int getConstitution() {
    return constitution;
  }

  @Override
  public int getDexterity() {
    return dexterity;
  }

  @Override
  public int getCharisma() {
    return charisma;
  }

  @Override
  public int getFinalStrength() {
    return finalStrength;
  }

  @Override
  public int getFinalConstitution() {
    return finalConstitution;
  }

  @Override
  public int getFinalDexterity() {
    return finalDexterity;
  }

  @Override
  public int getFinalCharisma() {
    return finalCharisma;
  }

  /**
   * Returns the hp of the character.
   *
   * @return defense
   */
  @Override
  public int getHealth() {
    return health;
  }

  /**
   * Returns the striking power of the character.
   *
   * @return attack
   */
  @Override
  public int getStrikingPower() {
    return finalStrength + r1.randomNumSingle(1, 10);
  }

  @Override
  public int getAvoidance() {
    return finalDexterity + r1.randomNumSingle(1, 6);
  }

  @Override
  public int getPotentialDamage() {
    return finalStrength + damage;
  }

  @Override
  public int getCurHealth() {
    return curHealth;
  }

  @Override
  public void getRealTimeHealth(int damage) {
    curHealth -= damage;
  }

  @Override
  public void rematch() {
    curHealth = health;
  }

  @Override
  public boolean getLifeFlag() {
    return lifeFlag;
  }

  @Override
  public void setLifeFlag(boolean b) {
    lifeFlag = b;
  }

  @Override
  public void weaponUp(Weapon weapon, Characters characters) {
    if (!weaponFlag) {
      weapons.add(weapon);
      damage += weapon.getDamage(characters);
      weaponFlag = true;
    } else if (weaponFlag && weapon.checkType() && weapons.get(0).checkType()) {
      if (weapon.checkType()) {
        weapons.add(weapon);
        damage += weapon.getDamage(characters);
        weaponFlag = true;
      }
    }
  }

  @Override
  public void gearUp(Gear o) throws IllegalArgumentException {
    if (!(o instanceof AbstractGear)) {
      throw new IllegalArgumentException("Can't be equipped");
    }
    AbstractGear gear = (AbstractGear) o;
    if (o instanceof HeadGear) {
      equipHeadGear(gear);
    } else if (o instanceof Potion) {
      equipPotion(gear);
    } else if (o instanceof Belt) {
      equipBelt(gear);
    } else if (o instanceof FootWear) {
      equipFootWear(gear);
    }
  }

  private void equipFootWear(AbstractGear gear) {
    if (footWears.size() == 0) {
      footWears.add(gear);
      finalDexterity += gear.getExtraDexterity();
      health += gear.getExtraDexterity();
    } else if (footWears.size() == 1 && gear.getName().equals(footWears.get(0).getName())) {
      footWears.add(gear);
      health += gear.getExtraDexterity();
      finalDexterity += gear.getExtraDexterity();
    }
    Collections.sort(footWears);
  }

  private void equipBelt(AbstractGear gear) {
    if (this.beltSpace - gear.getSize() >= 0) {
      belts.add(gear);
      health += gear.getExtraStrength();
      finalStrength += gear.getExtraStrength();
      health += gear.getExtraConstitution();
      finalConstitution += gear.getExtraConstitution();
      health += gear.getExtraCharisma();
      finalCharisma += gear.getExtraCharisma();
      health += gear.getExtraDexterity();
      finalDexterity += gear.getExtraDexterity();
      beltSpace -= gear.getSize();
    }
    Collections.sort(belts);
  }

  private void equipPotion(AbstractGear gear) {
    potions.add(gear);
    health += gear.getExtraStrength();
    finalStrength += gear.getExtraStrength();
    health += gear.getExtraConstitution();
    finalConstitution += gear.getExtraConstitution();
    health += gear.getExtraCharisma();
    finalCharisma += gear.getExtraCharisma();
    health += gear.getExtraDexterity();
    finalDexterity += gear.getExtraDexterity();
  }

  private void equipHeadGear(AbstractGear gear) {
    if (headGears.isEmpty()) {
      headGears.add(gear);
      health += gear.getExtraConstitution();
      finalConstitution += gear.getExtraConstitution();
    }
    Collections.sort(headGears);
  }

  /**
   * Returns the toString.
   *
   * @return toString
   */
  @Override
  public String toString() {
    List<String> headTemp = new ArrayList<>();
    List<String> potionTemp = new ArrayList<>();
    List<String> beltTemp = new ArrayList<>();
    List<String> footTemp = new ArrayList<>();
    List<String> weaponTemp = new ArrayList<>();
    for (Gear g : headGears) {
      headTemp.add(g.getName() + " ");
    }
    for (Gear g : potions) {
      potionTemp.add(g.getName() + " ");
    }
    for (Gear g : belts) {
      beltTemp.add(g.getName() + " ");
    }
    for (Gear g : footWears) {
      footTemp.add(g.getName() + " ");
    }
    for (Weapon w : weapons) {
      weaponTemp.add(w.getName() + " ");
    }
    return String.format("%s's info: %s s(%s s), %s d(%s d), %s c(%s c)) %s ch(%s ch) with %s HP."
                    + " Equipped %s, %s, %s and %s. Wielded %s.", name,
            finalStrength, strength, finalDexterity, dexterity, finalConstitution, constitution,
            finalCharisma, charisma, health, String.join(" ", headTemp),
            String.join(" ", potionTemp), String.join(" ", beltTemp), String.join(" ", footTemp),
            String.join(" ", weaponTemp));
  }
}
