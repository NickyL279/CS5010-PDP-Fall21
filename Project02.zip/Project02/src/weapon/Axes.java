package weapon;

import character.Characters;
import battle.Dicing;
import battle.RandomIntSeeded;

/**
 * This class represents an axes in a turn-based game. It offers all the operations
 * mandated by the weapon interface.
 */
public class Axes implements Weapon {
  private final String axeName;
  private final int damage;
  private final WeaponType weaponType;
  Dicing r1 = new RandomIntSeeded();

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param axeName name of the weapon
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public Axes(String axeName) {
    this.axeName = axeName;
    this.weaponType = WeaponType.AXES;
    if (axeName == null || axeName.trim().isEmpty()) {
      throw new IllegalArgumentException("name cannot be null or empty");
    }
    this.damage = r1.randomNumSingle(6, 10);
  }

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param axeName name of the weapon
   * @param seed seed for random number
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public Axes(String axeName, int seed) {
    this.axeName = axeName;
    this.weaponType = WeaponType.AXES;
    if (axeName == null || axeName.trim().isEmpty()) {
      throw new IllegalArgumentException("name cannot be null or empty");
    }
    this.damage = r1.randomNumSingleSeeded(6, 10, seed);
  }

  @Override
  public String getName() {
    return axeName;
  }

  @Override
  public WeaponType getWeaponType() {
    return weaponType;
  }

  @Override
  public int getDamage(Characters characters) {
    return damage;
  }

  @Override
  public Boolean checkType() {
    return false;
  }

  @Override
  public String toString() {
    return String.format("%s is a %s (%d damage)", axeName, weaponType.toString(), damage);
  }
}
