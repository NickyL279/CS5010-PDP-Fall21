package weapon;

import character.Characters;

/**
 * This interface represents a weapon in a turn-based game.
 */
public interface Weapon {
  String getName();

  WeaponType getWeaponType();

  int getDamage(Characters character);

  Boolean checkType();
}
