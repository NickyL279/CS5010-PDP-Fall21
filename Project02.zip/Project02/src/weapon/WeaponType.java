package weapon;

/**
 * This class represents the type of weapon in a turn-based game. It offers all the types
 * mandated by the weapon.
 */
public enum WeaponType {
  SWORDS,
  AXES,
  FLAILS;
}
