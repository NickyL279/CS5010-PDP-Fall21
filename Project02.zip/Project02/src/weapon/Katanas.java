package weapon;

import character.Characters;
import battle.Dicing;
import battle.RandomIntSeeded;

/**
 * This class represents a katanas in a turn-based game. It offers all the operations
 * mandated by the weapon interface.
 */
public class Katanas implements Weapon {
  private final String swordName;
  private final WeaponType weaponType;
  Dicing r1 = new RandomIntSeeded();
  private int damage;

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param swordName name of the weapon
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public Katanas(String swordName) {
    this.swordName = swordName;
    this.weaponType = WeaponType.SWORDS;
    if (swordName == null || swordName.trim().isEmpty()) {
      throw new IllegalArgumentException("name cannot be null or empty");
    }
    this.damage = r1.randomNumSingle(4, 6);
  }

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param swordName name of the weapon
   * @param seed      seed for random number
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public Katanas(String swordName, int seed) {
    this.swordName = swordName;
    this.weaponType = WeaponType.SWORDS;
    if (swordName == null || swordName.trim().isEmpty()) {
      throw new IllegalArgumentException("name cannot be null or empty");
    }
    this.damage = r1.randomNumSingleSeeded(4, 6, seed);
  }

  @Override
  public String getName() {
    return swordName;
  }

  @Override
  public WeaponType getWeaponType() {
    return weaponType;
  }

  @Override
  public int getDamage(Characters characters) {
    return damage;
  }


  @Override
  public Boolean checkType() {
    return true;
  }

  @Override
  public String toString() {
    return String.format("%s is a %s (%d damage)", swordName, weaponType.toString(), damage);
  }
}
