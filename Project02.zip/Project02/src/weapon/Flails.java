package weapon;


import character.Characters;
import battle.Dicing;
import battle.RandomIntSeeded;

/**
 * This class represents a flails in a turn-based game. It offers all the operations
 * mandated by the weapon interface.
 */
public class Flails implements Weapon {
  private final String flailsName;
  private final WeaponType weaponType;
  Dicing r1 = new RandomIntSeeded();
  private int damage;

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param flailsName name of the weapon
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public Flails(String flailsName) {
    this.flailsName = flailsName;
    this.weaponType = WeaponType.FLAILS;
    if (flailsName == null || flailsName.trim().isEmpty()) {
      throw new IllegalArgumentException("name cannot be null or empty");
    }
    this.damage = r1.randomNumSingle(8, 12);
  }

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param flailsName name of the weapon
   * @param seed seed for random number
   * @throws IllegalArgumentException If the weapon's name is empty or null.
   */
  public Flails(String flailsName, int seed) {
    this.flailsName = flailsName;
    this.weaponType = WeaponType.FLAILS;
    if (flailsName == null || flailsName.trim().isEmpty()) {
      throw new IllegalArgumentException("name cannot be null or empty");
    }
    this.damage = r1.randomNumSingleSeeded(8, 12, seed);
  }

  @Override
  public String getName() {
    return flailsName;
  }

  @Override
  public WeaponType getWeaponType() {
    return weaponType;
  }

  @Override
  public int getDamage(Characters character) {
    if (character.getDexterity() <= 14) {
      return damage / 2;
    } else {
      return damage;
    }
  }

  @Override
  public Boolean checkType() {
    return false;
  }

  @Override
  public String toString() {
    return String.format("%s is a %s (%d damage)", flailsName, weaponType.toString(), damage);
  }
}
