package gear;

/**
 * This class represents a potion gear in a turn-based game. It offers all the operations
 * mandated by the gear interface.
 */
public class Potion extends AbstractGear {
  private final int strength;
  private final int constitution;
  private final int dexterity;
  private final int charisma;

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param gearName          name of the gear
   * @param extraCharisma     extra charisma of the gear
   * @param extraConstitution extra constitution of the gear
   * @param extraDexterity    extra dexterity of the gear
   * @param extraStrength     extra strength of the gear
   * @throws IllegalArgumentException If the gear's name is empty or null.
   * @throws IllegalArgumentException If the gear's attributes are 0.
   * @throws IllegalArgumentException If the gear's attributes are too strong.
   */
  public Potion(String gearName, int extraStrength, int extraConstitution, int extraDexterity,
                int extraCharisma) throws IllegalArgumentException {
    super(gearName);
    if (extraStrength == 0 && extraConstitution == 0
            && extraDexterity == 0 && extraCharisma == 0) {
      throw new IllegalArgumentException("potion cannot have zero power");
    }
    if (extraStrength > 10 || extraConstitution > 10
            || extraDexterity > 10 || extraCharisma > 10) {
      throw new IllegalArgumentException("This potion is too strong");
    }
    if (gearName == null || gearName.trim().isEmpty()) {
      throw new IllegalArgumentException("Must have a name");
    }
    strength = extraStrength;
    charisma = extraCharisma;
    constitution = extraConstitution;
    dexterity = extraDexterity;
  }

  @Override
  public int getExtraStrength() {
    return strength;
  }

  @Override
  public int getExtraConstitution() {
    return constitution;
  }

  @Override
  public int getExtraDexterity() {
    return dexterity;
  }

  @Override
  public int getExtraCharisma() {
    return charisma;
  }

  @Override
  public int compareTo(Gear o) {
    if (!(o instanceof AbstractGear)) {
      throw new IllegalArgumentException("Not abstract gear");
    }
    AbstractGear potionGear = (AbstractGear) o;
    return potionGear.compareToPotion(this);
  }

  @Override
  public int compareToPotion(Gear o) {
    return o.getName().compareTo(this.getName());
  }

  @Override
  public int compareToBelt(Gear o) {
    return 1;
  }

  @Override
  public String toString() {
    return String.format("Name is %s with %d s, %d d, %d c, %d ch",
            gearName, strength, dexterity, constitution, charisma);
  }
}
