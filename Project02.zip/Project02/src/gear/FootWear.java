package gear;

/**
 * This class represents a foot gear in a turn-based game. It offers all the operations
 * mandated by the gear interface.
 */
public class FootWear extends AbstractGear {
  private final int dexterity;

  /**
   * The constructor of the foot gear class which calls the abstractGear class.
   *
   * @param gearName       name of the gear
   * @param extraDexterity extra dexterity of the gear
   * @throws IllegalArgumentException If the gear's name is empty or null.
   * @throws IllegalArgumentException If the gear's attributes are 0.
   * @throws IllegalArgumentException If the gear's attributes are too strong.
   */
  public FootWear(String gearName, int extraDexterity) throws IllegalArgumentException {
    super(gearName);
    if (extraDexterity == 0) {
      throw new IllegalArgumentException("Foot wear cannot have zero power");
    }
    if (extraDexterity > 10) {
      throw new IllegalArgumentException("This foot wear is too strong");
    }
    if (gearName == null || gearName.trim().isEmpty()) {
      throw new IllegalArgumentException("Must have a name");
    }
    dexterity = extraDexterity;
  }

  @Override
  public int getExtraDexterity() {
    return dexterity;
  }

  @Override
  public int compareTo(Gear o) {
    if (!(o instanceof AbstractGear)) {
      throw new IllegalArgumentException("Not abstract gear");
    }
    AbstractGear footGear = (AbstractGear) o;
    return footGear.compareToFootGear(this);
  }

  @Override
  public int compareToFootGear(Gear o) {
    return o.getName().compareTo(this.getName());
  }

  @Override
  public String toString() {
    return String.format("Name is %s with %d dexterity", gearName, dexterity);
  }
}
