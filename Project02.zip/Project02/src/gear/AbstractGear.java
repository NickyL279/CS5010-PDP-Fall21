package gear;

/**
 * An abstract class that contains all of the code that is shared by all types of gaers.
 */
public abstract class AbstractGear implements Gear {
  protected final String gearName;
  protected int extraStrength;
  protected int extraConstitution;
  protected int extraDexterity;
  protected int extraCharisma;
  protected int size;

  /**
   * Protected constructor for use by subclasses.
   *
   * @param gearName name of the gear
   * @throws IllegalArgumentException If the gear name is null
   * @throws IllegalArgumentException If the gear name is empty
   */
  public AbstractGear(String gearName) throws IllegalArgumentException {
    this.extraStrength = extraStrength;
    this.extraConstitution = extraConstitution;
    this.extraDexterity = extraDexterity;
    this.extraCharisma = extraCharisma;
    if (gearName == null) {
      throw new IllegalArgumentException("Gear name cannot be null");
    }
    if (gearName.trim().isEmpty()) {
      throw new IllegalArgumentException("Gear name cannot be empty");
    }
    this.gearName = gearName;
  }

  @Override
  public String getName() {
    return this.gearName;
  }

  @Override
  public int getExtraStrength() {
    return this.extraStrength;
  }

  @Override
  public int getExtraConstitution() {
    return this.extraConstitution;
  }

  @Override
  public int getExtraDexterity() {
    return this.extraDexterity;
  }

  @Override
  public int getExtraCharisma() {
    return this.extraCharisma;
  }

  @Override
  public int getSize() {
    return this.size;
  }

  /**
   * Returns -1, which places any gear below it.
   *
   * @param gear The gear object.
   * @return -1
   */
  public int compareToHeadGear(Gear gear) {
    return -1;
  }

  /**
   * Returns -1, which places any gear below it.
   *
   * @param gear The gear object.
   * @return -1
   */
  public int compareToPotion(Gear gear) {
    return -1;
  }

  /**
   * Returns -1, which places any gear below it.
   *
   * @param gear The gear object.
   * @return -1
   */
  public int compareToBelt(Gear gear) {
    return -1;
  }

  /**
   * Returns 1, which places any gear above it.
   *
   * @param gear The gear object.
   * @return 1
   */
  public int compareToFootGear(Gear gear) {
    return 1;
  }

  /**
   * Returns the toString.
   *
   * @return toString
   */
  @Override
  public String toString() {
    return String.format("%s", getName());
  }
}
