package gear;

/**
 * This class represents a head gear in a turn-based game. It offers all the operations
 * mandated by the gear interface.
 */
public class HeadGear extends AbstractGear {
  private final int constitution;

  /**
   * The constructor of the Head gear class which calls the abstractGear class.
   *
   * @param gearName       name of the gear
   * @param extraConstitution extra dexterity of the gear
   * @throws IllegalArgumentException If the gear's name is empty or null.
   * @throws IllegalArgumentException If the gear's attributes are 0.
   * @throws IllegalArgumentException If the gear's attributes are too strong.
   */
  public HeadGear(String gearName, int extraConstitution) throws IllegalArgumentException {
    super(gearName);
    if (extraConstitution == 0) {
      throw new IllegalArgumentException("Cannot be zero");
    }
    if (extraConstitution > 20) {
      throw new IllegalArgumentException("This head gear is too strong");
    }
    if (gearName == null || gearName.trim().isEmpty()) {
      throw new IllegalArgumentException("Must have a name");
    }
    constitution = extraConstitution;
  }

  @Override
  public int getExtraConstitution() {
    return constitution;
  }

  @Override
  public int compareTo(Gear gear) {
    if (!(gear instanceof AbstractGear)) {
      throw new IllegalArgumentException("Not abstract gear");
    }
    AbstractGear headGear = (AbstractGear) gear;
    return headGear.compareToHeadGear(this);
  }

  @Override
  public int compareToHeadGear(Gear gear) {
    return gear.getName().compareTo(this.getName());
  }

  /**
   * Returns -1, which places this gear above any potion.
   *
   * @param gear The gear object.
   * @return -1
   */
  @Override
  public int compareToPotion(Gear gear) {
    return 1;
  }

  /**
   * Returns 1, which places this gear above any belt.
   *
   * @param gear The gear object.
   * @return -1
   */
  @Override
  public int compareToBelt(Gear gear) {
    return 1;
  }

  @Override
  public String toString() {
    return String.format("Name is %s with %d constitution", gearName, constitution);
  }
}


