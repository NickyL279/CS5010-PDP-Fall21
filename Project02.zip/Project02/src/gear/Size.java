package gear;

/**
 * This class represents the size of belt in a turn-based game. It offers all the sizes
 * mandated by the belt.
 */
public enum Size {
  SMALL,
  MEDIUM,
  LARGE;
}
