package gear;

/**
 * This interface represents a gear in a turn-based game.
 */
public interface Gear extends Comparable<Gear> {

  String getName();

  int getExtraStrength();

  int getExtraConstitution();

  int getExtraDexterity();

  int getExtraCharisma();

  int getSize();
}
