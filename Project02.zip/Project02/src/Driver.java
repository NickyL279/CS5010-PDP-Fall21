import battle.Battle;
import battle.BattleField;
import character.Character;
import character.Characters;
import gear.Belt;
import gear.FootWear;
import gear.Gear;
import gear.HeadGear;
import gear.Potion;
import gear.Size;

import java.util.Scanner;

import weapon.Axes;
import weapon.Broadswords;
import weapon.Flails;
import weapon.Katanas;
import weapon.TwoHandedSwords;
import weapon.Weapon;

/**
 * This class represents the driver a turn-based game. It offers all the operations mandated by the
 * game.
 */
public class Driver {
  /**
   * This class represents a main class.
   */
  public static void main(String[] args) {
    Characters playerOne = new Character("p1");
    Characters playerTwo = new Character("p2");
    final Battle neu = new BattleField(playerOne, playerTwo, 10, 10, 30, 30);
    System.out.println("----------------------------Today's two players");
    System.out.println(playerOne.toString());
    System.out.println(playerTwo.toString());
    System.out.println("----------------------------Adding Head gears");
    Gear head1 = new HeadGear("Helm1", 3);
    Gear head2 = new HeadGear("Helm2", 4);
    Gear head3 = new HeadGear("Helm3", 1);
    Gear head4 = new HeadGear("Helm4", 2);
    Gear head5 = new HeadGear("Helm5", -3);
    neu.addHeadGear(head1);
    neu.addHeadGear(head2);
    neu.addHeadGear(head3);
    neu.addHeadGear(head4);
    neu.addHeadGear(head5);
    System.out.println(neu.getHeadList());
    //System.out.println(head1);
    System.out.println("----------------------------Adding Foot gears");
    Gear foot1 = new FootWear("Foot1", 3);
    Gear foot2 = new FootWear("Foot2", 4);
    Gear foot3 = new FootWear("Foot3", 1);
    Gear foot4 = new FootWear("Foot4", 2);
    Gear foot5 = new FootWear("Foot5", -3);
    Gear foot6 = new FootWear("Foot2", 4);
    Gear foot7 = new FootWear("Foot1", 3);
    Gear foot8 = new FootWear("Foot3", 1);
    Gear foot9 = new FootWear("Foot4", 2);
    Gear foot10 = new FootWear("Foot5", -3);
    neu.addFootWear(foot1);
    neu.addFootWear(foot2);
    neu.addFootWear(foot3);
    neu.addFootWear(foot4);
    neu.addFootWear(foot5);
    neu.addFootWear(foot6);
    neu.addFootWear(foot7);
    neu.addFootWear(foot8);
    neu.addFootWear(foot9);
    neu.addFootWear(foot10);
    System.out.println(neu.getFootList());
    //System.out.println(foot1);
    System.out.println("----------------------------Adding Potions");
    Gear potion1 = new Potion("Potion1", 0, 3, 0, 0);
    Gear potion2 = new Potion("Potion2", 0, 0, 3, 0);
    Gear potion3 = new Potion("Potion3", 3, 0, 0, 0);
    Gear potion4 = new Potion("Potion4", 0, 0, 0, 3);
    Gear potion5 = new Potion("Potion5", 1, 0, 0, 0);
    Gear potion6 = new Potion("Potion6", 0, 1, 0, 0);
    Gear potion7 = new Potion("Potion7", 0, 0, 1, 0);
    Gear potion8 = new Potion("Potion8", 0, 0, 0, 1);
    Gear potion9 = new Potion("Potion9", 2, 0, 0, 0);
    Gear potion10 = new Potion("Potion10", 0, -3, 0, 0);
    Gear potion11 = new Potion("Potion11", -1, 0, 0, 0);
    Gear potion12 = new Potion("Potion12", 0, 0, -1, 0);
    Gear potion13 = new Potion("Potion13", 0, 0, 0, -1);
    Gear potion14 = new Potion("Potion14", -1, 0, 0, 0);
    Gear potion15 = new Potion("Potion15", 0, 3, 0, 0);
    neu.addPotion(potion1);
    neu.addPotion(potion2);
    neu.addPotion(potion3);
    neu.addPotion(potion4);
    neu.addPotion(potion5);
    neu.addPotion(potion6);
    neu.addPotion(potion7);
    neu.addPotion(potion8);
    neu.addPotion(potion9);
    neu.addPotion(potion10);
    neu.addPotion(potion11);
    neu.addPotion(potion12);
    neu.addPotion(potion13);
    neu.addPotion(potion14);
    neu.addPotion(potion15);
    System.out.println(neu.getPotionList());
    //System.out.println(potion1);
    System.out.println("----------------------------Adding Belts");
    Gear belt1 = new Belt(Size.SMALL, "belt1", 0, 1, 1, 0);
    Gear belt2 = new Belt(Size.SMALL, "belt2", 1, 0, 1, 0);
    Gear belt3 = new Belt(Size.SMALL, "belt3", 0, 0, 1, 1);
    Gear belt4 = new Belt(Size.SMALL, "belt4", 0, 1, 0, 1);
    Gear belt5 = new Belt(Size.SMALL, "belt5", 1, 0, 0, 1);
    Gear belt6 = new Belt(Size.MEDIUM, "belt6", 0, 2, 2, 0);
    Gear belt7 = new Belt(Size.MEDIUM, "belt7", 2, 0, 2, 0);
    Gear belt8 = new Belt(Size.MEDIUM, "belt8", 0, 2, 0, 2);
    Gear belt9 = new Belt(Size.MEDIUM, "belt9", 2, 0, 0, 2);
    Gear belt10 = new Belt(Size.MEDIUM, "belt10", 0, 2, 0, 2);
    Gear belt11 = new Belt(Size.LARGE, "belt11", 0, 3, 3, 0);
    Gear belt12 = new Belt(Size.LARGE, "belt12", 3, 0, 0, 3);
    Gear belt13 = new Belt(Size.LARGE, "belt13", 3, 0, 3, 0);
    Gear belt14 = new Belt(Size.LARGE, "belt14", 0, 3, 0, 3);
    Gear belt15 = new Belt(Size.LARGE, "belt15", 3, 0, 3, 0);
    neu.addBelt(belt1);
    neu.addBelt(belt2);
    neu.addBelt(belt3);
    neu.addBelt(belt4);
    neu.addBelt(belt5);
    neu.addBelt(belt6);
    neu.addBelt(belt7);
    neu.addBelt(belt8);
    neu.addBelt(belt9);
    neu.addBelt(belt10);
    neu.addBelt(belt11);
    neu.addBelt(belt12);
    neu.addBelt(belt13);
    neu.addBelt(belt14);
    neu.addBelt(belt15);
    System.out.println(neu.getBeltList());
    //System.out.println(belt1);
    System.out.println("----------------------------Build Gear bag");
    neu.buildGearBag();
    System.out.println(neu.getGearBag());
    System.out.println("----------------------------Adding Head gears");
    Weapon a1 = new Axes("axe1");
    Weapon a2 = new Axes("axe2");
    Weapon f1 = new Flails("flails1");
    Weapon f2 = new Flails("flails2");
    Weapon s1 = new Katanas("k1");
    Weapon s2 = new Katanas("k1");
    Weapon s3 = new Broadswords("b1");
    Weapon s4 = new TwoHandedSwords("t1");
    neu.addWeapon(a1);
    neu.addWeapon(a2);
    neu.addWeapon(f1);
    neu.addWeapon(f2);
    neu.addWeapon(s1);
    neu.addWeapon(s2);
    neu.addWeapon(s3);
    neu.addWeapon(s4);
    neu.buildArmory();
    System.out.println(neu.getArmory());
    System.out.println("----------------------------Player 1 and player 2 entered the arena!");
    neu.dressPlayer();
    neu.dressSecondPlayer();
    System.out.println(playerOne.toString());
    System.out.println(playerTwo.toString());
    System.out.println("----------------------------Battle begins!");
    int i = 0;
    while (i < 1000) {
      try {
        System.out.println("----------------------------round" + (neu.getRound() + 1));
        System.out.println(neu.getCurPlayer().getName() + " attacks");
        neu.attack();
        System.out.println(neu.getHitRecords());
        System.out.println(neu.getHealthStatus());
        System.out.println(neu.getStatus());
        if (neu.getBattleFlag()) {
          break;
        }
        i++;
      } catch (Exception e) {
        System.out.println("It is a draw");
        break;
      }
    }

    System.out.println("Wanna a rematch? (true or false)");
    Scanner in = new Scanner(System.in);
    boolean rematchFlag = in.nextBoolean();
    if (rematchFlag) {
      System.out.println("----------------------------Rematch confirm!");
      neu.setUpRematch(true);
      i = 0;
      while (i < 1000) {
        try {
          System.out.println("----------------------------round" + (neu.getRound() + 1));
          System.out.println(neu.getCurPlayer().getName() + " attacks");
          neu.attack();
          System.out.println(neu.getHitRecords());
          System.out.println(neu.getHealthStatus());
          System.out.println(neu.getStatus());
          if (neu.getBattleFlag()) {
            break;
          }
          i++;
        } catch (Exception e) {
          System.out.println("It is a draw");
          break;
        }
      }
    } else {
      System.out.println("----------------------------Rematch denied!");
      System.out.println("GG WP!");
    }
  }
}
