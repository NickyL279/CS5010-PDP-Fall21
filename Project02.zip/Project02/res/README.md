# CS5010-Project2: Battle

Creates an arena for two players to fight in turns.

## Overview:

Lots of games pit one player against another either in the arena or on the field of battle. The
winners of these battles tend to depend upon the abilities of the players, the gear that they have
at their disposal, and, a little bit, on their luck.

## Features:

- Put two players into the arena with basic abilities(determined by rolling a die four times and
  taking the highest three values of those rolls.) and without any equipments.
- A player's health is the sum of all four abilities. All final abilities are determined by the
  dicing process plus any equipment buffing.
- Once the player enters the arena, an gear package is created, and the player equips these items. A
  player may have a headgear, a pair of foot wears, unlimited potions, and belts depends on size. (
  The player’s abilities are affected positively and negatively by the equipment items) Later
  players are equipped with gears, and they choose a weapon from the armory. the weapon is assigned
  to players that have different damage ranges according to their abilities and random numbers
  distribution of weapon damage.
- Once the player is equipped with gears and weapons, they will enter the turn-based battle. This
  battle is turn-based, where the actual damage to the defending player depends on the calculation
  of striking power, avoidance and damage. If the striking power of the attacking side is greater
  than the avoidance of the defending side, the attacker successfully hit the defender. If the
  attacker hits the player, actual damage is the potential damage minus the defender’s constitution.
- Once the health of one of the players is zero or below, the game is over, and the result will be
  printed. The user can also request a rematch. In this case, the players re-enter the battle with
  full HP.

## How to:

The program will follow the steps of the above function and ask the user to enter "true" or "
false" about deciding whether they would like to have a rematch. If choose true, then the players
will Fight again.

To run this program, please run the driver file and put in option following the instruction.

## How to Use the Program:

This program is interactive, open the Project02.jar in your IDE, and run it. Then follow the
instruction to interact.

## Description of Examples:

This program equips two players with gears and weapons, then entered into a turn-based battle until
the winner is declared. Please refer to the features section for a step-by-step guide on how the
program works.

Run 1 -- run1.txt:

1. initialize the battlefield and players
2. initialize gears and weapons for the gear bag and armory
3. start fight, p1 wins. Then start a rematch, p1 wins again.

Run 2 -- run2.txt:

1. initialize the battlefield and players
2. initialize gears and weapons for the gear bag and armory
3. start fight, p2 wins. Then not start a rematch. Games over.

Run 3 -- run3.txt:

1. initialize the battlefield and players
2. initialize gears and weapons for the gear bag and armory
3. start fight, it is a draw. Then start a rematch, it is a draw again. Games over.

## Design/Model Changes:

I made some changes to the original UML, but the classes are basically unchanged.

I reorganized the methods in the class, so the methods can get information from the class. I added
many getters to the battle and character classes, so I can get those information in the driver.

I also added two enums to the design, so I can limit the size of belt, and the weapon types. Also
added a interface and a class for generating the random numbers.

## Assumptions:

I assume that after those two players picked gears or weapons, those items will not be available for
next player. This is common sense in games.

I assume a draw game happens when they did not hit the other player more than 300 times out of 400
rounds. In this case, there is a great chance that there is not going to have a winner in the end.

I also assume a pair of footwear will have the same name, in really games, they are.

## Limitations:

This program will only take in limited number of gears and weapon, and only manipulate two players.
And the gears and weapons are not detailed enough like real games.

## Citations:

CSDN, https://www.csdn.net/. Stack Overflow, https://stackoverflow.com/.
Geeksforgeeks, https://www.geeksforgeeks.org/. Google, https://www.google.com/.
