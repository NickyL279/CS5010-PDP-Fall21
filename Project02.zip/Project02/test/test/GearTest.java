package test;

import org.junit.Before;
import org.junit.Test;

import battle.Battle;
import battle.BattleField;
import character.Character;
import character.Characters;
import gear.Belt;
import gear.FootWear;
import gear.Gear;
import gear.HeadGear;
import gear.Potion;
import gear.Size;

import static org.junit.Assert.assertEquals;

/**
 * This class represents gear classes' test.
 */
public class GearTest {
  Gear head1;
  Gear head2;
  Gear foot1;
  Gear foot2;
  Gear foot6;
  Gear foot7;
  Gear potion1;
  Gear potion2;
  Gear potion3;
  Gear potion4;
  Gear potion10;
  Gear potion11;
  Gear potion12;
  Gear potion13;
  Gear belt1;
  Gear belt2;
  Gear belt3;
  Gear belt4;
  Gear belt5;
  Gear belt6;
  Gear belt7;
  Gear belt8;
  Gear belt9;
  Gear belt10;
  Gear belt11;
  Gear belt12;
  Gear belt13;
  Gear belt14;
  Gear belt15;
  Characters playerOne;
  Characters playerTwo;
  Battle neu;
  Gear head3 = new HeadGear("Helm3", 1);
  Gear head4 = new HeadGear("Helm4", 2);
  Gear head5 = new HeadGear("Helm5", -3);
  Gear foot3 = new FootWear("Foot3", 1);
  Gear foot4 = new FootWear("Foot4", 2);
  Gear foot5 = new FootWear("Foot5", -3);
  Gear foot8 = new FootWear("Foot3", 1);
  Gear foot9 = new FootWear("Foot4", 2);
  Gear foot10 = new FootWear("Foot5", -3);
  Gear potion5 = new Potion("Potion5", 1, 0, 0, 0);
  Gear potion6 = new Potion("Potion6", 0, 1, 0, 0);
  Gear potion7 = new Potion("Potion7", 0, 0, 1, 0);
  Gear potion8 = new Potion("Potion8", 0, 0, 0, 1);
  Gear potion9 = new Potion("Potion9", 2, 0, 0, 0);
  Gear potion14 = new Potion("Potion14", -1, 0, 0, 0);
  Gear potion15 = new Potion("Potion15", 0, 3, 0, 0);

  @Before
  public void setUp() {
    head1 = new HeadGear("Helm1", 3);
    head2 = new HeadGear("Helm2", -4);
    foot1 = new FootWear("Foot1", 3);
    foot2 = new FootWear("Foot2", 4);
    foot6 = new FootWear("Foot2", 4);
    foot7 = new FootWear("Foot1", 3);
    potion1 = new Potion("Potion1", 0, 3, 0, 0);
    potion2 = new Potion("Potion2", 0, 0, 3, 0);
    potion3 = new Potion("Potion3", 3, 0, 0, 0);
    potion4 = new Potion("Potion4", 0, 0, 0, 3);
    potion10 = new Potion("Potion10", 0, -3, 0, 0);
    potion11 = new Potion("Potion11", -1, 0, 0, 0);
    potion12 = new Potion("Potion12", 0, 0, -1, 0);
    potion13 = new Potion("Potion13", 0, 0, 0, -1);
    belt1 = new Belt(Size.SMALL, "belt1", 0, 1, 1, 0);
    belt2 = new Belt(Size.SMALL, "belt2", 1, 0, 1, 0);
    belt3 = new Belt(Size.SMALL, "belt3", 0, 0, 1, 1);
    belt4 = new Belt(Size.SMALL, "belt4", 0, 1, 0, 1);
    belt5 = new Belt(Size.SMALL, "belt5", 1, 0, 0, 1);
    belt6 = new Belt(Size.MEDIUM, "belt6", 0, 2, 2, 0);
    belt7 = new Belt(Size.MEDIUM, "belt7", 2, 0, 2, 0);
    belt8 = new Belt(Size.MEDIUM, "belt8", 0, 2, 0, 2);
    belt9 = new Belt(Size.MEDIUM, "belt9", 2, 0, 0, 2);
    belt10 = new Belt(Size.MEDIUM, "belt10", 0, 2, 0, 2);
    belt11 = new Belt(Size.LARGE, "belt11", 0, 3, 3, 0);
    belt12 = new Belt(Size.LARGE, "belt12", 3, 0, 0, 3);
    belt13 = new Belt(Size.LARGE, "belt13", 3, 0, 3, 0);
    belt14 = new Belt(Size.LARGE, "belt14", 0, 3, 0, 3);
    belt15 = new Belt(Size.LARGE, "belt15", 3, 0, 3, 0);
    playerOne = new Character("p1");
    playerTwo = new Character("p2");
    neu = new BattleField(playerOne, playerTwo, 10, 10, 30, 30);
    neu.addHeadGear(head1);
    neu.addHeadGear(head2);
    neu.addHeadGear(head3);
    neu.addHeadGear(head4);
    neu.addHeadGear(head5);
    neu.addFootWear(foot1);
    neu.addFootWear(foot2);
    neu.addFootWear(foot3);
    neu.addFootWear(foot4);
    neu.addFootWear(foot5);
    neu.addFootWear(foot6);
    neu.addFootWear(foot7);
    neu.addFootWear(foot8);
    neu.addFootWear(foot9);
    neu.addFootWear(foot10);
    neu.addPotion(potion1);
    neu.addPotion(potion2);
    neu.addPotion(potion3);
    neu.addPotion(potion4);
    neu.addPotion(potion5);
    neu.addPotion(potion6);
    neu.addPotion(potion7);
    neu.addPotion(potion8);
    neu.addPotion(potion9);
    neu.addPotion(potion10);
    neu.addPotion(potion11);
    neu.addPotion(potion12);
    neu.addPotion(potion13);
    neu.addPotion(potion14);
    neu.addPotion(potion15);
    neu.addBelt(belt1);
    neu.addBelt(belt2);
    neu.addBelt(belt3);
    neu.addBelt(belt4);
    neu.addBelt(belt5);
    neu.addBelt(belt6);
    neu.addBelt(belt7);
    neu.addBelt(belt8);
    neu.addBelt(belt9);
    neu.addBelt(belt10);
    neu.addBelt(belt11);
    neu.addBelt(belt12);
    neu.addBelt(belt13);
    neu.addBelt(belt14);
    neu.addBelt(belt15);
    neu.buildGearBag();

  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateHead() {
    Gear head0 = new HeadGear("", 3);
    Gear head1 = new HeadGear("", 0);
    Gear head2 = new HeadGear(null, 0);
    Gear head4 = new HeadGear(null, 50);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateBelt() {
    Gear belt0 = new Belt(Size.SMALL, "", 0, 1, 1, 0);
    Gear belt1 = new Belt(Size.SMALL, "belt1", 0, 0, 0, 0);
    Gear belt2 = new Belt(Size.SMALL, "belt2", 0, 16, 1, 0);
    Gear belt3 = new Belt(Size.SMALL, null, 0, 1, 1, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreatePotion() {
    Gear potion1 = new Potion("", 0, 3, 0, 0);
    Gear potion2 = new Potion(null, 0, 3, 0, 0);
    Gear potion3 = new Potion("Potion1", 0, 31, 0, 0);
    Gear potion4 = new Potion("Potion1", 0, 0, 0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateFoot() {
    Gear foot1 = new FootWear("", 3);
    Gear foot2 = new FootWear(null, 3);
    Gear foot3 = new FootWear("Foot1", 0);
    Gear foot4 = new FootWear("Foot1", 31);
  }

  @Test
  public void getName() {
    assertEquals("Helm1", head1.getName());
    assertEquals("belt1", belt1.getName());
    assertEquals("Potion1", potion1.getName());
    assertEquals("Foot1", foot1.getName());
  }

  @Test
  public void getExtraStrength() {
    assertEquals(0, head1.getExtraStrength());
    assertEquals(0, belt1.getExtraStrength());
    assertEquals(0, potion1.getExtraStrength());
    assertEquals(0, foot1.getExtraStrength());
  }

  @Test
  public void getExtraConstitution() {
    assertEquals(3, head1.getExtraConstitution());
    assertEquals(1, belt1.getExtraConstitution());
    assertEquals(3, potion1.getExtraConstitution());
    assertEquals(0, foot1.getExtraConstitution());
  }

  @Test
  public void getExtraDexterity() {
    assertEquals(0, head1.getExtraDexterity());
    assertEquals(1, belt1.getExtraDexterity());
    assertEquals(0, potion1.getExtraDexterity());
    assertEquals(3, foot1.getExtraDexterity());
  }

  @Test
  public void getExtraCharisma() {
    assertEquals(0, head1.getExtraCharisma());
    assertEquals(0, belt1.getExtraCharisma());
    assertEquals(0, potion1.getExtraCharisma());
    assertEquals(0, foot1.getExtraCharisma());
  }

  @Test
  public void getSize() {
    assertEquals(1, belt1.getSize());
    assertEquals(2, belt7.getSize());
    assertEquals(4, belt11.getSize());
  }

  @Test
  public void invalidDress() {
    Characters player1 = new Character("nicky", 40, 40, 40, 40);
    player1.gearUp(head1);
    player1.gearUp(head2);
    assertEquals("nicky's info: 40 s(40 s), 40 d(40 d), 43 c(40 c)) 40 ch(40 ch) with 163 HP." +
            " Equipped Helm1 , ,  and . Wielded .", player1.toString());
    player1.gearUp(belt11);
    player1.gearUp(belt12);
    player1.gearUp(belt13);
    player1.gearUp(belt14);
    player1.gearUp(belt15);
    assertEquals("nicky's info: 43 s(40 s), 43 d(40 d), 46 c(40 c)) 43 ch(40 ch) with 175 HP." +
            " Equipped Helm1 , , belt11  belt12  and . Wielded .", player1.toString());
    player1.gearUp(foot1);
    player1.gearUp(foot6);
    assertEquals("nicky's info: 43 s(40 s), 46 d(40 d), 46 c(40 c)) 43 ch(40 ch) with 178 HP." +
            " Equipped Helm1 , , belt11  belt12  and Foot1 . Wielded .", player1.toString());
  }

  @Test
  public void testOrder() {
    assertEquals("[Name is Helm1 with 3 constitution," +
                    " Name is Helm2 with -4 constitution, Name is Helm3 with 1 constitution," +
                    " Name is Helm4 with 2 constitution, Name is Helm5 with -3 constitution," +
                    " Name is Potion1 with 0 s, 0 d, 3 c, 0 ch, Name is Potion10 with 0 s," +
                    " 0 d, -3 c, 0 ch, Name is Potion11 with -1 s, 0 d, 0 c, 0 ch," +
                    " Name is Potion12 with 0 s, -1 d, 0 c, 0 ch, Name is Potion13 with 0 s," +
                    " 0 d, 0 c, -1 ch, Name is Potion14 with -1 s, 0 d, 0 c, 0 ch," +
                    " Name is Potion15 with 0 s, 0 d, 3 c, 0 ch, Name is Potion2 with 0 s," +
                    " 3 d, 0 c, 0 ch, Name is Potion3 with 3 s, 0 d, 0 c, 0 ch," +
                    " Name is Potion4 with 0 s, 0 d, 0 c, 3 ch, Name is Potion5 with 1 s," +
                    " 0 d, 0 c, 0 ch, Name is Potion6 with 0 s, 0 d, 1 c, 0 ch," +
                    " Name is Potion7 with 0 s, 1 d, 0 c, 0 ch, Name is Potion8 with 0 s," +
                    " 0 d, 0 c, 1 ch, Name is Potion9 with 2 s, 0 d, 0 c, 0 ch, " +
                    "Name is belt1 (size: 1) with 0 s, 1 d, 1 c, 0 ch, Name is belt10" +
                    " (size: 2) with 0 s," +
                    " 0 d, 2 c, 2 ch, Name is belt11 (size: 4) with 0 s, 3 d, 3 c, 0 ch," +
                    " Name is belt12 (size: 4) with 3 s, 0 d, 0 c, 3 ch," +
                    " Name is belt13 (size: 4)" +
                    " with 3 s, 3 d, 0 c, 0 ch, Name is belt14 (size: 4) with" +
                    " 0 s, 0 d, 3 c, 3 ch," +
                    " Name is belt15 (size: 4) with 3 s, 3 d, 0 c, 0 ch," +
                    " Name is belt2 (size: 1)" +
                    " with 1 s, 1 d, 0 c, 0 ch, Name is belt3 (size: 1)" +
                    " with 0 s, 1 d, 0 c, 1 ch," +
                    " Name is belt4 (size: 1) with 0 s, 0 d, 1 c, 1 ch," +
                    " Name is belt5 (size: 1)" +
                    " with 1 s, 0 d, 0 c, 1 ch, Name is belt6 (size: 2)" +
                    " with 0 s, 2 d, 2 c, 0 ch," +
                    " Name is belt7 (size: 2) with 2 s, 2 d, 0 c, 0 ch," +
                    " Name is belt8 (size: 2)" +
                    " with 0 s, 0 d, 2 c, 2 ch, Name is belt9 (size: 2)" +
                    " with 2 s, 0 d, 0 c, 2 ch," +
                    " Name is Foot1 with 3 dexterity, Name is Foot1 with" +
                    " 3 dexterity, Name is Foot2" +
                    " with 4 dexterity, Name is Foot2 with 4 dexterity," +
                    " Name is Foot3 with 1 dexterity," +
                    " Name is Foot3 with 1 dexterity, Name is Foot4 with 2" +
                    " dexterity, Name is Foot4 with" +
                    " 2 dexterity, Name is Foot5 with -3 dexterity, Name is " +
                    "Foot5 with -3 dexterity]",
            neu.getGearBag().toString());
  }

}