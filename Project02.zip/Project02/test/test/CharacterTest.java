package test;

import org.junit.Before;
import org.junit.Test;

import battle.Battle;
import battle.BattleField;
import character.Character;
import character.Characters;
import gear.Belt;
import gear.FootWear;
import gear.Gear;
import gear.HeadGear;
import gear.Potion;
import gear.Size;
import weapon.Axes;
import weapon.Broadswords;
import weapon.Flails;
import weapon.Katanas;
import weapon.TwoHandedSwords;
import weapon.Weapon;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This class represents character class's test.
 */
public class CharacterTest {
  Gear head1;
  Gear head2;
  Gear foot1;
  Gear foot2;
  Gear foot6;
  Gear foot7;
  Gear potion1;
  Gear potion2;
  Gear potion3;
  Gear potion4;
  Gear potion10;
  Gear potion11;
  Gear potion12;
  Gear potion13;
  Gear belt1;
  Gear belt2;
  Gear belt3;
  Gear belt4;
  Gear belt5;
  Gear belt6;
  Gear belt7;
  Gear belt8;
  Gear belt9;
  Gear belt10;
  Gear belt11;
  Gear belt12;
  Gear belt13;
  Gear belt14;
  Gear belt15;
  Characters playerOne;
  Characters playerTwo;
  Characters player3;
  Characters player4;
  Battle neu;
  Gear head3 = new HeadGear("Helm3", 1);
  Gear head4 = new HeadGear("Helm4", 2);
  Gear head5 = new HeadGear("Helm5", -3);
  Gear foot3 = new FootWear("Foot3", 1);
  Gear foot4 = new FootWear("Foot4", 2);
  Gear foot5 = new FootWear("Foot5", -3);
  Gear foot8 = new FootWear("Foot3", 1);
  Gear foot9 = new FootWear("Foot4", 2);
  Gear foot10 = new FootWear("Foot5", -3);
  Gear potion5 = new Potion("Potion5", 1, 0, 0, 0);
  Gear potion6 = new Potion("Potion6", 0, 1, 0, 0);
  Gear potion7 = new Potion("Potion7", 0, 0, 1, 0);
  Gear potion8 = new Potion("Potion8", 0, 0, 0, 1);
  Gear potion9 = new Potion("Potion9", 2, 0, 0, 0);
  Gear potion14 = new Potion("Potion14", -1, 0, 0, 0);
  Gear potion15 = new Potion("Potion15", 0, 3, 0, 0);
  Weapon a1 = new Axes("axe1", 2211);
  Weapon a2 = new Axes("axe2", 14214);
  Weapon f1 = new Flails("flails1", 4124);
  Weapon f2 = new Flails("flails2", 412412);
  Weapon s1 = new Katanas("k1", 1434521);
  Weapon s2 = new Katanas("k1", 513515);
  Weapon s3 = new Broadswords("b1", 513515);
  Weapon s4 = new TwoHandedSwords("t1", 51531);

  @Before
  public void setUp() {
    head1 = new HeadGear("Helm1", 3);
    head2 = new HeadGear("Helm2", -4);
    foot1 = new FootWear("Foot1", 3);
    foot2 = new FootWear("Foot2", 4);
    foot6 = new FootWear("Foot2", 4);
    foot7 = new FootWear("Foot1", 3);
    potion1 = new Potion("Potion1", 0, 3, 0, 0);
    potion2 = new Potion("Potion2", 0, 0, 3, 0);
    potion3 = new Potion("Potion3", 3, 0, 0, 0);
    potion4 = new Potion("Potion4", 0, 0, 0, 3);
    potion10 = new Potion("Potion10", 0, -3, 0, 0);
    potion11 = new Potion("Potion11", -1, 0, 0, 0);
    potion12 = new Potion("Potion12", 0, 0, -1, 0);
    potion13 = new Potion("Potion13", 0, 0, 0, -1);
    belt1 = new Belt(Size.SMALL, "belt1", 0, 1, 1, 0);
    belt2 = new Belt(Size.SMALL, "belt2", 1, 0, 1, 0);
    belt3 = new Belt(Size.SMALL, "belt3", 0, 0, 1, 1);
    belt4 = new Belt(Size.SMALL, "belt4", 0, 1, 0, 1);
    belt5 = new Belt(Size.SMALL, "belt5", 1, 0, 0, 1);
    belt6 = new Belt(Size.MEDIUM, "belt6", 0, 2, 2, 0);
    belt7 = new Belt(Size.MEDIUM, "belt7", 2, 0, 2, 0);
    belt8 = new Belt(Size.MEDIUM, "belt8", 0, 2, 0, 2);
    belt9 = new Belt(Size.MEDIUM, "belt9", 2, 0, 0, 2);
    belt10 = new Belt(Size.MEDIUM, "belt10", 0, 2, 0, 2);
    belt11 = new Belt(Size.LARGE, "belt11", 0, 3, 3, 0);
    belt12 = new Belt(Size.LARGE, "belt12", 3, 0, 0, 3);
    belt13 = new Belt(Size.LARGE, "belt13", 3, 0, 3, 0);
    belt14 = new Belt(Size.LARGE, "belt14", 0, 3, 0, 3);
    belt15 = new Belt(Size.LARGE, "belt15", 3, 0, 3, 0);
    playerOne = new Character("p1", 30, 30, 30, 30);
    playerTwo = new Character("p2", 40, 30, 40, 30);
    player3 = new Character("nicky", 40, 46, 40, 30);
    player4 = new Character("mere", 40, 30, 40, 30);
    neu = new BattleField(playerOne, playerTwo, 10, 10, 30, 30);
    neu.addHeadGear(head1);
    neu.addHeadGear(head2);
    neu.addHeadGear(head3);
    neu.addHeadGear(head4);
    neu.addHeadGear(head5);
    neu.addFootWear(foot1);
    neu.addFootWear(foot2);
    neu.addFootWear(foot3);
    neu.addFootWear(foot4);
    neu.addFootWear(foot5);
    neu.addFootWear(foot6);
    neu.addFootWear(foot7);
    neu.addFootWear(foot8);
    neu.addFootWear(foot9);
    neu.addFootWear(foot10);
    neu.addPotion(potion1);
    neu.addPotion(potion2);
    neu.addPotion(potion3);
    neu.addPotion(potion4);
    neu.addPotion(potion5);
    neu.addPotion(potion6);
    neu.addPotion(potion7);
    neu.addPotion(potion8);
    neu.addPotion(potion9);
    neu.addPotion(potion10);
    neu.addPotion(potion11);
    neu.addPotion(potion12);
    neu.addPotion(potion13);
    neu.addPotion(potion14);
    neu.addPotion(potion15);
    neu.addBelt(belt1);
    neu.addBelt(belt2);
    neu.addBelt(belt3);
    neu.addBelt(belt4);
    neu.addBelt(belt5);
    neu.addBelt(belt6);
    neu.addBelt(belt7);
    neu.addBelt(belt8);
    neu.addBelt(belt9);
    neu.addBelt(belt10);
    neu.addBelt(belt11);
    neu.addBelt(belt12);
    neu.addBelt(belt13);
    neu.addBelt(belt14);
    neu.addBelt(belt15);
    neu.buildGearBag();
    neu.addWeapon(a1);
    neu.addWeapon(a2);
    neu.addWeapon(f1);
    neu.addWeapon(f2);
    neu.addWeapon(s1);
    neu.addWeapon(s2);
    neu.addWeapon(s3);
    neu.addWeapon(s4);
    neu.buildArmory();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate() {
    Characters p1 = new Character("");
    Characters p2 = new Character(null);
    Characters p3 = new Character("nicky", 0, 0, 0, 0);
  }


  @Test
  public void testGetName() {
    assertEquals("p1", playerOne.getName());
    assertEquals("p2", playerTwo.getName());
    assertEquals("nicky", player3.getName());
    assertEquals("mere", player4.getName());
  }

  @Test
  public void testGetStrength() {
    assertEquals(30, playerOne.getStrength());
  }

  @Test
  public void testGetConstitution() {
    assertEquals(30, playerOne.getConstitution());
  }

  @Test
  public void testGetDexterity() {
    assertEquals(30, playerOne.getDexterity());
  }

  @Test
  public void testGetCharisma() {
    assertEquals(30, playerOne.getCharisma());
  }

  @Test
  public void testDressUp() {
    playerOne.gearUp(head1);
    playerOne.gearUp(potion1);
    playerOne.gearUp(belt1);
    playerOne.gearUp(foot1);
    playerOne.weaponUp(a1, playerOne);
    assertEquals("p1's info: 30 s(30 s), 34 d(30 d), 37 c(30 c)) 30 ch(30 ch) with 131 HP." +
            " Equipped Helm1 , Potion1 , belt1  and Foot1 . Wielded axe1 .", playerOne.toString());
  }

  @Test
  public void testGetFinal() {
    playerOne.gearUp(head1);
    playerOne.gearUp(potion1);
    playerOne.gearUp(belt1);
    playerOne.gearUp(foot1);
    playerOne.weaponUp(a1, playerOne);
    assertEquals(30, playerOne.getFinalStrength());
    assertEquals(34, playerOne.getFinalDexterity());
    assertEquals(30, playerOne.getFinalCharisma());
    assertEquals(37, playerOne.getFinalConstitution());
    assertEquals(131, playerOne.getHealth());
    assertTrue(playerOne.getLifeFlag());
    playerOne.setLifeFlag(false);
    assertFalse(playerOne.getLifeFlag());
  }

}