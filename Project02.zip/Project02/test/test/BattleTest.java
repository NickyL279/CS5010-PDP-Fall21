package test;

import org.junit.Before;
import org.junit.Test;

import battle.Battle;
import battle.BattleField;
import character.Character;
import character.Characters;
import gear.Belt;
import gear.FootWear;
import gear.Gear;
import gear.HeadGear;
import gear.Potion;
import gear.Size;
import weapon.Axes;
import weapon.Broadswords;
import weapon.Flails;
import weapon.Katanas;
import weapon.TwoHandedSwords;
import weapon.Weapon;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This class represents battle class's test.
 */
public class BattleTest {

  Gear head1;
  Gear head2;
  Gear foot1;
  Gear foot2;
  Gear foot6;
  Gear foot7;
  Gear potion1;
  Gear potion2;
  Gear potion3;
  Gear potion4;
  Gear potion10;
  Gear potion11;
  Gear potion12;
  Gear potion13;
  Gear belt1;
  Gear belt2;
  Gear belt3;
  Gear belt4;
  Gear belt5;
  Gear belt6;
  Gear belt7;
  Gear belt8;
  Gear belt9;
  Gear belt10;
  Gear belt11;
  Gear belt12;
  Gear belt13;
  Gear belt14;
  Gear belt15;
  Characters playerOne;
  Characters playerTwo;
  Characters player3;
  Characters player4;
  Battle neu;
  Gear head3 = new HeadGear("Helm3", 1);
  Gear head4 = new HeadGear("Helm4", 2);
  Gear head5 = new HeadGear("Helm5", -3);
  Gear foot3 = new FootWear("Foot3", 1);
  Gear foot4 = new FootWear("Foot4", 2);
  Gear foot5 = new FootWear("Foot5", -3);
  Gear foot8 = new FootWear("Foot3", 1);
  Gear foot9 = new FootWear("Foot4", 2);
  Gear foot10 = new FootWear("Foot5", -3);
  Gear potion5 = new Potion("Potion5", 1, 0, 0, 0);
  Gear potion6 = new Potion("Potion6", 0, 1, 0, 0);
  Gear potion7 = new Potion("Potion7", 0, 0, 1, 0);
  Gear potion8 = new Potion("Potion8", 0, 0, 0, 1);
  Gear potion9 = new Potion("Potion9", 2, 0, 0, 0);
  Gear potion14 = new Potion("Potion14", -1, 0, 0, 0);
  Gear potion15 = new Potion("Potion15", 0, 3, 0, 0);
  Weapon a1 = new Axes("axe1", 2211);
  Weapon a2 = new Axes("axe2", 14214);
  Weapon f1 = new Flails("flails1", 4124);
  Weapon f2 = new Flails("flails2", 412412);
  Weapon s1 = new Katanas("k1", 1434521);
  Weapon s2 = new Katanas("k1", 513515);
  Weapon s3 = new Broadswords("b1", 513515);
  Weapon s4 = new TwoHandedSwords("t1", 51531);

  @Before
  public void setUp() {
    head1 = new HeadGear("Helm1", 3);
    head2 = new HeadGear("Helm2", -4);
    foot1 = new FootWear("Foot1", 3);
    foot2 = new FootWear("Foot2", 4);
    foot6 = new FootWear("Foot2", 4);
    foot7 = new FootWear("Foot1", 3);
    potion1 = new Potion("Potion1", 0, 3, 0, 0);
    potion2 = new Potion("Potion2", 0, 0, 3, 0);
    potion3 = new Potion("Potion3", 3, 0, 0, 0);
    potion4 = new Potion("Potion4", 0, 0, 0, 3);
    potion10 = new Potion("Potion10", 0, -3, 0, 0);
    potion11 = new Potion("Potion11", -1, 0, 0, 0);
    potion12 = new Potion("Potion12", 0, 0, -1, 0);
    potion13 = new Potion("Potion13", 0, 0, 0, -1);
    belt1 = new Belt(Size.SMALL, "belt1", 0, 1, 1, 0);
    belt2 = new Belt(Size.SMALL, "belt2", 1, 0, 1, 0);
    belt3 = new Belt(Size.SMALL, "belt3", 0, 0, 1, 1);
    belt4 = new Belt(Size.SMALL, "belt4", 0, 1, 0, 1);
    belt5 = new Belt(Size.SMALL, "belt5", 1, 0, 0, 1);
    belt6 = new Belt(Size.MEDIUM, "belt6", 0, 2, 2, 0);
    belt7 = new Belt(Size.MEDIUM, "belt7", 2, 0, 2, 0);
    belt8 = new Belt(Size.MEDIUM, "belt8", 0, 2, 0, 2);
    belt9 = new Belt(Size.MEDIUM, "belt9", 2, 0, 0, 2);
    belt10 = new Belt(Size.MEDIUM, "belt10", 0, 2, 0, 2);
    belt11 = new Belt(Size.LARGE, "belt11", 0, 3, 3, 0);
    belt12 = new Belt(Size.LARGE, "belt12", 3, 0, 0, 3);
    belt13 = new Belt(Size.LARGE, "belt13", 3, 0, 3, 0);
    belt14 = new Belt(Size.LARGE, "belt14", 0, 3, 0, 3);
    belt15 = new Belt(Size.LARGE, "belt15", 3, 0, 3, 0);
    playerOne = new Character("p1", 30, 30, 30, 30);
    playerTwo = new Character("p2", 40, 30, 40, 30);
    player3 = new Character("nicky", 40, 46, 40, 30);
    player4 = new Character("mere", 40, 30, 40, 30);
    neu = new BattleField(playerOne, playerTwo, 10, 10, 30, 30);
    neu.addHeadGear(head1);
    neu.addHeadGear(head2);
    neu.addHeadGear(head3);
    neu.addHeadGear(head4);
    neu.addHeadGear(head5);
    neu.addFootWear(foot1);
    neu.addFootWear(foot2);
    neu.addFootWear(foot3);
    neu.addFootWear(foot4);
    neu.addFootWear(foot5);
    neu.addFootWear(foot6);
    neu.addFootWear(foot7);
    neu.addFootWear(foot8);
    neu.addFootWear(foot9);
    neu.addFootWear(foot10);
    neu.addPotion(potion1);
    neu.addPotion(potion2);
    neu.addPotion(potion3);
    neu.addPotion(potion4);
    neu.addPotion(potion5);
    neu.addPotion(potion6);
    neu.addPotion(potion7);
    neu.addPotion(potion8);
    neu.addPotion(potion9);
    neu.addPotion(potion10);
    neu.addPotion(potion11);
    neu.addPotion(potion12);
    neu.addPotion(potion13);
    neu.addPotion(potion14);
    neu.addPotion(potion15);
    neu.addBelt(belt1);
    neu.addBelt(belt2);
    neu.addBelt(belt3);
    neu.addBelt(belt4);
    neu.addBelt(belt5);
    neu.addBelt(belt6);
    neu.addBelt(belt7);
    neu.addBelt(belt8);
    neu.addBelt(belt9);
    neu.addBelt(belt10);
    neu.addBelt(belt11);
    neu.addBelt(belt12);
    neu.addBelt(belt13);
    neu.addBelt(belt14);
    neu.addBelt(belt15);
    neu.buildGearBag();
    neu.addWeapon(a1);
    neu.addWeapon(a2);
    neu.addWeapon(f1);
    neu.addWeapon(f2);
    neu.addWeapon(s1);
    neu.addWeapon(s2);
    neu.addWeapon(s3);
    neu.addWeapon(s4);
    neu.buildArmory();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate() {
    Battle neu1 = new BattleField(null, playerTwo, 10, 10, 30, 30);
    Battle neu2 = new BattleField(playerOne, null, 10, 10, 30, 30);
    Battle neu3 = new BattleField(playerOne, playerTwo, 4, 10, 30, 30);
    Battle neu4 = new BattleField(playerOne, playerTwo, 10, 4, 30, 30);
    Battle neu5 = new BattleField(playerOne, playerTwo, 10, 10, 14, 30);
    Battle neu6 = new BattleField(playerOne, playerTwo, 10, 10, 30, 14);
  }

  @Test
  public void testGetBattleFlag() {
    assertFalse(neu.getBattleFlag());
    playerOne.setLifeFlag(false);
    neu.getWinner(playerOne, playerTwo);
    assertTrue(neu.getBattleFlag());
  }

  @Test
  public void testGetLists() {
    assertEquals("[Name is Helm1 with 3 constitution, Name is Helm2 with -4 constitution," +
            " Name is Helm3 with 1 constitution, Name is Helm4 with 2 constitution, Name is" +
            " Helm5 with -3 constitution]", neu.getHeadList().toString());
    assertEquals("[Name is belt1 (size: 1) with 0 s, 1 d, 1 c, 0 ch, Name is belt2 (size: 1)" +
            " with 1 s, 1 d, 0 c, 0 ch, Name is belt3 (size: 1) with 0 s, 1 d, 0 c, 1 ch, Name " +
            "is belt4 (size: 1) with 0 s, 0 d, 1 c, 1 ch, Name is belt5 (size: 1) with 1 s, 0 d," +
            " 0 c, 1 ch, Name is belt6 (size: 2) with 0 s, 2 d, 2 c, 0 ch," +
            " Name is belt7 (size: 2)" +
            " with 2 s, 2 d, 0 c, 0 ch, Name is belt8 (size: 2) with 0 s, 0 d, 2 c, 2 ch, Name is" +
            " belt9 (size: 2) with 2 s, 0 d, 0 c, 2 ch, Name is belt10 (size: 2) with 0 s, 0 d," +
            " 2 c, 2 ch, Name is belt11 (size: 4) with 0 s, 3 d, 3 c, 0 ch, Name is belt12" +
            " (size: 4) with 3 s, 0 d, 0 c, 3 ch, Name is belt13 (size: 4) with 3 s, 3 d, 0 c," +
            " 0 ch, Name is belt14 (size: 4) with 0 s, 0 d, 3 c, 3 ch, Name is belt15 (size: 4)" +
            " with 3 s, 3 d, 0 c, 0 ch]", neu.getBeltList().toString());
    assertEquals("[Name is Potion1 with 0 s, 0 d, 3 c, 0 ch, Name is Potion2 with 0 s, 3 d, 0 c," +
            " 0 ch, Name is Potion3 with 3 s, 0 d, 0 c, 0 ch, Name is Potion4 with 0 s, 0 d, 0 c," +
            " 3 ch, Name is Potion5 with 1 s, 0 d, 0 c, 0 ch, Name is Potion6 with 0 s, 0 d, 1 c," +
            " 0 ch, Name is Potion7 with 0 s, 1 d, 0 c, 0 ch, Name is Potion8 with 0 s, 0 d, 0 c," +
            " 1 ch, Name is Potion9 with 2 s, 0 d, 0 c, 0 ch, Name is Potion10 with 0 s, 0 d," +
            " -3 c, 0 ch, Name is Potion11 with -1 s, 0 d, 0 c, 0 ch, Name is Potion12 with 0 s," +
            " -1 d, 0 c, 0 ch, Name is Potion13 with 0 s, 0 d, 0 c, -1 ch, Name is Potion14" +
            " with -1 s, 0 d, 0 c, 0 ch, Name is Potion15 with 0 s, 0 d, 3 c, 0 ch]",
            neu.getPotionList().toString());
    assertEquals("[Name is Foot1 with 3 dexterity, Name is Foot2 with 4 dexterity, Name is" +
            " Foot3 with 1 dexterity, Name is Foot4 with 2 dexterity, Name is Foot5 with -3" +
            " dexterity, Name is Foot2 with 4 dexterity, Name is Foot1 with 3 dexterity, Name" +
            " is Foot3 with 1 dexterity, Name is Foot4 with 2 dexterity, Name is Foot5 with -3" +
            " dexterity]", neu.getFootList().toString());
    assertEquals("[Name is Helm1 with 3 constitution, Name is Helm2 with -4 constitution, Name" +
            " is Helm3 with 1 constitution, Name is Helm4 with 2 constitution, Name is Helm5 with" +
            " -3 constitution, Name is Potion1 with 0 s, 0 d, 3 c, 0 ch, Name is Potion10" +
            " with 0 s, 0 d, -3 c, 0 ch, Name is Potion11 with -1 s, 0 d, 0 c, 0 ch, Name is" +
            " Potion12 with 0 s, -1 d, 0 c, 0 ch, Name is Potion13 with 0 s, 0 d, 0 c, -1 ch," +
            " Name is Potion14 with -1 s, 0 d, 0 c, 0 ch, Name is Potion15 with 0 s, 0 d, 3 c," +
            " 0 ch, Name is Potion2 with 0 s, 3 d, 0 c, 0 ch, Name is Potion3 with 3 s, 0 d, 0 c," +
            " 0 ch, Name is Potion4 with 0 s, 0 d, 0 c, 3 ch, Name is Potion5 with 1 s, 0 d," +
            " 0 c, 0 ch, Name is Potion6 with 0 s, 0 d, 1 c, 0 ch, Name is Potion7 with 0 s," +
            " 1 d, 0 c, 0 ch, Name is Potion8 with 0 s, 0 d, 0 c, 1 ch, Name is Potion9 with 2 s," +
            " 0 d, 0 c, 0 ch, Name is belt1 (size: 1) with 0 s, 1 d, 1 c, 0 ch, Name is belt10" +
            " (size: 2) with 0 s, 0 d, 2 c, 2 ch, Name is belt11 (size: 4) with 0 s, 3 d, 3 c," +
            " 0 ch, Name is belt12 (size: 4) with 3 s, 0 d, 0 c, 3 ch, Name is belt13 (size: 4)" +
            " with 3 s, 3 d, 0 c, 0 ch, Name is belt14 (size: 4) with 0 s, 0 d, 3 c, 3 ch," +
            " Name is belt15 (size: 4) with 3 s, 3 d, 0 c, 0 ch, Name is belt2 (size: 1)" +
            " with 1 s, 1 d, 0 c, 0 ch, Name is belt3 (size: 1) with 0 s, 1 d, 0 c, 1 ch," +
            " Name is belt4 (size: 1) with 0 s, 0 d, 1 c, 1 ch, Name is belt5 (size: 1) with" +
            " 1 s, 0 d, 0 c, 1 ch, Name is belt6 (size: 2) with 0 s, 2 d, 2 c, 0 ch, Name is" +
            " belt7 (size: 2) with 2 s, 2 d, 0 c, 0 ch, Name is belt8 (size: 2) with 0 s, 0 d," +
            " 2 c, 2 ch, Name is belt9 (size: 2) with 2 s, 0 d, 0 c, 2 ch, Name is Foot1 with" +
            " 3 dexterity, Name is Foot1 with 3 dexterity, Name is Foot2 with 4 dexterity," +
            " Name is Foot2 with 4 dexterity, Name is Foot3 with 1 dexterity, Name is Foot3" +
            " with 1 dexterity, Name is Foot4 with 2 dexterity, Name is Foot4 with 2 dexterity," +
            " Name is Foot5 with -3 dexterity, Name is Foot5 with -3 dexterity]",
            neu.getGearBag().toString());
    assertEquals("[axe1 is a AXES (9 damage), axe2 is a AXES (7 damage), flails1 is a" +
            " FLAILS (8 damage), flails2 is a FLAILS (10 damage), k1 is a SWORDS (5 damage)," +
            " k1 is a SWORDS (5 damage), b1 is a SWORDS (9 damage), t1 is a SWORDS (10 damage)]",
            neu.getArmory().toString());
  }

  @Test
  public void testGetPlayers() {
    assertEquals("p1", neu.getCurPlayer().getName());
    assertEquals("p2", neu.getNextPlayer().getName());
  }

  @Test
  public void testAttack() {
    neu.attack();
    assertEquals("No winner yet", neu.getStatus());
  }
}
