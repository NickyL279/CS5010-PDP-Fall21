package test;

import org.junit.Before;
import org.junit.Test;

import battle.Battle;
import battle.BattleField;
import character.Character;
import character.Characters;
import weapon.Axes;
import weapon.Broadswords;
import weapon.Flails;
import weapon.Katanas;
import weapon.TwoHandedSwords;
import weapon.Weapon;

import static org.junit.Assert.assertEquals;

/**
 * This class represents weapon classes' test.
 */
public class WeaponTest {
  Characters playerOne = new Character("p1");
  Characters playerTwo = new Character("p2");
  Battle neu = new BattleField(playerOne, playerTwo, 10, 10, 30, 30);
  Weapon a1 = new Axes("axe1", 2211);
  Weapon a2 = new Axes("axe2", 14214);
  Weapon f1 = new Flails("flails1", 4124);
  Weapon f2 = new Flails("flails2", 412412);
  Weapon s1 = new Katanas("k1", 1434521);
  Weapon s2 = new Katanas("k1", 513515);
  Weapon s3 = new Broadswords("b1", 513515);
  Weapon s4 = new TwoHandedSwords("t1", 51531);


  @Before
  public void setUp() {
    neu.addWeapon(a1);
    neu.addWeapon(a2);
    neu.addWeapon(f1);
    neu.addWeapon(f2);
    neu.addWeapon(s1);
    neu.addWeapon(s2);
    neu.addWeapon(s3);
    neu.addWeapon(s4);
    neu.buildArmory();
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateAxes() {
    Weapon a1 = new Axes("");
    Weapon a2 = new Axes(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateBSword() {
    Weapon s3 = new Broadswords("");
    Weapon s4 = new Broadswords(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateFlails() {
    Weapon f1 = new Flails("");
    Weapon f2 = new Flails(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateKatanas() {
    Weapon s1 = new Katanas("");
    Weapon s2 = new Katanas(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCreateTSwords() {
    Weapon s4 = new TwoHandedSwords("");
    Weapon s5 = new TwoHandedSwords(null);
  }

  @Test
  public void getWeaponType() {
    assertEquals("AXES", a1.getWeaponType().toString());
    assertEquals("FLAILS", f1.getWeaponType().toString());
    assertEquals("SWORDS", s1.getWeaponType().toString());
    assertEquals("SWORDS", s3.getWeaponType().toString());
    assertEquals("SWORDS", s4.getWeaponType().toString());
  }

  @Test
  public void getDamage() {
    Characters p111 = new Character("nickll", 12, 12, 12, 12);
    Characters p222 = new Character("nickll", 15, 15, 15, 15);
    Weapon aaa = new Axes("aaa1", 1020);
    assertEquals(8, aaa.getDamage(p111));
    Weapon fff = new Flails("fff1", 20100);
    assertEquals(4, fff.getDamage(p111));
    Weapon sss1 = new Katanas("ss1", 515131);
    assertEquals(5, sss1.getDamage(p111));
    Weapon sss2 = new Broadswords("sss1", 151355135);
    assertEquals(9, sss2.getDamage(p111));
    Weapon ssss3 = new TwoHandedSwords("ssss1", 414123123);
    assertEquals(4, ssss3.getDamage(p111));

    assertEquals(8, aaa.getDamage(p222));
    assertEquals(9, fff.getDamage(p222));
    assertEquals(5, sss1.getDamage(p222));
    assertEquals(9, sss2.getDamage(p222));
    assertEquals(9, ssss3.getDamage(p222));
  }

  @Test
  public void checkType() {
    assertEquals(false, a1.checkType());
    assertEquals(false, f1.checkType());
    assertEquals(true, s1.checkType());
    assertEquals(false, s3.checkType());
    assertEquals(false, s4.checkType());
  }

  @Test
  public void getArmory() {
    assertEquals("[axe1 is a AXES (9 damage), axe2 is a AXES (7 damage), flails1 is a FLAILS" +
                    " (8 damage), flails2 is a FLAILS (10 damage), k1 is a SWORDS (5 damage)," +
                    " k1 is a SWORDS (5 damage), b1 is a SWORDS (9 damage), t1 is a " +
                    "SWORDS (10 damage)]",
            neu.getArmory().toString());
  }

  @Test
  public void testInvalidAxes() {
    Characters playerOne = new Character("p1", 40, 40, 40, 40);
    playerOne.weaponUp(a1, playerOne);
    playerOne.weaponUp(a2, playerOne);
    assertEquals("p1's info: 40 s(40 s), 40 d(40 d), 40 c(40 c)) 40 ch(40 ch) with 160 HP." +
            " Equipped , ,  and . Wielded axe1 .", playerOne.toString());
  }

  @Test
  public void testInvalidFlails() {
    Characters playerOne = new Character("p1", 40, 40, 40, 40);
    playerOne.weaponUp(f1, playerOne);
    playerOne.weaponUp(f2, playerOne);
    assertEquals("p1's info: 40 s(40 s), 40 d(40 d), 40 c(40 c)) 40 ch(40 ch) with 160 HP." +
            " Equipped , ,  and . Wielded flails1 .", playerOne.toString());
  }

  @Test
  public void testInvalidSwords() {
    Characters playerOne = new Character("p1", 40, 40, 40, 40);
    Weapon s5 = new Broadswords("b41", 513515);
    playerOne.weaponUp(s3, playerOne);
    playerOne.weaponUp(s5, playerOne);
    assertEquals("p1's info: 40 s(40 s), 40 d(40 d), 40 c(40 c)) 40 ch(40 ch) with 160 HP." +
            " Equipped , ,  and . Wielded b1 .", playerOne.toString());
  }

  @Test
  public void testInvalidSwords1() {
    Characters playerOne = new Character("p1", 40, 40, 40, 40);
    Weapon s6 = new TwoHandedSwords("t41", 51531);
    playerOne.weaponUp(s4, playerOne);
    playerOne.weaponUp(s6, playerOne);
    assertEquals("p1's info: 40 s(40 s), 40 d(40 d), 40 c(40 c)) 40 ch(40 ch) with 160 HP." +
            " Equipped , ,  and . Wielded t1 .", playerOne.toString());
  }

  @Test
  public void testWearTwoKatanas() {
    Characters playerOne = new Character("p1", 40, 40, 40, 40);
    playerOne.weaponUp(s1, playerOne);
    playerOne.weaponUp(s2, playerOne);
    assertEquals("p1's info: 40 s(40 s), 40 d(40 d), 40 c(40 c)) 40 ch(40 ch) with 160 HP." +
            " Equipped , ,  and . Wielded k1  k1 .", playerOne.toString());
  }
}