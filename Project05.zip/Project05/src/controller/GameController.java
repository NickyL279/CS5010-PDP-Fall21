package controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import model.Directions;
import model.Dungeons;
import model.Status;
import model.UnwrappedDungeon;
import model.WrappedDungeon;

/**
 * Represents a Controller for Dungeon Game: handle user moves, shoots and picks by executing them
 * using the model.
 */
public class GameController implements Controller {
  private final Appendable out;
  private final Scanner scan;
  private final int rows;
  private final int cols;
  private final int interConnect;
  private final int type;
  private final int perTreasure;
  private final int perArrow;
  private final int monsNum;
  private final int seed;

  /**
   * Constructor for the controller.
   *
   * @param in      the source to read from
   * @param out     the target to print to
   */
  public GameController(Readable in, Appendable out, String[] strings) {
    if (in == null || out == null) {
      throw new IllegalArgumentException("Readable and Appendable can't be null");
    }
    rows = Integer.parseInt(strings[0]);
    cols = Integer.parseInt(strings[1]);
    if (rows <= 0 || cols <= 0 || rows * cols < 5) {
      throw new IllegalArgumentException("Bad size of dungeon! Should be larger than 4 cells!");
    }
    interConnect = Integer.parseInt(strings[2]);
    if (interConnect < 0) {
      throw new IllegalArgumentException("Bad interconnectivity! Should be larger than 0");
    }
    type = Integer.parseInt(strings[3]);
    if (type != 1 && type != 2) {
      throw new IllegalArgumentException("Wrong type!");
    }
    int tmp = (rows - 1) * cols + (cols - 1) * rows - rows * cols;
    if (type == 1 && (interConnect > tmp + 1 + rows + cols)) {
      throw new IllegalArgumentException("Bad interconnectivity! Should be lesser!");
    }
    if (type == 2 && (interConnect > tmp + 1)) {
      throw new IllegalArgumentException("Bad interconnectivity! Should be lesser!");
    }
    perTreasure = Integer.parseInt(strings[4]);
    if (perTreasure < 20 || perTreasure > 100) {
      throw new IllegalArgumentException("Bad percentage! Should be great than 20 and"
              + " less than 100.");
    }
    perArrow = Integer.parseInt(strings[5]);
    if (perArrow < 0 || perArrow > 100) {
      throw new IllegalArgumentException("Bad percentage! Should be great than 0 and"
              + " less than 100.");
    }
    monsNum = Integer.parseInt(strings[6]);
    if (monsNum <= 0 || monsNum > rows * cols - 1) {
      throw new IllegalArgumentException("The dungeon should have at least 1 monster.");
    }
    seed = Integer.parseInt(strings[7]);
    this.out = out;
    scan = new Scanner(in);
  }

  @Override
  public void playGame() throws IOException {
    //    out.append("Please insert rows: ").append("\n");
    //    int rows = scan.nextInt();
    //    out.append("Please insert columns: ").append("\n");
    //    int cols = scan.nextInt();
    //    out.append("Please insert interconnectivity: ").append("\n");
    //    int interConnect = scan.nextInt();
    //    out.append("Please insert seed: ").append("\n");
    //    int seed = scan.nextInt();
    //    out.append("Please choose the dungeon type: ").append("\n");
    //    int type = scan.nextInt();
    Dungeons dungeonGraph;
    switch (type) {
      case 1:
        dungeonGraph = new WrappedDungeon(rows, cols, interConnect, seed);
        break;
      case 2:
        dungeonGraph = new UnwrappedDungeon(rows, cols, interConnect, seed);
        break;
      default:
        throw new IllegalArgumentException("Wrong type!");
    }
    dungeonGraph.generate();
    //    out.append("Please insert treasure percentage: ").append("\n");
    //    int perTreasure = scan.nextInt();
    dungeonGraph.addTreasure(perTreasure);
    //    out.append("Please insert arrow percentage: ").append("\n");
    //    int perArrow = scan.nextInt();
    dungeonGraph.addArrow(perArrow);
    //Dungeons dungeonGame = new Dungeon(dungeonGraph.getCellMap());
    //    out.append("Please insert monster number: ").append("\n");
    //    int monsNum = scan.nextInt();
    dungeonGraph.addMonster(monsNum);
    try {
      //                  out.append("The item map of this dungeon:").append("\n")
      //                          .append(dungeonGraph.toString()).append("\n");
      //                  out.append("The cave map of this dungeon:").append("\n")
      //                          .append(dungeonGraph.graphBuilder()).append("\n");
      //                  out.append("The monster position of this dungeon:")
      //                          .append(dungeonGraph.getMonsters()).append("\n");
      //                  out.append("The player's start point is: ")
      //                          .append(Arrays.toString(dungeonGraph.getStart())).append("\n");
      //                  out.append("The player's goal point is: ")
      //                          .append(Arrays.toString(dungeonGraph.getEnd())).append("\n");
      out.append("Welcome to the dungeon!").append("\n");
      label:
      while (!dungeonGraph.checkReachEnd() && dungeonGraph.getPlayerStatus() == Status.ALIVE) {
        out.append("You smell").append(dungeonGraph.smellMonster()).append("\n");
        if (dungeonGraph.getThisCellDiamond() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGraph.getThisCellDiamond()))
                  .append(" treasure here").append("\n");
        }
        if (dungeonGraph.getThisCellRuby() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGraph.getThisCellRuby()))
                  .append(" treasure here").append("\n");
        }
        if (dungeonGraph.getThisCellSap() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGraph.getThisCellSap()))
                  .append(" treasure here").append("\n");
        }
        if (dungeonGraph.getThisCellArrow() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGraph.getThisCellArrow()))
                  .append(" arrow here").append("\n");
        }
        out.append(dungeonGraph.getCellType()).append("\n");
        out.append("Doors lead to the ")
                .append(Arrays.toString(dungeonGraph.getPosDirections().toArray()).replace("[", "")
                        .replace("]", "")).append("\n");
        out.append("Move, Pickup, or Shoot (M-P-S)?").append("\n");
        String choice = scan.next().toUpperCase();
        switch (choice) {
          case "Q":
            try {
              out.append("Game quit!").append("\n")
                      .append("You collected ").append(String.valueOf(dungeonGraph.getCurrentDia()))
                      .append(" diamond(s)").append("\n")
                      .append("You collected ").append(String.valueOf(dungeonGraph.getCurrentRub()))
                      .append(" rubie(s)").append("\n")
                      .append("You collected ").append(String.valueOf(dungeonGraph.getCurrentSap()))
                      .append(" sapphire(s)").append("\n");
            } catch (IOException ioe) {
              throw new IllegalStateException("Append failed", ioe);
            }
            break label;
          case "MOVE":
          case "MO":
          case "MOV":
          case "MOVING":
            choice = "M";
            break;
          case "PICK":
          case "PIC":
          case "PI":
          case "PICKING":
            choice = "P";
            break;
          case "SHOOT":
          case "SHOT":
          case "SHO":
          case "SHOOTING":
          case "SHOTING":
            choice = "S";
            break;
          default:
        }
        switch (choice) {
          case "M":
            out.append("Enter the direction:").append("\n");
            String tmpDirection = scan.next().toLowerCase().trim();
            try {
              dungeonGraph.move(tmpDirection);
            } catch (IllegalStateException illegalStateException) {
              out.append("Invalid direction! Try move again!").append("\n");
            } catch (IllegalArgumentException illegalArgumentException) {
              out.append("Cannot move to this position! Try move again!").append("\n");
            }
            break;
          case "P":
            dungeonGraph.pickTreasure();
            dungeonGraph.pickArrow();
            break;
          case "S":
            out.append("Direction and distance?").append("\n");
            String tmpDirectionShoot = scan.next().toLowerCase().trim();
            Directions d;
            try {
              switch (tmpDirectionShoot) {
                case "north":
                  d = Directions.NORTH;
                  break;
                case "south":
                  d = Directions.SOUTH;
                  break;
                case "west":
                  d = Directions.WEST;
                  break;
                case "east":
                  d = Directions.EAST;
                  break;
                default:
                  throw new IllegalArgumentException("Invalid direction!");
              }
            } catch (IllegalArgumentException illegalArgumentException) {
              out.append("Invalid direction! Try shoot again!").append("\n");
              break;
            }
            int dis = Integer.parseInt(scan.next());
            try {
              out.append(dungeonGraph.shootArrow(d, dis)).append("\n");
              break;
            } catch (IllegalArgumentException illegalArgumentException) {
              out.append("Too far! Shoot between 1 - 5").append("\n");
              break;
            }
          default:
            try {
              out.append("Invalid operation, try again").append("\n");
            } catch (IOException e) {
              throw new IllegalStateException("Append failed", e);
            }
            break;
        }
      }
      if (dungeonGraph.getPlayerStatus().equals(Status.DEAD)) {
        try {
          out.append("Chomp, chomp, chomp, you are eaten by an Otyugh!").append("\n");
        } catch (IOException e) {
          throw new IllegalStateException("Append failed", e);
        }
      } else if (dungeonGraph.checkReachEnd()) {
        try {
          out.append("Whoa, Whoa, Whoa, you reached the goal point!").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGraph.getCurrentDia()))
                  .append(" diamond(s)").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGraph.getCurrentRub()))
                  .append(" rubie(s)").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGraph.getCurrentSap()))
                  .append(" sapphire(s)").append("\n");
        } catch (IOException e) {
          throw new IllegalStateException("Append failed", e);
        }
      }
    } catch (IOException e) {
      throw new IllegalStateException("Append failed", e);
    } catch (NumberFormatException e) {
      try {
        out.append("Invalid option!").append("\n");
      } catch (IOException e1) {
        throw new IllegalStateException("Append failed", e1);
      }
    }
  }
}