package controller;

import java.awt.Component;
import model.Directions;

/**
 * Represents a Controller for Dungeon Game: handle user moves, shoots and picks by executing them
 * using the model.
 */
public interface GuiControllers {
  void start();

  void createDungeon(String rows, String cols, String interconnect, String seed, String type,
                     String perTreasure, String perArrow, String monsNum, String pitNum,
                     String thiefNum);

  void pick();

  void move(Directions direction);

  void shoot();

  void endGame();

  void stopGame();

  void startNew();

  void startSame();

  void clickHelper(int id);

  void popupHelper(Component component, int id);
}
