package controller;

import java.awt.Component;
import model.Directions;
import model.Dungeons;
import model.Status;
import model.UnwrappedDungeon;
import model.WrappedDungeon;
import view.View;

/**
 * Represents a GUI controller of Dungeon Game. Reach the end cave alive win, eaten by monster
 * lose.
 */
public class GuiController implements GuiControllers {
  private final View view;
  private Dungeons model;
  private int type;
  private int rows;
  private int cols;
  private int perTreasure;
  private int perArrow;
  private int monsNum;
  private int pitNum;
  private int interconnect;
  private int seed;
  private int thiefNum;

  /**
   * Constructor for swing controller.
   *
   * @param view the view to use
   */
  public GuiController(View view) {
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null!");
    }
    this.view = view;
  }

  @Override
  public void start() {
    view.setCommands(this);
  }

  @Override
  public void createDungeon(String rows, String cols, String interconnect, String seed, String type,
                            String perTreasure, String perArrow, String monsNum, String pitNum,
                            String thiefNum) {
    if (rows.isEmpty()) {
      this.rows = 4;
    }
    if (cols.isEmpty()) {
      this.cols = 6;
    }
    if (interconnect.isEmpty()) {
      this.interconnect = 12;
    }
    if (seed.isEmpty()) {
      this.seed = 666;
    }
    if (type.isEmpty()) {
      this.type = 1;
    }
    if (perTreasure.isEmpty()) {
      this.perTreasure = 45;
    }
    if (perArrow.isEmpty()) {
      this.perArrow = 45;
    }
    if (monsNum.isEmpty()) {
      this.monsNum = 1;
    }
    if (pitNum.isEmpty()) {
      this.pitNum = 1;
    }
    if (pitNum.isEmpty()) {
      this.thiefNum = 1;
    }
    this.rows = Integer.parseInt(rows);
    this.cols = Integer.parseInt(cols);
    this.interconnect = Integer.parseInt(interconnect);
    this.seed = Integer.parseInt(seed);
    this.type = Integer.parseInt(type);
    this.perTreasure = Integer.parseInt(perTreasure);
    this.perArrow = Integer.parseInt(perArrow);
    this.monsNum = Integer.parseInt(monsNum);
    this.pitNum = Integer.parseInt(pitNum);
    this.thiefNum = Integer.parseInt(thiefNum);
    generateDungeon();
    view.setModel(model);
    view.removeSetPanel();
    view.showDungeon();
    view.setDungeonCommand(this);
    view.resetFocus();
  }

  private void generateDungeon() {
    if (type == 1) {
      this.model = new WrappedDungeon(rows, cols, interconnect, seed);
      model.generate();
      model.addTreasure(perTreasure);
      model.addArrow(perArrow);
      model.addMonster(monsNum);
      model.addPit(pitNum);
      model.addThief(thiefNum);
    } else if (type == 2) {
      this.model = new UnwrappedDungeon(rows, cols, interconnect, seed);
      model.generate();
      model.addTreasure(perTreasure);
      model.addArrow(perArrow);
      model.addMonster(monsNum);
      model.addPit(pitNum);
      model.addThief(thiefNum);
    }
  }

  @Override
  public void pick() {
    try {
      model.pickTreasure();
      model.pickArrow();
      view.refreshItemsBar();
      view.refreshAfterPick();
    } catch (Exception e) {
      //do nothing
    }
  }

  @Override
  public void move(Directions direction) {
    if (direction == null) {
      throw new IllegalArgumentException("Direction cannot be null!");
    }
    try {
      model.move(direction.toString());
      view.refreshAfterMove();
      view.refreshItemsBar();
      view.resetFocus();
    } catch (Exception e) {
      //do nothing
    }
    if (model.checkReachEnd()) {
      if (model.getPlayerStatus().equals(Status.DEAD)) {
        view.displayResult("Chomp, chomp, chomp, you are eaten by an Otyugh!");
      } else if (model.getPlayerStatus().equals(Status.FALLDEAD)) {
        view.displayResult("Shot, shot, shot, you fell into a pit!");
      } else {
        view.displayResult("Whoa, Whoa, Whoa, you reached the goal point!");
      }
      endGame();
    } else {
      if (model.getPlayerStatus().equals(Status.DEAD)) {
        view.displayResult("Chomp, chomp, chomp, you are eaten by an Otyugh!");
        endGame();
      } else if (model.getPlayerStatus().equals(Status.FALLDEAD)) {
        view.displayResult("Shot, shot, shot, you fell into a pit!");
        endGame();
      }
    }
  }

  @Override
  public void shoot() {
    try {
      Directions[] directions = model.getPosDirections().toArray(new Directions[0]);
      Directions direction = view.showShootOptions(directions);
      Integer[] distances = {1, 2, 3, 4, 5};
      Integer distance = view.showDistanceOptions(distances);
      if (direction == null || distance == null) {
        return;
      }
      view.refreshAfterShoot(model.shootArrow(direction, distance));
      view.refreshItemsBar();
    } catch (Exception e) {
      //do nothing
    }
  }

  @Override
  public void endGame() {
    view.removeDungeonPanel();
    view.showEnd();
  }

  @Override
  public void stopGame() {
    view.removeDungeonPanel();
    view.addSet();
  }

  @Override
  public void startNew() {
    view.removeEndPanel();
    view.removeDungeonPanel();
    view.addSet();
  }

  @Override
  public void startSame() {
    view.removeEndPanel();
    view.removeDungeonPanel();
    generateDungeon();
    view.setModel(model);
    view.showDungeon();
    view.setDungeonCommand(this);
    view.resetFocus();
  }

  @Override
  public void clickHelper(int id) {
    if (id < 0) {
      throw new IllegalArgumentException("Id is invalid!");
    }
    if (directionHelper(id) != null) {
      move(directionHelper(id));
    }
  }

  private Directions directionHelper(int id) {
    Directions direction = null;
    if (model.getSurroundingIds(model.getCurCellId()).contains(id)) {
      if (model.getCurrentCell().getNorth() != null
              && id == model.getCurrentCell().getNorth().getId()) {
        direction = Directions.NORTH;
      } else if (model.getCurrentCell().getSouth() != null
              && id == model.getCurrentCell().getSouth().getId()) {
        direction = Directions.SOUTH;
      } else if (model.getCurrentCell().getEast() != null
              && id == model.getCurrentCell().getEast().getId()) {
        direction = Directions.EAST;
      } else if (model.getCurrentCell().getWest() != null
              && id == model.getCurrentCell().getWest().getId()) {
        direction = Directions.WEST;
      }
    }
    return direction;
  }

  @Override
  public void popupHelper(Component component, int id) {
    if (component == null) {
      throw new IllegalArgumentException("Component cannot be null!");
    }
    if (id < 0) {
      throw new IllegalArgumentException("Id is invalid!");
    }
    if (id == model.getCurCellId()) {
      view.showPopup(component);
    }
  }
}
