package view;

import java.awt.Component;
import java.io.IOException;
import controller.GuiController;
import model.Directions;
import model.ReadonlyModel;

/**
 * Represents a mock view using swing of Dungeon Game. Reach the end cave alive win, eaten by
 * monster lose.
 */
public class MockView implements View{
  private Appendable log;

  /**
   * Primary constructor that creates a new instance of a DungeonView.
   *
   * @param log the log to all the view operations.
   */
  public MockView(Appendable log) {
    this.log = log;
  }

  @Override
  public void removeSetPanel() {
    try {
      log.append("removeSetPanel\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void removeDungeonPanel() {
    try {
      log.append("removeDungeonPanel\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void removeEndPanel() {
    try {
      log.append("removeEndPanel\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void setModel(ReadonlyModel model) {
    try {
      log.append("setModel\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void resetFocus() {
    try {
      log.append("resetFocus\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void addSet() {
    try {
      log.append("addSet\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void refreshAfterPick() {
    try {
      log.append("refreshAfterPick\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void refreshAfterMove() {
    try {
      log.append("refreshAfterMove\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void refreshAfterShoot(String shootResult) {
    try {
      log.append("refreshAfterShoot\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public Directions showShootOptions(Directions[] options) {
    try {
      log.append("showShootOptions\n");
    } catch (IOException e) {
      // do nothing
    }
    return null;
  }

  @Override
  public Integer showDistanceOptions(Integer[] options) {
    try {
      log.append("showDistanceOptions\n");
    } catch (IOException e) {
      // do nothing
    }
    return null;
  }

  @Override
  public void setCommands(GuiController guiController) {
    try {
      log.append("setCommands\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void showEnd() {
    try {
      log.append("showEnd\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void showDungeon() {
    try {
      log.append("showDungeon\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void refreshItemsBar() {
    try {
      log.append("refreshItemsBar\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void setDungeonCommand(GuiController guiController) {
    try {
      log.append("setDungeonCommand\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void displayResult(String s) {
    try {
      log.append("displayResult\n");
    } catch (IOException e) {
      // do nothing
    }
  }

  @Override
  public void showPopup(Component component) {
    try {
      log.append("showPopup\n");
    } catch (IOException e) {
      // do nothing
    }
  }
}
