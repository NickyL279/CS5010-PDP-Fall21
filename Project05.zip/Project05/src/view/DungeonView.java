package view;

import controller.GuiController;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.Spring;
import javax.swing.SpringLayout;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import model.Cells;
import model.Directions;
import model.Obstacles;
import model.ReadonlyModel;

/**
 * Represents a view using swing of Dungeon Game. Reach the end cave alive win, eaten by monster
 * lose.
 */
public class DungeonView extends JFrame implements View {
  private final JPanel setPanel;
  private final JButton create;
  private final JTextField[] createEntries;
  private final JMenuItem startNew;
  private final JMenuItem startSame;
  private final JMenuItem stopGame;
  private final JPopupMenu popup;
  private final JMenuItem shoot;
  private final JMenuItem pick;
  private final JPanel itemBar;
  private final JLabel arrowItem;
  private final JLabel playerItem;
  private final JLabel diamond;
  private final JLabel ruby;
  private final JLabel sapphire;
  private ReadonlyModel model;
  private BufferedImage[] dungeonImage;
  private boolean[] visitedCell;
  private JPanel dungeonPanel;
  private JButton[] dungeonCell;
  private JPanel endPanel;
  private JScrollPane sp;

  /**
   * Primary constructor that creates a new instance of a DungeonView.
   *
   * @param title The Dungeon reference passed in that is visualized by this view.
   */
  public DungeonView(String title) {
    super(title);
    //this.setPreferredSize(new Dimension(600, 500));
    this.setLocation(1000, 300);
    this.setMaximumSize(new Dimension(600, 500));
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JMenuBar menuBar = new JMenuBar();
    JMenu restart = new JMenu("Start");
    menuBar.add(restart);
    this.stopGame = new JMenuItem("Stop game");
    restart.add(stopGame);
    this.startNew = new JMenuItem("New game");
    restart.add(startNew);
    this.startSame = new JMenuItem("Same game");
    restart.add(startSame);
    this.setJMenuBar(menuBar);
    this.popup = new JPopupMenu();
    this.shoot = new JMenuItem("Shoot", KeyEvent.VK_T);
    popup.add(shoot);
    this.pick = new JMenuItem("Pick", KeyEvent.VK_P);
    popup.add(pick);
    this.endPanel = new JPanel();
    JPanel panel1 = new JPanel(new SpringLayout());
    String[] texts = {"Rows: ", "Columns: ", "Interconnectivity: ", "Seed", "Type: ",
        "Treasure percent: ", "Arrow percent: ", "Monster number: ", "Pit number: ",
        "Thief number: "};
    String[] preSet = {"4", "6", "12", "666", "1", "20", "20", "1", "1", "1"};
    int tmpNum = texts.length;
    this.createEntries = new JTextField[tmpNum];
    for (int i = 0; i < tmpNum; i++) {
      JLabel l = new JLabel(texts[i]);
      panel1.add(l);
      JTextField textField = new JTextField(preSet[i], 10);
      l.setLabelFor(textField);
      createEntries[i] = textField;
      panel1.add(textField);
    }
    makeCompactGrid(panel1, tmpNum, 2, 5, 5, 5, 5);
    JPanel panel2 = new JPanel();
    create = new JButton("Create Dungeon");
    create.setActionCommand("Create");
    panel2.add(create);
    panel2.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
    setPanel = new JPanel();
    setPanel.setLayout(new BoxLayout(setPanel, BoxLayout.PAGE_AXIS));
    setPanel.add(panel1);
    setPanel.add(panel2);
    itemBar = new JPanel(new FlowLayout());
    playerItem = new JLabel();
    arrowItem = new JLabel();
    diamond = new JLabel();
    ruby = new JLabel();
    sapphire = new JLabel();
    this.addSet();
    pack();
    setVisible(true);
  }

  @Override
  public void removeSetPanel() {
    this.remove(setPanel);
  }

  @Override
  public void removeDungeonPanel() {
    this.remove(dungeonPanel);
    this.remove(sp);
    this.remove(itemBar);
    this.remove(dungeonCell[0]);
    this.repaint();
    //System.out.println(this.getBackground());
  }

  @Override
  public void removeEndPanel() {
    this.remove(endPanel);
    if (itemBar != null) {
      this.remove(itemBar);
    }
    this.repaint();
  }

  @Override
  public void setModel(ReadonlyModel model) {
    this.model = model;
  }

  @Override
  public void resetFocus() {
    dungeonPanel.setFocusable(true);
    dungeonPanel.requestFocus();
  }

  @Override
  public void addSet() {
    this.add(setPanel);
    stopGame.setEnabled(false);
    startNew.setEnabled(false);
    startSame.setEnabled(false);
    pack();
  }

  @Override
  public void refreshAfterPick() {
    //System.out.println("p");
    refreshCellImage(model.getCurCellId());
    int currentId = model.getCurCellId();
    BufferedImage currentImage = dungeonImage[currentId];
    currentImage = overlay(currentImage, "/icons/player.png", 10);
    dungeonCell[currentId].setIcon(new ImageIcon(currentImage));
    dungeonPanel.repaint();
    pack();
  }

  @Override
  public void refreshAfterMove() {
    int curId = model.getCurCellId();
    if (!visitedCell[curId]) {
      refreshCellImage(curId);
      visitedCell[curId] = true;
    }
    BufferedImage curImage = dungeonImage[curId];
    curImage = overlay(curImage, "/icons/player.png", 10);
    dungeonCell[curId].setIcon(new ImageIcon(curImage));
    int preId = model.getPreCellId();
    if (preId != -1) {
      BufferedImage preImage = dungeonImage[preId];
      dungeonCell[preId].setIcon(new ImageIcon(preImage));
    }
    dungeonPanel.repaint();
    pack();
  }

  @Override
  public void refreshAfterShoot(String shootResult) {
    //System.out.println("s");
    String input = "";
    switch (shootResult) {
      case "No more arrows!":
        input = "No more arrow!";
        break;
      case "You shoot at a wall!":
        input = "Shoot at a wall!";
        break;
      case "you injured a monster!":
        input = "you injure a monster!";
        break;
      case "you killed a monster!":
        input = "You kill a monster!";
        refreshShootResult(model.getArrowLocation().getId());
        refreshAfterMove();
        //System.out.println("arrow loc" + model.getArrowLocation().getId());
        break;
      case "you missed!":
        input = "You missed!";
        break;
      default:
        break;
    }
    JOptionPane.showMessageDialog(this, input);
  }

  private void refreshShootResult(int id) {
    refreshCellImage(id);
    //System.out.println("arrow loc" + id);
    List<Cells> visited = new ArrayList<>();
    List<Cells> queue = new ArrayList<>();
    visited.add(model.getArrowLocation());
    queue.add(model.getArrowLocation());
    Map<Cells, Integer> distanceCnt = new HashMap<>();
    distanceCnt.put(model.getArrowLocation(), 0);
    while (queue.size() != 0 && visited.size() <= model.getRowNum() * model.getColNum()) {
      Cells cur = queue.remove(0);
      for (Cells c : cur.dfsHelper()) {
        if (!visited.contains(c)) {
          if (this.visitedCell[c.getId()]) {
            //System.out.println("refresh arrow loc" + c.getId());
            refreshCellImage(c.getId());
          }
          queue.add(c);
          distanceCnt.put(c, distanceCnt.getOrDefault(cur, 0) + 1);
          visited.add(c);
        }
        //System.out.println("cell distance from mons" + distanceCnt.get(c));
        if (distanceCnt.get(c) > 3) {
          break;
        }
      }
    }
  }

  private void refreshCellImage(int id) {
    List<Directions> directions = model.getCellById(id).getDirections();
    //System.out.println(directions);
    String result = directions.stream().map(a -> a.toString().substring(0, 1))
            .sorted().collect(Collectors.joining());
    String cellFileName = "/icons/" + result + ".png";
    //System.out.println(cellFileName);
    try {
      URL tmp = getClass().getResource(cellFileName);
      BufferedImage tmpImage = ImageIO.read(tmp);
      //System.out.println(model.smellMonsterByCell(id));
      if (!model.smellMonsterByCell(id).isEmpty()) {
        if (model.smellMonsterByCell(id).equals(" a less pungent smell ")) {
          tmpImage = overlay(tmpImage, "/icons/stench01.png", 0);
        } else if (model.smellMonsterByCell(id).equals(" a more pungent smell ")) {
          tmpImage = overlay(tmpImage, "/icons/stench02.png", 0);
        }
      }
      if (!model.sensePit(id).isEmpty()) {
        //System.out.println(model.sensePit(id));
        if (model.sensePit(id).equals("the pit is close")) {
          tmpImage = overlay(tmpImage, "/icons/pits02.png", 17);
        }
      }
      if (model.getCellById(id).getObstacles() != null
              && model.getCellById(id).getObstacles().equals(Obstacles.PIT)) {
        tmpImage = overlay(tmpImage, "/icons/pit.png", 17);
      }
      if (model.getCellById(id).getObstacles() != null
              && model.getCellById(id).getObstacles().equals(Obstacles.THIEF)) {
        tmpImage = overlay(tmpImage, "/icons/thief.png", 17);
      }
      if (model.getCellById(id).getOtyugh() != null) {
        tmpImage = overlay(tmpImage, "/icons/otyugh.png", 6);
      }
      if (model.getCellById(id).getDiamondNum() != 0) {
        tmpImage = overlay(tmpImage, "/icons/diamond.png", 0);
      } else if (model.getCellById(id).getRubiesNum() != 0) {
        tmpImage = overlay(tmpImage, "/icons/ruby.png", 0);
      } else if (model.getCellById(id).getSapphiresNum() != 0) {
        tmpImage = overlay(tmpImage, "/icons/sapphire.png", 0);
      }
      if (model.getCellById(id).getArrowNum() != 0) {
        tmpImage = overlay(tmpImage, "/icons/arrow-white.png", 15);
      }
      dungeonImage[id] = tmpImage;
      //System.out.println(dungeonImage[id]);
      if (visitedCell[id]) {
        dungeonCell[id].setIcon(new ImageIcon(dungeonImage[id]));
        dungeonPanel.repaint();
        pack();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public Directions showShootOptions(Directions[] options) {
    return (Directions) JOptionPane.showInputDialog(null, "Select direction",
            "Direction", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
  }

  public Integer showDistanceOptions(Integer[] options) {
    return (Integer) JOptionPane.showInputDialog(null, "Select distance",
            "Distance", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
  }

  @Override
  public void setCommands(GuiController guiController) {
    startNew.addActionListener(l -> guiController.startNew());
    startSame.addActionListener(l -> guiController.startSame());
    stopGame.addActionListener(l -> guiController.stopGame());
    shoot.addActionListener(l -> guiController.shoot());
    pick.addActionListener(l -> guiController.pick());
    create.addActionListener(l -> guiController.createDungeon(
                    createEntries[0].getText(),
                    createEntries[1].getText(),
                    createEntries[2].getText(),
                    createEntries[3].getText(),
                    createEntries[4].getText(),
                    createEntries[5].getText(),
                    createEntries[6].getText(),
                    createEntries[7].getText(),
                    createEntries[8].getText(),
                    createEntries[9].getText()
            )
    );
  }

  @Override
  public void showEnd() {
    stopGame.setEnabled(false);
    startNew.setEnabled(true);
    startSame.setEnabled(true);
    int rows = model.getRowNum();
    int cols = model.getColNum();
    GridLayout dungeonLayout = new GridLayout(rows, cols);
    this.endPanel = new JPanel(dungeonLayout);
    resetFocus();
    int total = rows * cols;
    JButton[] tmp = new JButton[total];
    for (int i = 0; i < total; i++) {
      //System.out.println(i);
      if (dungeonImage[i] == null) {
        refreshCellImage(i);
      }
      tmp[i] = new JButton();
      tmp[i].setBorder(new EmptyBorder(0, 0, 0, 0));
      tmp[i].setIcon(new ImageIcon(dungeonImage[i]));
      endPanel.add(tmp[i]);
    }
    this.add(endPanel, BorderLayout.CENTER);
    endPanel.setVisible(true);
    this.add(itemBar, BorderLayout.PAGE_END);
    itemBar.setVisible(true);
    pack();
  }

  @Override
  public void showDungeon() {
    stopGame.setEnabled(true);
    GridLayout layout = new GridLayout(model.getRowNum(), model.getColNum());
    layout.setHgap(0);
    layout.setVgap(0);
    this.dungeonPanel = new JPanel(layout);
    dungeonPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
    sp = new JScrollPane();
    sp.setViewportView(dungeonPanel);
    resetFocus();
    int totalCells = model.getRowNum() * model.getColNum();
    this.dungeonCell = new JButton[totalCells];
    this.dungeonImage = new BufferedImage[totalCells];
    this.visitedCell = new boolean[totalCells];
    Arrays.fill(visitedCell, false);
    for (int i = 0; i < totalCells; i++) {
      dungeonCell[i] = new JButton();
      dungeonCell[i].setBorder(new EmptyBorder(0, 0, 0, 0));
      dungeonPanel.add(dungeonCell[i]);
      URL tmp = getClass().getResource("/icons/blank.png");
      ImageIcon icon = new ImageIcon(tmp);
      dungeonCell[i].setIcon(icon);
    }
    this.add(sp);
    try {
      URL tmp = getClass().getResource("/icons/arrow-black.png");
      ImageIcon icon = new ImageIcon(tmp);
      arrowItem.setIcon(icon);
      URL tmp1 = getClass().getResource("/icons/diamond.png");
      ImageIcon icon1 = new ImageIcon(tmp1);
      diamond.setIcon(icon1);
      URL tmp2 = getClass().getResource("/icons/ruby.png");
      ImageIcon icon2 = new ImageIcon(tmp2);
      ruby.setIcon(icon2);
      URL tmp3 = getClass().getResource("/icons/sapphire.png");
      ImageIcon icon3 = new ImageIcon(tmp3);
      sapphire.setIcon(icon3);
    } catch (Exception e) {
      e.printStackTrace();
    }
    itemBar.add(playerItem);
    itemBar.add(arrowItem);
    itemBar.add(diamond);
    itemBar.add(ruby);
    itemBar.add(sapphire);
    this.add(itemBar, BorderLayout.PAGE_END);
    itemBar.setVisible(true);
    refreshItemsBar();
    refreshCellImage(model.getCellMap()[model.getStart()[0]][model.getStart()[1]].getId());
    visitedCell[model.getCellMap()[model.getStart()[0]][model.getStart()[1]].getId()] = true;
    int curId = model.getCellMap()[model.getLoc()[0]][model.getLoc()[1]].getId();
    BufferedImage curImage = dungeonImage[curId];
    curImage = overlay(curImage, "/icons/player.png", 5);
    dungeonCell[curId].setIcon(new ImageIcon(curImage));
    dungeonPanel.repaint();
    pack();
  }

  private BufferedImage overlay(BufferedImage starting, String filePath, int offset) {
    URL tmp = getClass().getResource(filePath);
    BufferedImage overlay = null;
    try {
      overlay = ImageIO.read(tmp);
    } catch (IOException e) {
      e.printStackTrace();
    }
    int w = Math.max(starting.getWidth(), overlay.getWidth());
    int h = Math.max(starting.getHeight(), overlay.getHeight());
    BufferedImage combined = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
    Graphics g = combined.getGraphics();
    g.drawImage(starting, 0, 0, null);
    g.drawImage(overlay, offset, offset, null);
    return combined;
  }

  @Override
  public void refreshItemsBar() {
    try {
      URL tmp = getClass().getResource("/icons/player.png");
      ImageIcon icon = new ImageIcon(tmp);
      playerItem.setIcon(icon);
    } catch (Exception e) {
      e.printStackTrace();
    }
    arrowItem.setText(String.valueOf(model.getCurrentArrow()));
    diamond.setText(String.valueOf(model.getCurrentDia()));
    ruby.setText(String.valueOf(model.getCurrentRub()));
    sapphire.setText(String.valueOf(model.getCurrentSap()));
    itemBar.repaint();
  }

  @Override
  public void setDungeonCommand(GuiController guiController) {
    dungeonPanel.addKeyListener(new KeyListener() {
      @Override
      public void keyTyped(KeyEvent event) {
        if (event.getKeyChar() == 'w') {
          guiController.move(Directions.NORTH);
        }
        if (event.getKeyChar() == 's') {
          guiController.move(Directions.SOUTH);
        }
        if (event.getKeyChar() == 'a') {
          guiController.move(Directions.WEST);
        }
        if (event.getKeyChar() == 'd') {
          guiController.move(Directions.EAST);
        }
      }

      @Override
      public void keyPressed(KeyEvent event) {
        switch (event.getKeyCode()) {
          case KeyEvent.VK_UP:
            guiController.move(Directions.NORTH);
            break;
          case KeyEvent.VK_DOWN:
            guiController.move(Directions.SOUTH);
            break;
          case KeyEvent.VK_LEFT:
            guiController.move(Directions.WEST);
            break;
          case KeyEvent.VK_RIGHT:
            guiController.move(Directions.EAST);
            break;
          case KeyEvent.VK_P:
            guiController.pick();
            break;
          case KeyEvent.VK_T:
            guiController.shoot();
            break;
          default:
            break;
        }
      }

      @Override
      public void keyReleased(KeyEvent e) {
        return;
      }
    });
    for (int i = 0; i < dungeonCell.length; i++) {
      int tmpId = i;
      dungeonCell[i].addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
          super.mouseClicked(e);
          if (SwingUtilities.isLeftMouseButton(e)) {
            guiController.clickHelper(tmpId);
          }
        }
      });
      dungeonCell[i].addMouseListener(new MouseAdapter() {
        @Override
        public void mousePressed(MouseEvent e) {
          if (e.isPopupTrigger()) {
            showPopup(e);
          }
        }

        @Override
        public void mouseReleased(MouseEvent e) {
          if (e.isPopupTrigger()) {
            showPopup(e);
          }
        }

        private void showPopup(MouseEvent e) {
          guiController.popupHelper(e.getComponent(), tmpId);
        }
      });
    }
  }

  @Override
  public void displayResult(String s) {
    JOptionPane.showMessageDialog(this, s);
  }

  @Override
  public void showPopup(Component component) {
    popup.show(component, 10, 10);
  }

  /**
   * Aligns the first <code>rows</code> * <code>cols</code> components of <code>parent</code> in a
   * grid. Each component in a column is as wide as the maximum preferred width of the components in
   * that column; height is similarly determined for each row. The parent is made just big enough to
   * fit them all.
   *
   * @param rows     number of rows
   * @param cols     number of columns
   * @param initialX x location to start the grid at
   * @param initialY y location to start the grid at
   * @param paddingX x padding between cells
   * @param paddingY y padding between cells
   */
  private void makeCompactGrid(Container parent,
                               int rows, int cols,
                               int initialX, int initialY,
                               int paddingX, int paddingY) {
    SpringLayout layout;
    try {
      layout = (SpringLayout) parent.getLayout();
    } catch (ClassCastException exc) {
      System.err.println("The first argument to makeCompactGrid must use SpringLayout.");
      return;
    }

    //Align all cells in each column and make them the same width.
    Spring x = Spring.constant(initialX);
    for (int c = 0; c < cols; c++) {
      Spring width = Spring.constant(0);
      for (int r = 0; r < rows; r++) {
        width = Spring.max(width,
                getConstraintsForCell(r, c, parent, cols).getWidth());
      }
      for (int r = 0; r < rows; r++) {
        SpringLayout.Constraints constraints =
                getConstraintsForCell(r, c, parent, cols);
        constraints.setX(x);
        constraints.setWidth(width);
      }
      x = Spring.sum(x, Spring.sum(width, Spring.constant(paddingX)));
    }

    //Align all cells in each row and make them the same height.
    Spring y = Spring.constant(initialY);
    for (int r = 0; r < rows; r++) {
      Spring height = Spring.constant(0);
      for (int c = 0; c < cols; c++) {
        height = Spring.max(height,
                getConstraintsForCell(r, c, parent, cols).getHeight());
      }
      for (int c = 0; c < cols; c++) {
        SpringLayout.Constraints constraints =
                getConstraintsForCell(r, c, parent, cols);
        constraints.setY(y);
        constraints.setHeight(height);
      }
      y = Spring.sum(y, Spring.sum(height, Spring.constant(paddingY)));
    }

    //Set the parent's size.
    SpringLayout.Constraints consP = layout.getConstraints(parent);
    consP.setConstraint(SpringLayout.SOUTH, y);
    consP.setConstraint(SpringLayout.EAST, x);
  }

  /* Used by makeCompactGrid. */
  private SpringLayout.Constraints getConstraintsForCell(
          int row, int col,
          Container parent,
          int cols) {
    SpringLayout layout = (SpringLayout) parent.getLayout();
    Component c = parent.getComponent(row * cols + col);
    return layout.getConstraints(c);
  }
}
