package view;

import java.awt.Component;
import controller.GuiController;
import model.Directions;
import model.ReadonlyModel;

/**
 * A view for Dungeon Game: display the game board and provide visual interface for users.
 */
public interface View {
  void removeSetPanel();

  void removeDungeonPanel();

  void removeEndPanel();

  void setModel(ReadonlyModel model);

  void resetFocus();

  void addSet();

  void refreshAfterPick();

  void refreshAfterMove();

  void refreshAfterShoot(String shootResult);

  Directions showShootOptions(Directions[] options);

  Integer showDistanceOptions(Integer[] options);

  void setCommands(GuiController guiController);

  void showEnd();

  void showDungeon();

  void refreshItemsBar();

  void setDungeonCommand(GuiController guiController);

  void displayResult(String s);

  void showPopup(Component component);
}
