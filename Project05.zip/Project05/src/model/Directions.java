package model;

/**
 * This class represents the directions in this dungeon. It was limited to four directions as north,
 * south, east and west. Can be extended for future use.
 */
public enum Directions {
  NORTH,
  SOUTH,
  EAST,
  WEST
}
