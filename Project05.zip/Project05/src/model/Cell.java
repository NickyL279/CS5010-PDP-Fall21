package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * This class represents a cell room. A cell has treasures, directions and id. A cell has id,
 * location and all of its neighbor cells.
 */
public class Cell implements Cells {
  private final int[] location;
  private final Random random;
  private final List<Treasures> treasures;
  private final List<Gadget> arrows;
  private int id;
  private Cells north;
  private Cells south;
  private Cells west;
  private Cells east;
  private Otyugh otyugh;
  private Obstacles obstacles;

  /**
   * Construct a cell object that has the provided location.
   *
   * @param location the location of this cell in a dungeon.
   * @throws IllegalArgumentException if location is invalid.
   */
  public Cell(int[] location) {
    if (location[0] < 0 || location[1] < 0) {
      throw new IllegalArgumentException("Bad cell.");
    }
    this.random = new Random();
    //random.setSeed(1);
    this.location = location;
    this.north = null;
    this.south = null;
    this.west = null;
    this.east = null;
    this.otyugh = null;
    treasures = new ArrayList<>();
    arrows = new ArrayList<>();
    this.obstacles = null;
  }

  /**
   * Construct a cell object that has the provided location.
   *
   * @param location the location of this cell in a dungeon.
   * @throws IllegalArgumentException if location is invalid.
   */
  public Cell(int[] location, int seed) {
    if (location[0] < 0 || location[1] < 0) {
      throw new IllegalArgumentException("Bad cell.");
    }
    this.random = new Random();
    random.setSeed(seed);
    this.location = location;
    this.north = null;
    this.south = null;
    this.west = null;
    this.east = null;
    this.otyugh = null;
    treasures = new ArrayList<>();
    arrows = new ArrayList<>();
  }

  @Override
  public void addPit() {
    this.obstacles = Obstacles.PIT;
  }

  @Override
  public void addThief() {
    this.obstacles = Obstacles.THIEF;
  }

  @Override
  public Obstacles getObstacles() {
    Obstacles tmp = this.obstacles;
    return tmp;
  }



  @Override
  public void addMonster(Otyugh otyugh) {
    if (otyugh == null) {
      throw new IllegalArgumentException("Otyugh cannot be null");
    }
    this.otyugh = otyugh;
  }

  @Override
  public int getArrowNum() {
    int tmpNum = this.arrows.size();
    return tmpNum;
  }

  @Override
  public void setArrowNum() {
    arrows.add(Gadget.ARROW);
  }

  @Override
  public Gadget getArrow() {
    Gadget tmp = null;
    for (Gadget g : arrows) {
      tmp = g;
    }
    arrows.remove(tmp);
    return tmp;
  }

  @Override
  public List<Cells> dfsHelper() {
    List<Cells> sur = new ArrayList<>();
    if (this.getNorth() != null) {
      sur.add(this.getNorth());
    }
    if (this.getSouth() != null) {
      sur.add(this.getSouth());
    }
    if (this.getWest() != null) {
      sur.add(this.getWest());
    }
    if (this.getEast() != null) {
      sur.add(this.getEast());
    }
    return sur;
  }

  @Override
  public int[] getLocation() {
    return this.location;
  }

  @Override
  public int getId() {
    return this.id;
  }

  @Override
  public void setId(int id) {
    if (id < 0) {
      throw new IllegalArgumentException("Id cannot be smaller than 0!");
    }
    this.id = id;
  }

  @Override
  public Cells getNorth() {
    Cells tmpCell = this.north;
    return tmpCell;
  }

  @Override
  public void setNorth(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.north = cell;
  }

  @Override
  public Cells getSouth() {
    Cells tmpCell = this.south;
    return tmpCell;
  }

  @Override
  public void setSouth(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.south = cell;
  }

  @Override
  public Cells getWest() {
    Cells tmpCell = this.west;
    return tmpCell;
  }

  @Override
  public void setWest(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.west = cell;
  }

  @Override
  public Cells getEast() {
    Cells tmpCell = this.east;
    return tmpCell;
  }

  @Override
  public void setEast(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.east = cell;
  }

  @Override
  public List<Integer> getSurroundingIds() {
    List<Integer> surroundingCellsIds = new ArrayList<>();
    if (this.getNorth() != null) {
      surroundingCellsIds.add(this.getNorth().getId());
    }
    if (this.getSouth() != null) {
      surroundingCellsIds.add(this.getSouth().getId());
    }
    if (this.getEast() != null) {
      surroundingCellsIds.add(this.getEast().getId());
    }
    if (this.getWest() != null) {
      surroundingCellsIds.add(this.getWest().getId());
    }
    return surroundingCellsIds;
  }

  @Override
  public Otyugh getOtyugh() {
    Otyugh tmp = this.otyugh;
    return tmp;
  }

  @Override
  public void setOtyugh() {
    this.otyugh = null;
  }

  @Override
  public Cells getCell(Directions d) {
    Cells tmpCell;
    if (d == null) {
      throw new IllegalArgumentException("Direction cannot be nulL!");
    }
    switch (d) {
      case NORTH:
        tmpCell = this.getNorth();
        break;
      case SOUTH:
        tmpCell = this.getSouth();
        break;
      case WEST:
        tmpCell = this.getWest();
        break;
      case EAST:
        tmpCell = this.getEast();
        break;
      default:
        throw new IllegalArgumentException("Wrong direction for getting cell!");
    }
    if (tmpCell != null) {
      return tmpCell;
    } else {
      throw new IllegalArgumentException("No cell here for getting cell");
    }
  }

  @Override
  public List<Directions> getDirections() {
    List<Directions> directions1 = new ArrayList<>();
    if (this.north != null) {
      directions1.add(Directions.NORTH);
    }
    if (this.south != null) {
      directions1.add(Directions.SOUTH);
    }
    if (this.west != null) {
      directions1.add(Directions.WEST);
    }
    if (this.east != null) {
      directions1.add(Directions.EAST);
    }
    return directions1;
  }

  @Override
  public void setTreasure() {
    List<Treasures> availableTreasure = new ArrayList<>();
    Collections.addAll(availableTreasure, Treasures.values());
    treasures.add(availableTreasure.get(random.nextInt(availableTreasure.size())));
  }

  @Override
  public void addTreasure(Treasures t) {
    if (t == null) {
      throw new IllegalArgumentException("Treasure cannot be null!");
    }
    treasures.add(t);
  }

  @Override
  public Treasures getTreasure() {
    Treasures tmp = null;
    for (Treasures t : treasures) {
      tmp = t;
    }
    treasures.remove(tmp);
    return tmp;
  }

  @Override
  public int getDiamondNum() {
    int tmpCnt = 0;
    for (Treasures t : treasures) {
      if (t.equals(Treasures.DIAMONDS)) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public int getRubiesNum() {
    int tmpCnt = 0;
    for (Treasures t : treasures) {
      if (t.equals(Treasures.RUBIES)) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public int getSapphiresNum() {
    int tmpCnt = 0;
    for (Treasures t : treasures) {
      if (t.equals(Treasures.SAPPHIRES)) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public String toString() {
    return String.format("* %s %s. Has %d dia, %d rub, %d sap. %d arrow.*",
            Arrays.toString(location), this.getDirections().toString(),
            this.getDiamondNum(), this.getRubiesNum(), this.getSapphiresNum(), this.getArrowNum());
  }

  @Override
  public String cellGraphHelper() {
    String s = String.join(" ", this.getDirections().toString().toLowerCase());
    switch (s) {
      case "[north]":
        return String.format("  |  \n %d %d \n     ", location[0], location[1]);
      case "[south]":
        return String.format("     \n %d %d \n  |  ", location[0], location[1]);
      case "[east]":
        return String.format("     \n %d %d-\n     ", location[0], location[1]);
      case "[west]":
        return String.format("     \n-%d %d \n     ", location[0], location[1]);
      case "[north, south]":
        return String.format("  |  \n %d %d \n  |  ", location[0], location[1]);
      case "[west, east]":
        return String.format("     \n-%d %d-\n     ", location[0], location[1]);
      case "[north, east]":
        return String.format("  |  \n %d %d-\n     ", location[0], location[1]);
      case "[north, west]":
        return String.format("  |  \n-%d %d \n     ", location[0], location[1]);
      case "[south, west]":
        return String.format("     \n-%d %d \n  |  ", location[0], location[1]);
      case "[south, east]":
        return String.format("     \n %d %d-\n  |  ", location[0], location[1]);
      case "[north, west, east]":
        return String.format("  |  \n-%d %d-\n     ", location[0], location[1]);
      case "[south, west, east]":
        return String.format("     \n-%d %d-\n  |  ", location[0], location[1]);
      case "[north, south, west]":
        return String.format("  |  \n-%d %d \n  |  ", location[0], location[1]);
      case "[north, south, east]":
        return String.format("  |  \n %d %d-\n  |  ", location[0], location[1]);
      case "[north, south, west, east]":
        return String.format("  |  \n-%d %d-\n  |  ", location[0], location[1]);
      default:
        return "";
    }
  }
}
