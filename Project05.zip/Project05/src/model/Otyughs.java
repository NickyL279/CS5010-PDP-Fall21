package model;

/**
 * This interface represents all the operations to be supported by otyughs. An Otyugh can be injured
 * or not.
 */
public interface Otyughs {
  /**
   * Return whether the monster is injured.
   *
   * @return whether the monster is injured
   */
  boolean isInjured();

  /**
   * Set this monster to injured.
   */
  void setInjured();
}
