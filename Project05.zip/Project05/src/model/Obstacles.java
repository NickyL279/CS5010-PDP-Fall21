package model;

/**
 * This class represents the obstacles in this dungeon. It was limited to two types as thief,
 * and pit. Can be extended for future use.
 */
public enum Obstacles {
  THIEF,
  PIT
}
