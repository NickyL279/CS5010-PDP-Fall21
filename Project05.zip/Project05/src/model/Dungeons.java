package model;

import java.util.List;

/**
 * This interface represents all the operations to be supported by a maze implements Kruskal
 * Algorithm.
 */
public interface Dungeons extends ReadonlyModel {
  /**
   * Add the given percentage of treasure to this dungeon.
   *
   * @param percentage the percentage of all room who has treasure
   */
  void addTreasure(int percentage);

  /**
   * Generate the dungeon using kruskal algorithm.
   */
  void generate();

  /**
   * Generate the dungeon using kruskal algorithm.
   *
   * @param allPath           all the edges in the dungeon
   * @param interconnectivity the interconnectivity of this dungeon
   */
  void generateDungeonGraph(List<int[]> allPath, int interconnectivity);

  /**
   * Add the given percentage of arrows to this dungeon.
   *
   * @param percentage the percentage of all room who has arrows
   */
  void addArrow(int percentage);

  /**
   * Move the player to the desired direction in this dungeon.
   *
   * @param movement the player's move direction
   */
  void move(String movement);

  /**
   * Player picks up the treasure in current location.
   */
  void pickTreasure();

  /**
   * Player picks up the arrow in current location.
   */
  void pickArrow();

  /**
   * Return whether the player has reached the goal point.
   *
   * @return whether the player has reached the goal point
   */
  boolean checkReachEnd();

  /**
   * Return a graphic map of the dungeon.
   *
   * @return a graphic map of the dungeon
   */
  String graphBuilder();

  /**
   * Adding the given number monster to the dungeon.
   *
   * @param number the given number monster
   */
  void addMonster(int number);

  /**
   * Return the result of shooting an arrow.
   *
   * @return the result of shooting an arrow
   */
  String shootArrow(Directions d, int distance);

  /**
   * Return the status of the player.
   *
   * @return the status of the player
   */
  Status getPlayerStatus();

  /**
   * Return the location of monsters in the dungeon.
   *
   * @return the location of monsters in the dungeon
   */
  String getMonsters();

  /**
   * Return the number of diamond in the current cell.
   *
   * @return the number of diamond in the current cell
   */
  int getThisCellDiamond();

  /**
   * Return the number of ruby in the current cell.
   *
   * @return the number of ruby in the current cell
   */
  int getThisCellRuby();

  /**
   * Return the number of sapphire in the current cell.
   *
   * @return the number of sapphire in the current cell
   */
  int getThisCellSap();

  /**
   * Return the number of arrow in the current cell.
   *
   * @return the number of arrow in the current cell
   */
  int getThisCellArrow();

  /**
   * Return the type of the current cell.
   *
   * @return the type of the current cell
   */
  String getCellType();

  void addPit(int number);

  void addThief(int number);
}
