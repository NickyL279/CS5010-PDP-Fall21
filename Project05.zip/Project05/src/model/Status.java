package model;

/**
 * This class represents the player's status in this dungeon. It was limited to two types as alive
 * and dead. Can be extended for future use.
 */
public enum Status {
  ALIVE,
  DEAD,
  FALLDEAD
}
