package model;

/**
 * This class represents the treasures in this dungeon. It was limited to three types as rubies,
 * sapphires and diamonds. Can be extended for future use.
 */
public enum Treasures {
  RUBIES,
  SAPPHIRES,
  DIAMONDS
}
