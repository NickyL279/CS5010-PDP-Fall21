package model;

/**
 * This class represents an otyugh. An otyugh can be injured or not.
 */
public class Otyugh implements Otyughs {
  private boolean isInjured;

  /**
   * Construct an otyugh object that is always not injured at first.
   *
   */
  public Otyugh() {
    isInjured = false;
  }

  @Override
  public boolean isInjured() {
    boolean tmp = isInjured;
    return tmp;
  }

  @Override
  public void setInjured() {
    this.isInjured = true;
  }

  @Override
  public String toString() {
    return "Otyugh here!";
  }
}
