package model;

import java.util.List;

/**
 * The interface needed for a read-only model for the dungeon game.
 */
public interface ReadonlyModel {

  /**
   * Return the number of rows in this dungeon.
   *
   * @return the number of rows
   */
  int getRowNum();

  /**
   * Return the number of columns in this dungeon.
   *
   * @return the number of columns
   */
  int getColNum();

  /**
   * Return the number of interconnectivity in this dungeon.
   *
   * @return the number of interconnectivity
   */
  int getInterconnectivity();

  /**
   * Return the list of all treasure's location in this dungeon.
   *
   * @return the list of all treasure's location
   */
  List<String> getTreasure();

  /**
   * Return the list of all paths in this dungeon.
   *
   * @return the list of all paths
   */
  List<int[]> getAllPath();

  /**
   * Return all the cells in this dungeon.
   *
   * @return all the cells
   */
  Cells[][] getCellMap();

  /**
   * Return the list of all arrow's location in this dungeon.
   *
   * @return the list of all arrow's location
   */
  List<String> getArrow();

  /**
   * Return the start point of this dungeon.
   *
   * @return the start point
   */
  int[] getStart();

  /**
   * Return the end point of this dungeon.
   *
   * @return the end point
   */
  int[] getEnd();

  /**
   * Return the player's location in this dungeon.
   *
   * @return the player's location
   */
  int[] getLoc();

  /**
   * Return the player's diamond number in this dungeon.
   *
   * @return the player's diamond number
   */
  int getCurrentDia();

  /**
   * Return the player's ruby number in this dungeon.
   *
   * @return the player's ruby number
   */
  int getCurrentRub();

  /**
   * Return the player's sapphires number in this dungeon.
   *
   * @return the player's sapphires number
   */
  int getCurrentSap();

  /**
   * Return the player's possible move direction in this dungeon.
   *
   * @return the player's possible move direction
   */
  List<Directions> getPosDirections();

  /**
   * Return the current arrow number of the player.
   *
   * @return the current arrow number of the player.
   */
  int getCurrentArrow();

  /**
   * Return the result of smelling a monster.
   *
   * @return the result of smelling a monster
   */
  String smellMonster();

  /**
   * Return the id of current cell.
   *
   * @return the id of current cell
   */
  int getCurCellId();

  int getPreCellId();

  List<Integer> getSurroundingIds(int id);

  Cells getCurrentCell();

  Cells getArrowLocation();

  Cells getCellById(int id);

  String smellMonsterByCell(int id);

  String sensePit(int id);
}
