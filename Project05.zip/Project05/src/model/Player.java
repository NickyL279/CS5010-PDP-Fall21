package model;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a player. A player has three treasures and arrows.
 */
public class Player implements Players {
  private Status status;
  private final List<Gadget> arrows;
  private final List<Treasures> treasures;

  /**
   * Construct a player object that has the provided diamond, rubies and sapphires.
   */
  public Player() {
    this.status = Status.ALIVE;
    this.arrows = new ArrayList<>();
    arrows.add(Gadget.ARROW);
    arrows.add(Gadget.ARROW);
    arrows.add(Gadget.ARROW);
    this.treasures = new ArrayList<>();
  }

  @Override
  public Status getStatus() {
    Status tmpStatus = this.status;
    return tmpStatus;
  }

  @Override
  public void setStatus(Status status) {
    if (status == null) {
      throw new IllegalArgumentException("Status cannot be null");
    }
    this.status = status;
  }

  @Override
  public int getArrowNum() {
    int tmpCnt = 0;
    for (Gadget g : arrows) {
      if (g == Gadget.ARROW) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public void pickArrow(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    this.arrows.add(cell.getArrow());
  }

  @Override
  public void loseArrow() {
    this.arrows.remove(0);
  }

  @Override
  public void loseTreasure(Treasures treasures) {
    this.treasures.remove(treasures);
  }

  @Override
  public int getDiamondNum() {
    int tmpCnt = 0;
    for (Treasures t : treasures) {
      if (t.equals(Treasures.DIAMONDS)) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public int getRubiesNum() {
    int tmpCnt = 0;
    for (Treasures t : treasures) {
      if (t.equals(Treasures.RUBIES)) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public int getSapphiresNum() {
    int tmpCnt = 0;
    for (Treasures t : treasures) {
      if (t.equals(Treasures.SAPPHIRES)) {
        tmpCnt++;
      }
    }
    return tmpCnt;
  }

  @Override
  public void addTreasure(Treasures t) {
    if (t == null) {
      throw new IllegalArgumentException("Treasure cannot be null!");
    }
    treasures.add(t);
  }

  @Override
  public void pickTreasure(Cells cell) {
    if (cell == null) {
      throw new IllegalArgumentException("Cell cannot be null!");
    }
    if (cell.getDiamondNum() == 0 && cell.getRubiesNum() == 0 && cell.getSapphiresNum() == 0) {
      throw new IllegalArgumentException("No treasure to pick!");
    }
    Treasures t = cell.getTreasure();
    treasures.add(t);
  }
}
