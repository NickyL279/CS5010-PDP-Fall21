package model;

/**
 * This class represents the gadgets in this dungeon. It was limited to one gadget as arrow. Can be
 * extended for future use.
 */
public enum Gadget {
  ARROW,
}
