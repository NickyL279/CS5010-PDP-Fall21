package model;

import java.util.List;

/**
 * This interface represents all the operations to be supported by a cell. A cell has id, location
 * and all of its neighbor cells.
 */
public interface Cells {
  /**
   * Return the location of this cell.
   *
   * @return the location of this cell
   */
  int[] getLocation();

  /**
   * Return the id of this cell.
   *
   * @return the id of this cell
   */
  int getId();

  /**
   * Set the id of this cell.
   *
   * @param id the id of this cell
   */
  void setId(int id);

  /**
   * Return the north cell of this cell.
   *
   * @return the north cell of this cell
   */
  Cells getNorth();

  /**
   * Set the north cell of this cell.
   *
   * @param north the north cell of this cell
   */
  void setNorth(Cells north);

  /**
   * Return the south cell of this cell.
   *
   * @return the south cell of this cell
   */
  Cells getSouth();

  /**
   * Set the south cell of this cell.
   *
   * @param south the south cell of this cell
   */
  void setSouth(Cells south);

  /**
   * Return the west cell of this cell.
   *
   * @return the west cell of this cell
   */
  Cells getWest();

  /**
   * Set the west cell of this cell.
   *
   * @param west the west cell of this cell
   */
  void setWest(Cells west);

  /**
   * Return the east cell of this cell.
   *
   * @return the east cell of this cell
   */
  Cells getEast();

  /**
   * Set the east cell of this cell.
   *
   * @param east the east cell of this cell
   */
  void setEast(Cells east);

  /**
   * Return the surrounding cells of this cell.
   *
   * @return the surrounding cells of this cell
   */
  List<Directions> getDirections();

  /**
   * Set the treasure of this cell.
   */
  void setTreasure();

  /**
   * Return the diamond Number of this cell.
   *
   * @return the diamond Number
   */
  int getDiamondNum();

  /**
   * Return the rubies Number of this cell.
   *
   * @return the rubies Number
   */
  int getRubiesNum();

  /**
   * Return the sapphires Number of this cell.
   *
   * @return the sapphires Number
   */
  int getSapphiresNum();

  /**
   * Return the graph of this cell.
   *
   * @return the graph of this cell
   */
  String cellGraphHelper();

  /**
   * Return the surrounding cells of this cell.
   *
   * @return the surrounding cells of this cell
   */
  List<Cells> dfsHelper();

  /**
   * Return the arrow number of this cell.
   *
   * @return the arrow number of this cell
   */
  int getArrowNum();

  /**
   * Set the arrow number of this cell.
   *
   */
  void setArrowNum();

  /**
   * Return the given direction's cell of this cell.
   *
   * @return the given direction's cell of this cell
   */
  Cells getCell(Directions d);

  /**
   * Add a monster to this cell.
   *
   * @param otyugh a monster object
   */
  void addMonster(Otyugh otyugh);

  /**
   * Get the monster of this cell.
   *
   * @return the otyugh object of this cell
   */
  Otyugh getOtyugh();

  /**
   * Set the monster to dead after got shoot twice.
   */
  void setOtyugh();

  /**
   * Get the treasure of this cell.
   *
   * @return the treasure of this cell
   */
  Treasures getTreasure();

  /**
   * Add a treasure to this cell.
   *
   * @param t a treasure to this cell
   */
  void addTreasure(Treasures t);

  /**
   * Get the gadget of this cell.
   *
   * @return the gadget of this cell
   */
  Gadget getArrow();

  /**
   * Get the surrounding ids of this cell.
   *
   * @return the surrounding ids of this cell
   */
  List<Integer> getSurroundingIds();

  void addPit();

  Obstacles getObstacles();

  void addThief();
}
