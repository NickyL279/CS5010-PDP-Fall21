import controller.Controller;
import controller.GameController;
import controller.GuiController;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import view.DungeonView;

/**
 * Run a dungeon game interactively on the console. Taking inputs as the dungeon setup and play the
 * game interactively.
 */
public class DungeonRun {

  /**
   * Run a dungeon game interactively on the console. Taking inputs as the dungeon setup and play
   * the game interactively.
   */
  public static void main(String[] args) throws IOException {
    //args = new String[]{"--gui"};
    //args = new String[]{"--text", "4", "4", "1", "1", "45", "45", "1", "1"};
    if (args[0].equals("--text")) {
      //System.out.println(args[1]);
      //System.out.println(args[8]);
      //System.out.println(Arrays.toString(args));
      //System.out.println(Arrays.toString(Arrays.copyOfRange(args, 1, 8)));
      if (Arrays.copyOfRange(args, 1, 9).length != 8) {
        throw new IOException("Usage: java -jar Project05-args.jar --text --rows --columns"
                + " --interconnectivity --dungeon type --treasure percentage --arrow percentage"
                + " --monster numbers --seed");
      }
      //System.out.println(Arrays.toString(Arrays.copyOfRange(args, 1, 9)));
      Controller c = new GameController(new InputStreamReader(System.in), System.out,
              Arrays.copyOfRange(args, 1, 9));
      c.playGame();
    } else if (args[0].equals("--gui")) {
      DungeonView dungeonView = new DungeonView("Dungeon");
      GuiController guiController = new GuiController(dungeonView);
      guiController.start();
    } else {
      throw new IOException("Usage: java -jar Project05.jar"
              + " <--text Project05-args.jar --text --rows --columns --interconnectivity"
              + " --dungeon type --treasure percentage --arrow percentage --monster numbers --seed "
              + "| --gui>\n");
    }
  }
}
