package test;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import model.Directions;
import model.Dungeons;
import model.UnwrappedDungeon;
import model.WrappedDungeon;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Class that tests the Abstract Dungeon.
 */
public class AbstractDungeonTest {
  Dungeons d1;
  Dungeons d2;

  @Before
  public void setUp() {
    d1 = new WrappedDungeon(4, 6, 12, 1);
    d1.generate();
    d2 = new UnwrappedDungeon(6, 8, 16, 1);
    d2.generate();
  }

  @Test
  public void testGetAllCell() {
    assertEquals(4, d1.getCellMap().length);
    assertEquals(6, d1.getCellMap()[0].length);
    assertEquals(6, d2.getCellMap().length);
    assertEquals(8, d2.getCellMap()[0].length);
  }

  @Test
  public void testAddArrow() {
    d1.addArrow(40);
    // System.out.println(d1.getArrow().size());
    assertEquals("[3, 1] [1, 1] [0, 3] [3, 0] [0, 4] [2, 4] [1, 2] [0, 0] [2, 2]"
            , String.join(" ", d1.getArrow()));
  }

  @Test
  public void getRowNumTest() {
    assertEquals(4, d1.getRowNum());
    assertEquals(6, d2.getRowNum());
  }

  @Test
  public void getColNum() {
    assertEquals(6, d1.getColNum());
    assertEquals(8, d2.getColNum());
  }

  @Test
  public void getInterconnectivity() {
    assertEquals(12, d1.getInterconnectivity());
    assertEquals(16, d2.getInterconnectivity());
  }

  @Test
  public void getTreasure() {
    d1.addTreasure(50);
    d2.addTreasure(50);
    assertEquals("[3, 1] [0, 3] [3, 0] [0, 4] [2, 4] [1, 2] [0, 0] [2, 2] [1, 0] [0, 1]" +
            " [3, 3] [3, 5]", String.join(" ", d1.getTreasure()));
    assertEquals("[1, 1] [5, 3] [0, 1] [0, 0] [4, 5] [5, 7] [4, 3] [1, 2] [0, 3] [3, 4] [1, 7]" +
            " [4, 4] [1, 3] [5, 2] [5, 1] [3, 6] [4, 2] [4, 6] [5, 6] [2, 5] [1, 0] [5, 5] [3, 5]" +
            " [1, 6]", String.join(" ", d2.getTreasure()));
  }

  @Test(expected = IllegalArgumentException.class)
  public void getTreasure1() {
    d1.addTreasure(12);
    d2.addTreasure(12);
  }

  @Test(expected = IllegalArgumentException.class)
  public void getTreasure2() {
    d1.addTreasure(102);
    d2.addTreasure(201);
  }

  @Test
  public void testGenerate() {
    assertEquals(12, Arrays.toString(d1.getAllPath().get(0)).length());
    assertEquals(12, Arrays.toString(d2.getAllPath().get(0)).length());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGenerate1() {
    Dungeons kd3 = new WrappedDungeon(2, 2, 8);
    Dungeons kd4 = new UnwrappedDungeon(2, 2, 8);
    kd3.generateDungeonGraph(null, 12);
    kd4.generateDungeonGraph(null, 12);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate() {
    Dungeons kd3 = new WrappedDungeon(2, 2, 8);
    Dungeons kd4 = new UnwrappedDungeon(2, 2, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate1() {
    Dungeons kd3 = new WrappedDungeon(-1, 2, 8);
    Dungeons kd4 = new UnwrappedDungeon(-2, 2, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate2() {
    Dungeons kd3 = new WrappedDungeon(4, -2, 8);
    Dungeons kd4 = new UnwrappedDungeon(4, -2, 8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate3() {
    Dungeons kd3 = new WrappedDungeon(4, 6, 45);
    Dungeons kd4 = new UnwrappedDungeon(4, 6, 36);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate4() {
    Dungeons kd3 = new WrappedDungeon(4, 6, -45);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate5() {
    Dungeons kd4 = new UnwrappedDungeon(4, 6, -36);
  }

  @Test
  public void testGetStart() {
    assertEquals(6, Arrays.toString(d1.getStart()).length());
    assertEquals(6, Arrays.toString(d2.getStart()).length());
    assertEquals("[1, 0]", Arrays.toString(d1.getStart()));
    assertEquals("[0, 1]", Arrays.toString(d2.getStart()));
  }

  @Test
  public void testGetEnd() {
    assertEquals(6, Arrays.toString(d1.getEnd()).length());
    assertEquals(6, Arrays.toString(d2.getEnd()).length());
    assertEquals("[2, 2]", Arrays.toString(d1.getEnd()));
    assertEquals("[2, 3]", Arrays.toString(d2.getEnd()));
  }

  @Test
  public void testGetPlayerLocation() {
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
    assertEquals(6, Arrays.toString(d2.getLoc()).length());
    assertEquals("[1, 0]", Arrays.toString(d1.getLoc()));
    assertEquals("[1, 0]", Arrays.toString(d1.getStart()));
    assertEquals("[0, 1]", Arrays.toString(d2.getLoc()));
  }

  @Test
  public void testGetTreasure() {
    assertEquals(0, d1.getCurrentDia());
    assertEquals(0, d2.getCurrentDia());
    assertEquals(0, d1.getCurrentRub());
    assertEquals(0, d2.getCurrentRub());
    assertEquals(0, d1.getCurrentSap());
    assertEquals(0, d2.getCurrentSap());
  }

  @Test
  public void getPossibleMove() {
    boolean flagOne = d1.getPosDirections().size() > 0;
    assertTrue(flagOne);
    boolean flagTwo = d2.getPosDirections().size() > 0;
    assertTrue(flagTwo);
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidMove() {
    d1.move("out");
    d2.move("in");
  }

  @Test
  public void testMove() {
    assertEquals("[1, 0]", Arrays.toString(d1.getLoc()));
    d1.move("west");
    assertEquals("[1, 5]", Arrays.toString(d1.getLoc()));
  }

  @Test (expected = IllegalArgumentException.class)
  public void testMove1() {
    //    System.out.println(d1.graphBuilder());
    //    System.out.println(Arrays.toString(d1.getStart()));
    //    System.out.println(Arrays.toString(d1.getEnd()));
    d1.move("east");
    d1.move("south");
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
  }

  @Test(expected = AssertionError.class)
  public void testGetTreasure1() {
    d1.addTreasure(60);
    d1.pickTreasure();
    d2.addTreasure(60);
    d2.pickTreasure();
    assertEquals(1, d1.getCurrentDia());
    assertEquals(1, d2.getCurrentDia());
    assertEquals(1, d1.getCurrentRub());
    assertEquals(1, d2.getCurrentRub());
    assertEquals(1, d1.getCurrentSap());
    assertEquals(1, d2.getCurrentSap());
  }

  @Test
  public void moveFromStartToEnd() {
    Dungeons kd3 = new WrappedDungeon(4, 4, 17, 1);
    kd3.generate();
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("south");
    kd3.move("west");
    assertTrue(kd3.checkReachEnd());
  }

  @Test
  public void moveFromStartToEnd1() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9, 1);
    kd3.generate();
    //    System.out.println(Arrays.toString(kd3.getStart()));
    //    System.out.println(Arrays.toString(kd3.getEnd()));
    //    System.out.println(kd3.graphBuilder());
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("south");
    kd3.move("west");
    assertTrue(kd3.checkReachEnd());
  }

  @Test
  public void moveToAllCells() {
    Dungeons kd3 = new WrappedDungeon(4, 4, 17);
    kd3.generate();
    kd3.move("south");
    kd3.move("east");
    kd3.move("north");
    kd3.move("east");
    kd3.move("south");
    kd3.move("east");
    kd3.move("north");
    kd3.move("north");
    kd3.move("north");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    assertTrue(kd3.checkReachEnd());
  }

  @Test
  public void moveToAllCells1() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9, 1);
    kd3.generate();
    //System.out.println(Arrays.toString(kd3.getStart()));
    //System.out.println(Arrays.toString(kd3.getEnd()));
    //System.out.println(kd3.graphBuilder());
    kd3.move("east");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("east");
    kd3.move("south");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("north");
    assertTrue(kd3.checkReachEnd());
  }

  @Test
  public void testGetCellType() {
    assertEquals("You are in a cave.", d1.getCellType());
    assertEquals("You are in a cave.", d2.getCellType());
    d1.move("east");
    assertEquals("You are in a tunnel.", d1.getCellType());
  }

  @Test
  public void testGetMonster() {
    d1.addMonster(2);
    d2.addMonster(2);
    assertEquals("[2, 2] [3, 1] ", d1.getMonsters());
    assertEquals("[2, 3] [1, 1] ", d2.getMonsters());
  }

  @Test
  public void testGetCurrentArrow() {
    assertEquals(3, d1.getCurrentArrow());
    assertEquals(3, d2.getCurrentArrow());
  }

  @Test
  public void testGetPlayerStatus() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9, 1);
    kd3.generate();
    kd3.addMonster(1);
    assertEquals("ALIVE", kd3.getPlayerStatus().toString());
    kd3.move("east");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("east");
    kd3.move("south");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("north");
    assertEquals("DEAD", kd3.getPlayerStatus().toString());
  }

  @Test
  public void testSmellMonster() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9, 1);
    kd3.generate();
    kd3.addMonster(1);
    kd3.move("east");
    assertEquals(" nothing here ", kd3.smellMonster());
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("east");
    kd3.move("south");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    assertEquals(" a less pungent smell ", kd3.smellMonster());
    kd3.move("east");
    kd3.move("east");
    kd3.move("west");
    assertEquals(" nothing here ", kd3.smellMonster());
    kd3.move("west");
    kd3.move("west");
    kd3.move("north");
  }

  @Test
  public void testShootArrow() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9, 1);
    kd3.generate();
    kd3.addMonster(1);
    assertEquals("ALIVE", kd3.getPlayerStatus().toString());
    kd3.move("east");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("east");
    kd3.move("south");
    kd3.move("west");
    kd3.move("west");
    kd3.move("south");
    kd3.move("east");
    kd3.move("east");
    kd3.move("west");
    kd3.move("west");
    kd3.move("west");
    assertEquals("you injured a monster!", kd3.shootArrow(Directions.NORTH, 1));
    assertEquals("you killed a monster!", kd3.shootArrow(Directions.NORTH, 1));
    kd3.move("north");
    assertEquals("ALIVE", kd3.getPlayerStatus().toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidShootArrow() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    kd3.addMonster(1);
    kd3.shootArrow(null, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidShootArrow2() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    kd3.addMonster(1);
    kd3.shootArrow(Directions.EAST, 61);
  }

  @Test
  public void testGetItemNumber() {
    assertEquals(3, d1.getCurrentArrow());
    assertEquals(3, d2.getCurrentArrow());
    assertEquals(0, d1.getCurrentDia());
    assertEquals(0, d2.getCurrentDia());
    assertEquals(0, d1.getCurrentRub());
    assertEquals(0, d2.getCurrentRub());
    assertEquals(0, d1.getCurrentSap());
    assertEquals(0, d2.getCurrentSap());
  }

  @Test
  public void testGetItemNumber2() {
    assertEquals(0, d1.getThisCellArrow());
    assertEquals(0, d2.getThisCellArrow());
    assertEquals(0, d1.getThisCellDiamond());
    assertEquals(0, d2.getThisCellDiamond());
    assertEquals(0, d1.getThisCellRuby());
    assertEquals(0, d2.getThisCellRuby());
    assertEquals(0, d1.getThisCellSap());
    assertEquals(0, d2.getThisCellSap());
  }

  @Test
  public void testStartToEndLength() {
    Dungeons kd3 = new UnwrappedDungeon(6, 8, 12, 1);
    kd3.generate();
    assertEquals(5, Math.abs(kd3.getStart()[0] - kd3.getEnd()[0]) +
            Math.abs(kd3.getStart()[1] - kd3.getEnd()[1]));
  }

  @Test
  public void testMonsterEndLoc() {
    d1.addMonster(1);
    assertEquals(Arrays.toString(d1.getEnd()) + " ", d1.getMonsters());
  }

  @Test
  public void testGetCurId() {
    assertEquals(6, d1.getCurCellId());
    assertEquals(1, d2.getCurCellId());
  }

  @Test
  public void testGetPreId() {
    assertEquals(-1, d1.getPreCellId());
    assertEquals(-1, d2.getPreCellId());
  }

  @Test
  public void testGetSurroundingId() {
    assertEquals("[0, 12, 7, 11]", Arrays.toString(d1.getSurroundingIds(6).toArray()));
  }

  @Test
  public void testGetCurrentCell() {
    assertEquals("* [1, 0] [NORTH, SOUTH, WEST, EAST]. Has 0 dia, 0 rub, 0 sap. 0 arrow.*",
            d1.getCurrentCell().toString());
    assertEquals("* [0, 1] [SOUTH, WEST, EAST]. Has 0 dia, 0 rub, 0 sap. 0 arrow.*",
            d2.getCurrentCell().toString());
  }

  @Test
  public void testGetArrowLocation() {
    d1.shootArrow(Directions.SOUTH, 1);
    assertEquals("* [2, 0] [NORTH, SOUTH, WEST, EAST]. Has 0 dia, 0 rub, 0 sap. 0 arrow.*",
            d1.getArrowLocation().toString());
  }

  @Test
  public void testGetCellById() {
    assertEquals("* [0, 1] [NORTH, WEST, EAST]. Has 0 dia, 0 rub, 0 sap. 0 arrow.*",
            d1.getCellById(1).toString());
  }

  @Test
  public void testSmellByCell() {
    assertEquals(" nothing here ", d1.smellMonsterByCell(1));
  }

  @Test
  public void testAddOb() {
    d1.addPit(1);
    assertEquals("  |    |    |    |    |    |  \n" +
            " 0 0--0 1--0 2--0 3--0 4--0 5 \n" +
            "  |              |    |    |  \n" +
            "  |              |    |    |  \n" +
            "-1 0--1 1--1 2--1 3  1 4  1 5-\n" +
            "  |         |                 \n" +
            "  |         |                 \n" +
            "-2 0--2 1--2 2--2 3  2 4--2 5-\n" +
            "  |    |    |    |         |  \n" +
            "  |    |    |    |         |  \n" +
            "-3 0--3 1  3 2  3 3--3 4--3 5-\n" +
            "  |    |    |    |    |    |  ", d1.graphBuilder());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddOb1() {
    d1.addPit(-1);
  }

  @Test
  public void testAddOb2() {
    d1.addThief(1);
    assertEquals("  |    |    |    |    |    |  \n" +
            " 0 0--0 1--0 2--0 3--0 4--0 5 \n" +
            "  |              |    |    |  \n" +
            "  |              |    |    |  \n" +
            "-1 0--1 1--1 2--1 3  1 4  1 5-\n" +
            "  |         |                 \n" +
            "  |         |                 \n" +
            "-2 0--2 1--2 2--2 3  2 4--2 5-\n" +
            "  |    |    |    |         |  \n" +
            "  |    |    |    |         |  \n" +
            "-3 0--3 1  3 2  3 3--3 4--3 5-\n" +
            "  |    |    |    |    |    |  ", d1.graphBuilder());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddOb3() {
    d1.addThief(-1);
  }

  @Test
  public void testLost() {
    Dungeons kd3 = new UnwrappedDungeon(4, 4, 9, 1);
    kd3.generate();
    kd3.addThief(1);
    //System.out.println(kd3.getCurrentCell().getId());
    //System.out.println(Arrays.toString(kd3.getStart()));
    //System.out.println(kd3.graphBuilder());
    kd3.move("south");
    kd3.move("south");
    kd3.move("east");
    kd3.move("west");
    kd3.move("east");
    kd3.move("west");
    kd3.move("east");
    kd3.move("west");
    assertEquals("No more arrows!", kd3.shootArrow(Directions.SOUTH, 1));
    //assertEquals("you killed a monster!", kd3.shootArrow(Directions.NORTH, 1));
    //kd3.move("north");
    //assertEquals("ALIVE", kd3.getPlayerStatus().toString());
  }
}