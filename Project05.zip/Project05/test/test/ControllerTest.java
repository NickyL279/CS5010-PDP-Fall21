package test;

import org.junit.Test;
import java.io.IOException;
import java.io.StringReader;
import controller.Controller;
import controller.GameController;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the controller.
 */
public class ControllerTest {

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidRow() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"0", "4", "17", "1", "45", "45", "1"});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCol() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "0", "17", "1", "45", "45", "1"});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidInter() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "0", "1", "45", "45", "1", "1"});
    Controller g1 = new GameController(input, gameLog,
            new String[]{"4", "4", "30", "1", "45", "45", "1", "1"});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTypeDungeon() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "3", "45", "45", "1"});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTreasurePer() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "12", "45", "1"});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidArrowPer() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "12", "120", "1"});
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMonsterNum() {
    StringReader input = new StringReader("");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "12", "120", "0"});
  }

  @Test
  public void testMoveToAllCells() throws IOException {
    StringReader input = new StringReader("m east m east m east m south m west m west m west" +
            " m south m east m east s east 1 s east 1 m south" +
            "m east m west m west m west m east m east m east m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a more pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a more pungent smell \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a more pungent smell \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you injured a monster!\n" +
            "You smell a more pungent smell \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you killed a monster!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Invalid direction! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Invalid operation, try again\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Whoa, Whoa, Whoa, you reached the goal point!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testMoveFromStartToEnd() throws IOException {
    StringReader input = new StringReader("m east m east m east m south s south 1 s south 1" +
            " m south q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a more pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you injured a monster!\n" +
            "You smell a more pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you killed a monster!\n" +
            "You smell nothing here \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Whoa, Whoa, Whoa, you reached the goal point!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidRows() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"1", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCols() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "1", "17", "1", "45", "45", "1", "1"});
    g.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidInterConnectivity() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "18", "1", "45", "45", "1", "1"});
    g.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidType() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "3", "45", "45", "1", "1"});
    g.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTreasurePercent() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "12", "45", "1", "1"});
    g.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidArrowPercent() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "102", "1", "1"});
    g.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTreasureNumber() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "24", "1"});
    g.playGame();
  }

  @Test
  public void testValidDirection() throws IOException {
    StringReader input = new StringReader("m east q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testValidDirectionAndInvalidDirection() throws IOException {
    StringReader input = new StringReader("m east m easter q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Invalid direction! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testInvalidDirection() throws IOException {
    StringReader input = new StringReader("m easter q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Invalid direction! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testInvalidOption() throws IOException {
    StringReader input = new StringReader("m easter 1 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Invalid direction! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Invalid operation, try again\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testValidAndInvalidOption() throws IOException {
    StringReader input = new StringReader("1 m east q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Invalid operation, try again\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testValidShoot() throws IOException {
    StringReader input = new StringReader("m east s east 1 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testValidAndInvalidShoot() throws IOException {
    StringReader input = new StringReader("s east 1 s eastf q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "Invalid direction! Try shoot again!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testValidAndInvalidShoot2() throws IOException {
    StringReader input = new StringReader("s east 1 s east 134 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "Too far! Shoot between 1 - 5\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }


  @Test
  public void testShootThroughTunnel() throws IOException {
    StringReader input = new StringReader("s south 2 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "5", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testShootThroughRoom() throws IOException {
    StringReader input = new StringReader("s east 2 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testShootOnTheWall() throws IOException {
    StringReader input = new StringReader("s west 1 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "11", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "You shoot at a wall!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testInjureMonster() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testKillMonster() throws IOException {
    StringReader input = new StringReader("m east m east m east m south s south 1 s south 1 q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a more pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you injured a monster!\n" +
            "You smell a more pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you killed a monster!\n" +
            "You smell nothing here \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testEatenByMonster() throws IOException {
    StringReader input = new StringReader("m east m east m north q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testPickItem() throws IOException {
    StringReader input = new StringReader("p q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "You smell nothing here \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testWin() throws IOException {
    StringReader input = new StringReader("m east m east s north 1 s north 1 m north q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testWinGameWithInvalid() throws IOException {
    StringReader input = new StringReader("m east m east m easter s easrt"
            + " s north 1 s north 1 m north q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "17", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Invalid direction! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "Invalid direction! Try shoot again!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Direction and distance?\n" +
            "you missed!\n" +
            "You smell nothing here \n" +
            "You find 1 arrow here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "You smell a less pungent smell \n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, SOUTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  @Test
  public void testMoveToInvalid() throws IOException {
    StringReader input = new StringReader("m south m south q");
    StringBuffer gameLog = new StringBuffer();
    Controller g = new GameController(input, gameLog,
            new String[]{"4", "4", "1", "1", "45", "45", "1", "1"});
    g.playGame();
    assertEquals("Welcome to the dungeon!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Cannot move to this position! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Enter the direction:\n" +
            "Cannot move to this position! Try move again!\n" +
            "You smell nothing here \n" +
            "You find 1 treasure here\n" +
            "You are in a cave.\n" +
            "Doors lead to the NORTH, WEST, EAST\n" +
            "Move, Pickup, or Shoot (M-P-S)?\n" +
            "Game quit!\n" +
            "You collected 0 diamond(s)\n" +
            "You collected 0 rubie(s)\n" +
            "You collected 0 sapphire(s)\n", gameLog.toString());
  }

  //  @Test
  //  public void test() throws IOException {
  //    StringReader input = new StringReader("m easter 1 q");
  //    StringBuffer gameLog = new StringBuffer();
  //    Controller g = new GameController(input, gameLog, new String[]{"4", "4", "17", "1",
  //            "45", "45", "1"});
  //    g.playGame();
  //    assertEquals("", gameLog.toString());
  //  }

}
