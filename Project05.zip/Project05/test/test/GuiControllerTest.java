package test;

import org.junit.Test;
import java.awt.Component;
import controller.GuiController;
import controller.GuiControllers;
import model.Directions;
import view.DungeonView;
import view.MockView;
import view.View;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the GUI controller.
 */
public class GuiControllerTest {

  @Test(expected = IllegalArgumentException.class)
  public void testConstruct() {
    GuiControllers guiController = new GuiController(null);
  }

  //@Test
  //public void testGenerate() {
  //  View dummy = new DungeonView("Test");
  //  GuiControllers guiController = new GuiController(dummy);
  //  assertEquals("", guiController.)
  //}


  @Test(expected = IllegalArgumentException.class)
  public void testMove() {
    View dummy = new DungeonView("Test");
    GuiControllers guiController = new GuiController(dummy);
    guiController.move(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testClick() {
    View dummy = new DungeonView("Test");
    GuiControllers guiController = new GuiController(dummy);
    guiController.clickHelper(-1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPopup() {
    View dummy = new DungeonView("Test");
    GuiControllers guiController = new GuiController(dummy);
    guiController.popupHelper(null, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPopup1() {
    View dummy = new DungeonView("Test");
    GuiControllers guiController = new GuiController(dummy);
    guiController.popupHelper(new Component() {
    }, -1);
  }

  @Test
  public void testRemove() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.start();
    assertEquals("setCommands\n", log.toString());
  }

  @Test
  public void testRemove1() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n", log.toString());
  }

  @Test
  public void testRemove2() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.pick();
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "refreshItemsBar\n" +
            "refreshAfterPick\n", log.toString());
  }

  @Test
  public void testRemove3() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.move(Directions.NORTH);
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "refreshAfterMove\n" +
            "refreshItemsBar\n" +
            "resetFocus\n" +
            "displayResult\n" +
            "removeDungeonPanel\n" +
            "showEnd\n", log.toString());
  }

  @Test
  public void testRemove4() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.shoot();
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "showShootOptions\n" +
            "showDistanceOptions\n", log.toString());
  }

  @Test
  public void testRemove5() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.endGame();
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "removeDungeonPanel\n" +
            "showEnd\n", log.toString());
  }

  @Test
  public void testRemove6() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.stopGame();
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "removeDungeonPanel\n" +
            "addSet\n", log.toString());
  }

  @Test
  public void testRemove7() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.startNew();
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "removeEndPanel\n" +
            "removeDungeonPanel\n" +
            "addSet\n", log.toString());
  }

  @Test
  public void testRemove8() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.startSame();
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n" +
            "removeEndPanel\n" +
            "removeDungeonPanel\n" +
            "setModel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n", log.toString());
  }

  @Test
  public void testRemove9() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.clickHelper(1);
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n", log.toString());
  }

  @Test
  public void testRemove10() {
    StringBuilder log = new StringBuilder();
    View dummy = new MockView(log);
    GuiControllers guiController = new GuiController(dummy);
    guiController.createDungeon("4", "6", "12", "666", "1", "20", "20", "1", "1", "1");
    guiController.popupHelper(new Component() {
    }, 1);
    assertEquals("setModel\n" +
            "removeSetPanel\n" +
            "showDungeon\n" +
            "setDungeonCommand\n" +
            "resetFocus\n", log.toString());
  }
}
