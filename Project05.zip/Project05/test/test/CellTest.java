package test;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import model.Cell;
import model.Cells;
import model.Directions;
import model.Otyugh;
import model.Player;
import model.Treasures;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Class that tests the cell.
 */
public class CellTest {
  Cells c1;
  Player p;

  @Before
  public void setUp() {
    c1 = new Cell(new int[]{1, 2}, 1);
    p = new Player();
  }

  @Test
  public void testMonster() {
    c1.addMonster(new Otyugh());
    assertEquals("Otyugh here!", c1.getOtyugh().toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddInvalidMonster() {
    c1.addMonster(null);
  }

  @Test
  public void testSetMonster() {
    c1.addMonster(new Otyugh());
    c1.setOtyugh();
    assertNull(c1.getOtyugh());
  }

  @Test
  public void setArrow() {
    c1.setArrowNum();
    assertEquals(1, c1.getArrowNum());
  }

  @Test(expected = IllegalArgumentException.class)
  public void createInvalid() {
    Cells c2 = new Cell(new int[]{-1, 2});
  }

  @Test
  public void getLocation() {
    assertEquals("[1, 2]", Arrays.toString(c1.getLocation()));
  }

  @Test
  public void getId() {
    c1.setId(1);
    assertEquals(1, c1.getId());
  }

  @Test(expected = IllegalArgumentException.class)
  public void getId1() {
    c1.setId(-1);
  }

  @Test
  public void testGetCell() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("* [0, 0] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*",
            c1.getCell(Directions.NORTH).toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidGetCell() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    c1.getCell(null);
  }

  @Test
  public void getDirection() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("* [0, 0] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c1.getNorth().toString());
    assertEquals("* [0, 1] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c1.getSouth().toString());
    assertEquals("* [0, 2] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c1.getEast().toString());
    assertEquals("* [0, 3] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c1.getWest().toString());
    assertEquals("[NORTH, SOUTH, WEST, EAST]", String.join(" ", c1.getDirections().toString()));
  }

  @Test(expected = IllegalArgumentException.class)
  public void getDirection1() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(null);
    c1.setSouth(null);
    c1.setEast(null);
    c1.setWest(null);
  }

  @Test
  public void getTreasure() {
    c1.setTreasure();
    assertEquals(0, c1.getDiamondNum());
    assertEquals(1, c1.getRubiesNum());
    assertEquals(0, c1.getSapphiresNum());
  }

  @Test
  public void toStringTest() {
    assertEquals("* [1, 2] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c1.toString());
    c1.setTreasure();
    assertEquals("* [1, 2] []. Has 0 dia, 1 rub, 0 sap. 0 arrow.*", c1.toString());
    p.pickTreasure(c1);
    assertEquals("* [1, 2] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c1.toString());
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("* [1, 2] [NORTH, SOUTH, WEST, EAST]. Has 0 dia, 0 rub, 0 sap. 0 arrow.*",
            c1.toString());
  }

  @Test
  public void testGraph() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("  |  \n" +
            "-1 2-\n" +
            "  |  ", c1.cellGraphHelper());
  }

  @Test
  public void testDfsHelper() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("[* [0, 0] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*," +
            " * [0, 1] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*," +
            " * [0, 3] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*," +
            " * [0, 2] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*]",
            String.join(" ", c1.dfsHelper().toString()));
  }

  @Test
  public void testAddTreasure() {
    Cells c2 = new Cell(new int[]{0, 0});
    c2.addTreasure(Treasures.DIAMONDS);
    c2.addTreasure(Treasures.RUBIES);
    c2.addTreasure(Treasures.SAPPHIRES);
    assertEquals(1, c2.getDiamondNum());
    assertEquals(1, c2.getRubiesNum());
    assertEquals(1, c2.getSapphiresNum());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddTreasure1() {
    Cells c2 = new Cell(new int[]{0, 0});
    c2.addTreasure(null);
  }

  @Test
  public void testGetArrow() {
    Cells c2 = new Cell(new int[]{0, 0});
    c2.setArrowNum();
    assertEquals("* [0, 0] []. Has 0 dia, 0 rub, 0 sap. 1 arrow.*", c2.toString());
    assertEquals("ARROW", c2.getArrow().toString());
    assertEquals("* [0, 0] []. Has 0 dia, 0 rub, 0 sap. 0 arrow.*", c2.toString());
  }

  @Test
  public void testSurroundingIds() {
    Cells c2 = new Cell(new int[]{0, 0});
    Cells c3 = new Cell(new int[]{0, 1});
    Cells c4 = new Cell(new int[]{0, 2});
    Cells c5 = new Cell(new int[]{0, 3});
    c2.setId(1);
    c3.setId(2);
    c4.setId(3);
    c5.setId(4);
    c1.setNorth(c2);
    c1.setSouth(c3);
    c1.setEast(c4);
    c1.setWest(c5);
    assertEquals("[1, 2, 3, 4]", Arrays.toString(c1.getSurroundingIds().toArray()));
  }

  @Test
  public void testAddOb() {
    Cells c2 = new Cell(new int[]{0, 0});
    c2.addPit();
    assertEquals("PIT", c2.getObstacles().toString());
  }

  @Test
  public void testAddOb1() {
    Cells c2 = new Cell(new int[]{0, 0});
    c2.addThief();
    assertEquals("THIEF", c2.getObstacles().toString());
  }
}
