package test;

import org.junit.Before;
import org.junit.Test;

import model.Cell;
import model.Cells;
import model.Dungeons;
import model.Player;
import model.Treasures;
import model.UnwrappedDungeon;
import model.WrappedDungeon;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the player.
 */
public class PlayerTest {
  Player player;
  Dungeons d1;
  Dungeons d2;

  @Before
  public void setUp() {
    player = new Player();
    d1 = new WrappedDungeon(4, 6, 12, 1);
    d1.generate();
    d2 = new UnwrappedDungeon(6, 8, 16, 1);
    d2.generate();
  }

  @Test
  public void testGetDiamond() {
    assertEquals(0, player.getDiamondNum());
    player.addTreasure(Treasures.DIAMONDS);
    assertEquals(1, player.getDiamondNum());
  }

  @Test
  public void testGetRub() {
    assertEquals(0, player.getRubiesNum());
    player.addTreasure(Treasures.RUBIES);
    assertEquals(1, player.getRubiesNum());
  }

  @Test
  public void testGetSap() {
    assertEquals(0, player.getSapphiresNum());
    player.addTreasure(Treasures.SAPPHIRES);
    assertEquals(1, player.getSapphiresNum());
  }

  @Test
  public void testPickTreasure() {
    Cells cells = new Cell(new int[]{1, 1}, 1);
    cells.setTreasure();
    player.pickTreasure(cells);
    assertEquals(0, player.getDiamondNum());
    assertEquals(1, player.getRubiesNum());
    assertEquals(0, player.getSapphiresNum());
  }

  @Test (expected = IllegalArgumentException.class)
  public void testPickTreasure1() {
    d1.addTreasure(20);
    player.pickTreasure(d1.getCellMap()[3][5]);
  }

  @Test
  public void testPickArrow() {
    Cells cells = new Cell(new int[]{1, 1});
    cells.setArrowNum();
    player.pickArrow(cells);
    assertEquals(4, player.getArrowNum());
  }

  @Test
  public void testPickArrow1() {
    Cells cells = new Cell(new int[]{1, 1});
    player.pickArrow(cells);
    assertEquals(3, player.getArrowNum());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPickArrow2() {
    player.pickArrow(null);
  }

  @Test
  public void testLoseArrow() {
    player.loseArrow();
    assertEquals(2, player.getArrowNum());
  }
}
