package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import model.dungeon.Directions;
import model.dungeon.Dungeon;
import model.dungeon.Dungeons;
import model.dungeon.Status;
import model.kruskal.KruskalDungeon;
import model.kruskal.UnwrappedDungeon;
import model.kruskal.WrappedDungeon;

public class GameControllerAuto implements ControllerArgs {
  private final Appendable out;
  private final Scanner scan;
  private int rows;
  private int cols;
  private int interConnect;
  private int type;
  private int perTreasure;
  private int perArrow;
  private int monsNum;

  public GameControllerAuto(Readable in, Appendable out) {
    if (in == null || out == null) {
      throw new IllegalArgumentException("Readable and Appendable can't be null");
    }
    this.out = out;
    scan = new Scanner(in);
  }

  @Override
  public void gatherInfo(String[] s) {
    rows = Integer.parseInt(s[0]);
    cols = Integer.parseInt(s[1]);
    interConnect = Integer.parseInt(s[2]);
    type = Integer.parseInt(s[3]);
    perTreasure = Integer.parseInt(s[4]);
    perArrow = Integer.parseInt(s[5]);
    monsNum = Integer.parseInt(s[6]);
  }

  @Override
  public void playGame() throws IOException {
    try {
      KruskalDungeon dungeonGraph;
      switch (type) {
        case 1 -> {
          dungeonGraph = new WrappedDungeon(rows, cols, interConnect);
        }
        case 2 -> {
          dungeonGraph = new UnwrappedDungeon(rows, cols, interConnect);
        }
        default -> {
          throw new IllegalArgumentException("Wrong type!");
        }
      }
      dungeonGraph.generate();
      dungeonGraph.addTreasure(perTreasure);
      dungeonGraph.addArrow(perArrow);
      Dungeons dungeonGame = new Dungeon(dungeonGraph.getCellMap());
      dungeonGame.addMonster(monsNum);
      out.append("The item map of this dungeon:").append("\n")
              .append(dungeonGame.toString()).append("\n");
      out.append("The cave map of this dungeon:").append("\n")
              .append(dungeonGame.graphBuilder()).append("\n");
      out.append("\n").append("The monster position of this dungeon:").append("\n")
              .append(dungeonGame.getMonsters()).append("\n");
      out.append("\n").append("The player's start point is: ").append(Arrays.toString(dungeonGame.getStart()))
              .append("\n");
      out.append("\n").append("The player's goal point is: ").append(Arrays.toString(dungeonGame.getEnd()))
              .append("\n");
      while (!dungeonGame.checkWin() && dungeonGame.getPlayerStatus() == Status.ALIVE) {
        out.append("\n").append("You smell").append(dungeonGame.smellMonster()).append("\n");
        int tmpDNum = dungeonGraph.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]]
                .getDiamondNum();
        if (tmpDNum != 0) {
          out.append("You find ").append(String.valueOf(tmpDNum)).append(" diamond here").append("\n");
        }
        int tmpRNum = dungeonGraph.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]]
                .getRubiesNum();
        if (tmpRNum != 0) {
          out.append("You find ").append(String.valueOf(tmpRNum)).append(" ruby here").append("\n");
        }
        int tmpSNum = dungeonGraph.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]]
                .getSapphiresNum();
        if (tmpSNum != 0) {
          out.append("You find ").append(String.valueOf(tmpSNum)).append(" sapphire here").append("\n");
        }
        int tmpANum = dungeonGraph.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]]
                .getArrowNum();
        if (tmpANum != 0) {
          out.append("You find ").append(String.valueOf(tmpANum)).append(" arrow here").append("\n");
        }
        out.append("You are in a cave:")
                .append(Arrays.toString(dungeonGame.getLoc())).append("\n");
        out.append("Doors lead to the ")
                .append(Arrays.toString(dungeonGame.getPosDirections().toArray())).append("\n");
        out.append("Move, Pickup, or Shoot (M-P-S)?").append("\n");
        String choice = scan.next().toUpperCase();
        switch (choice) {
          case "M" -> {
            out.append("Enter the direction:").append("\n");
            Scanner scanner = new Scanner(System.in);
            String tmpDirection = scanner.nextLine().toLowerCase().trim();
            dungeonGame.move(tmpDirection);
            break;
          }
          case "P" -> {
            dungeonGame.pickTreasure();
            dungeonGame.pickArrow();
            break;
          }
          case "S" -> {
            out.append("Direction and distance?").append("\n");
            Scanner scanner = new Scanner(System.in);
            String tmpDirection = scanner.nextLine().toLowerCase().trim();
            Directions d = null;
            switch (tmpDirection) {
              case "north" -> {
                d = Directions.NORTH;
              }
              case "south" -> {
                d = Directions.SOUTH;
              }
              case "west" -> {
                d = Directions.WEST;
              }
              case "east" -> {
                d = Directions.EAST;
              }
              default -> {
                try {
                  out.append("Invalid direction, shoot again");
                } catch (IOException e) {
                  throw new IllegalStateException("Append failed", e);
                }
              }
            }
            int dis = Integer.parseInt(scanner.next());
            out.append(dungeonGame.shootArrow(d, dis));
          }
          default -> {
            try {
              out.append("Invalid operation, try again");
            } catch (IOException e) {
              throw new IllegalStateException("Append failed", e);
            }
          }
        }
      }
      if (dungeonGame.getPlayerStatus().equals(Status.DEAD)) {
        try {
          out.append("Chomp, chomp, chomp, you are eaten by an Otyugh!").append("\n");
        } catch (IOException e) {
          throw new IllegalStateException("Append failed", e);
        }
      } else if (dungeonGame.checkWin()) {
        try {
          out.append("Whoa, Whoa, Whoa, you reached the goal point!").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGame.getCurrentDia()))
                  .append(" diamond(s)").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGame.getCurrentRub()))
                  .append(" rubie(s)").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGame.getCurrentSap()))
                  .append(" sapphire(s)").append("\n");
        } catch (IOException e) {
          throw new IllegalStateException("Append failed", e);
        }
      }
    } catch (IOException e) {
      throw new IllegalStateException("Append failed", e);
    }
  }


}


