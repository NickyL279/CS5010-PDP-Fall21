package controller;

import java.io.IOException;

public interface ControllerArgs {
  void playGame() throws IOException;
  void gatherInfo(String[] s);

}
