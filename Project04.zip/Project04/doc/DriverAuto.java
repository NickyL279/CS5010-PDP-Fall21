import model.dungeon.Dungeon;
import model.dungeon.Dungeons;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import model.kruskal.KruskalDungeon;
import model.kruskal.UnwrappedDungeon;
import model.kruskal.WrappedDungeon;

/**
 * The Driver class represents a dungeon game which allows a player explore and pick treasures.
 */
public class DriverAuto {
  private static int row;
  private static int col;
  private static int interconnectivity;
  private static int isWrapped;
  private static int[] start;
  private static int[] end;
  private static KruskalDungeon maze;
  private static Dungeons dungeonGame;

  /**
   * The main method demonstrates a game process.
   */
  public static void main(String[] args) {
    System.out.println("-----------------------------Dungeon-------------------------------\n");
    System.out.println("---------------------------Setting up------------------------------\n");
    System.out.println("Please insert rows: ");
    Scanner scanner = new Scanner(System.in);
    row = scanner.nextInt();
    System.out.println("Please insert columns: ");
    col = scanner.nextInt();
    System.out.printf("Please insert interconnectivity: (wrapped between 0 to %d/"
                    + " unwrapped between 0 to %d)%n",(row - 1) * col + (col - 1)
                    * row - row * col + 1 + row + col,
            (row - 1) * col + (col - 1) * row - row * col + 1);
    interconnectivity = scanner.nextInt();
    System.out.println("Please insert whether this dungeon is wrapped (1 for yes/2 for no): ");
    isWrapped = scanner.nextInt();
    System.out.println("---------------------------Setup done------------------------------\n");
    System.out.println("--------------------------Building maze----------------------------\n");
    if (isWrapped == 1) {
      maze = new WrappedDungeon(row, col, interconnectivity);

    } else {
      maze = new UnwrappedDungeon(row, col, interconnectivity);
    }
    maze.generate();
    System.out.println("Please insert treasure percentage: ");
    int percentage = scanner.nextInt();
    maze.addTreasure(percentage);
    System.out.println("--------------------------Build done-------------------------------\n");
    System.out.println("-----------------------Building dungeon----------------------------\n");
    System.out.println("-----------------------------");
    System.out.println("----Dungeon info----");
    System.out.println("----" + row + " rows----");
    System.out.println("----" + col + " cols----");
    if (isWrapped == 1) {
      System.out.println("----Wrapped Dungeon----");
    } else {
      System.out.println("----Non-Wrapped Dungeon----");
    }
    System.out.println("-----------------------------");
    dungeonGame = new Dungeon(maze.getCellMap());
    System.out.println("The player's start point is: " + Arrays.toString(dungeonGame.getStart()));
    System.out.println("The player's goal point is: " + Arrays.toString(dungeonGame.getEnd()));
    System.out.println("----------------------------Build done-----------------------------\n");
    System.out.println(dungeonGame.toString());
    System.out.println(dungeonGame.graphBuilder());
    System.out.println(String.join(" ", dungeonGame.getMonsters().toString()));
    System.out.println("--------------------------Playing game-----------------------------\n");
    System.out.printf("Welcome our challenger! The player has"
                    + " %d diamonds, %d rubies, %d sapphires. \n",
            dungeonGame.getCurrentDia(), dungeonGame.getCurrentRub(),
            dungeonGame.getCurrentSap());
    boolean flag = false;
    int moveCnt = 0;
    while (!flag) {
      System.out.printf("---The player is at [%d, %d][des: %d, %d]---%n",
              dungeonGame.getLoc()[0], dungeonGame.getLoc()[1],
              dungeonGame.getEnd()[0], dungeonGame.getEnd()[1]);
      if (moveCnt == 0) {
        System.out.printf("---This room has %d diamonds, %d rubies, %d sapphires.--- \n",
                diamondHelper(),
                rubyHelper(),
                sapphireHelper());
        if (!(diamondHelper() == 0 && rubyHelper() == 0 && sapphireHelper() == 0)) {
          System.out.println("---Do you want to pick up treasures? (1 for yes/2 for no)---");
          // int want = scanner.nextInt();
          // if (want == 1) {
            dungeonGame.pickTreasure();
          // }
        }
      }
      System.out.printf("---You can move to: %s---", String.join(", ",
              dungeonGame.getPosDirections().toString().toLowerCase()));
      System.out.println("\n---Please insert the direction: ---");
      // String tmpDirection = directionHelper(scanner);
      //System.out.println("Direction confirmed.");
      Random random = new Random();
      String tmpDirection = dungeonGame.getPosDirections().get(random.nextInt(dungeonGame.getPosDirections().size())).toString().toLowerCase();
      dungeonGame.move(tmpDirection);
      moveCnt++;
      System.out.println(dungeonGame.graphBuilder());
      System.out.printf("---You've entered [%d, %d]. ---\n",
              dungeonGame.getLoc()[0], dungeonGame.getLoc()[1]);
      System.out.printf("---This room has %d diamonds, %d rubies, %d sapphires. ---\n",
              diamondHelper(),
              rubyHelper(),
              sapphireHelper());
      if (!(diamondHelper() == 0 && rubyHelper() == 0 && sapphireHelper() == 0)) {
        System.out.println("---Do you want to pick up treasures? (1 for yes/2 for no)---");
        // int want = scanner.nextInt();
        // if (want == 1) {
          dungeonGame.pickTreasure();
        // }
      }
      System.out.printf("---This player has collected %d diamonds, %d rubies,"
                      + " %d sapphires so far.---\n",
              dungeonGame.getCurrentDia(), dungeonGame.getCurrentRub(),
              dungeonGame.getCurrentSap());
      if (dungeonGame.checkWin()) {
        System.out.println("\n****Congrats! Find your way out!****");
        System.out.printf("---This player has collected %d diamonds, %d rubies, %d sapphires!---\n",
                dungeonGame.getCurrentDia(), dungeonGame.getCurrentRub(),
                dungeonGame.getCurrentSap());
        flag = true;
      }
    }
    System.out.println("----------------------------Game done-----------------------------\n");
  }

  private static String directionHelper(Scanner scanner) {
    String tmpDirection = scanner.nextLine().toLowerCase().trim();
    if (tmpDirection.equals("")) {
      tmpDirection = scanner.nextLine().toLowerCase().trim();
    }
    while (!(tmpDirection.equals("north") || tmpDirection.equals("south")
            || tmpDirection.equals("west") || tmpDirection.equals("east"))) {
      System.out.println("Bad input. Please select one from the options!");
      tmpDirection = scanner.nextLine().toLowerCase().trim();
    }
    return tmpDirection;
  }

  private static int diamondHelper() {
    return maze.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]].getDiamondNum();
  }

  private static int rubyHelper() {
    return maze.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]].getRubiesNum();
  }

  private static int sapphireHelper() {
    return maze.getCellMap()[dungeonGame.getLoc()[0]][dungeonGame.getLoc()[1]].getSapphiresNum();
  }
}
