import java.io.IOException;
import java.io.InputStreamReader;

import controller.Controller;
import controller.ControllerArgs;
import controller.GameController;
import controller.GameControllerAuto;

public class DriverControllerAuto {

  public static void main(String[] args) throws IOException {
    if (args.length != 7) {
      throw new IOException("Usage: java -jar Project04-args.jar --rows --columns" +
              " --interconnectivity --dungeon type --treasure percentage --arrow percentage" +
              " --monster numbers");
    }
    ControllerArgs c = new GameControllerAuto(new InputStreamReader(System.in), System.out);
    c.gatherInfo(args);
    c.playGame();
  }
}
