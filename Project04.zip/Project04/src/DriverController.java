import controller.Controller;
import controller.GameController;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Run a dungeon game interactively on the console. Taking inputs as the dungeon setup and play the
 * game interactively.
 */
public class DriverController {

  /**
   * Run a dungeon game interactively on the console. Taking inputs as the dungeon setup and play
   * the game interactively.
   */
  public static void main(String[] args) throws IOException {
    // Use the IDE to run the program.
    //Controller c = new GameController(new InputStreamReader(System.in), System.out,
    //new String[]{"4", "6", "12", "2", "45", "45", "1"});
    // Use the jar to run the program.
    if (args.length != 7) {
      throw new IOException("Usage: java -jar Project04-args.jar --rows --columns" +
              " --interconnectivity --dungeon type --treasure percentage --arrow percentage" +
              " --monster numbers");
    }
    Controller c = new GameController(new InputStreamReader(System.in), System.out, args);
    c.playGame();
  }
}
