package model;

/**
 * This class represents a non-wrapping dungeon. A non-wrapping dungeon has rows, columns and
 * interconnectivity.
 */
public class UnwrappedDungeon extends AbstractDungeon {
  private final int interconnectivity;
  private int allPathSize;

  /**
   * Construct a non-wrapping dungeon object that has the provided has rows, columns and
   * interconnectivity.
   *
   * @param rows              the rows of this dungeon
   * @param cols              the columns of this dungeon
   * @param interconnectivity the interconnectivity of this dungeon
   * @throws IllegalArgumentException if interconnectivity is not valid
   */
  public UnwrappedDungeon(int rows, int cols, int interconnectivity) {
    super(rows, cols, interconnectivity);
    if (interconnectivity < 0 || interconnectivity > ((rows - 1) * cols + (cols - 1)
            * rows - rows * cols + 1)) {
      throw new IllegalArgumentException("Interconnectivity not valid.");
    }
    this.interconnectivity = interconnectivity;
  }

  @Override
  public void generate() {
    allPathSize = super.getAllPath().size();
    super.generateDungeonGraph(this.getAllPath(), this.interconnectivity);
  }

  @Override
  public int getAllPathSize() {
    return allPathSize;
  }
}
