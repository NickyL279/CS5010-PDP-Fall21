package model;

import java.util.List;

/**
 * This class represents a wrapping dungeon. A wrapping dungeon has rows, columns and
 * interconnectivity.
 */
public class WrappedDungeon extends AbstractDungeon {
  private final int interconnectivity;
  private final int rows;
  private final int cols;
  private int allPathSize;

  /**
   * Construct a wrapping dungeon object that has the provided has rows, columns and
   * interconnectivity.
   *
   * @param rows              the rows of this dungeon
   * @param cols              the columns of this dungeon
   * @param interconnectivity the interconnectivity of this dungeon
   * @throws IllegalArgumentException if interconnectivity is not valid
   */
  public WrappedDungeon(int rows, int cols, int interconnectivity) {
    super(rows, cols, interconnectivity);
    if (interconnectivity < 0 || interconnectivity > ((rows - 1) * cols + (cols - 1)
            * rows - rows * cols + 1 + rows + cols)) {
      throw new IllegalArgumentException("Interconnectivity not valid.");
    }
    this.interconnectivity = interconnectivity;
    this.rows = rows;
    this.cols = cols;
  }

  @Override
  public void generate() {
    List<int[]> allPath = super.getAllPath();
    for (int i = 0; i < rows; i++) {
      allPath.add(new int[]{i, cols - 1, i, 0});
    }
    for (int j = 0; j < cols; j++) {
      allPath.add(new int[]{rows - 1, j, 0, j});
    }
    allPathSize = allPath.size();
    super.generateDungeonGraph(allPath, this.interconnectivity);
  }

  @Override
  public int getAllPathSize() {
    return allPathSize;
  }
}
