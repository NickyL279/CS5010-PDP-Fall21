package model;

/**
 * This interface represents all the operations to be supported by player. A player has three kind
 * of treasure with different amount of them.
 */
public interface Players {
  /**
   * Return the number of diamonds of this player.
   *
   * @return the number of diamonds
   */
  int getDiamondNum();

  /**
   * Return the number of rubies of this player.
   *
   * @return the number of rubies
   */
  int getRubiesNum();

  /**
   * Return the number of Sapphires of this player.
   *
   * @return the number of Sapphires
   */
  int getSapphiresNum();

  /**
   * Pick up treasures in a given cell.
   *
   * @param cell the cell player is in
   */
  void pickTreasure(Cells cell);

  /**
   * Pick up arrows in a given cell.
   *
   * @param cell the cell player is in
   */
  void pickArrow(Cells cell);

  /**
   * Return the player's current status.
   *
   * @return the player's current status
   */
  Status getStatus();

  /**
   * Set the player's current status.
   *
   * @param status the status the player is going to be
   */
  void setStatus(Status status);

  /**
   * Return the player's current arrow number.
   *
   * @return the player's current arrow number
   */
  int getArrowNum();

  /**
   * Add a treasure to the player.
   *
   * @param t a treasure to the player
   */
  void addTreasure(Treasures t);

  /**
   * Player loses an arrow after shooting.
   */
  void loseArrow();
}
