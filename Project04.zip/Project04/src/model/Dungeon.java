package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * This class represents a dungeon. A dungeon has a start point, an end point. It also supports to
 * show the graph of this dungeon.
 */
public class Dungeon implements Dungeons {
  private final Cells[][] cellMap;
  private final int rows;
  private final int cols;
  private final Player player;
  private final int[] start;
  private final int[] end;
  private final List<int[]> monsterList;
  private final List<int[]> endList;
  private final Random random;
  private int[] playerLocation;
  private boolean winFlag;
  private Cells arrowLocation;

  /**
   * Construct a dungeon object that has the provided rows, columns and cellMap.
   *
   * @param cellMap the map to all cells to be given to this dungeon
   * @throws IllegalArgumentException if start/end point is invalid
   */
  public Dungeon(Cells[][] cellMap) {
    if (cellMap == null) {
      throw new IllegalArgumentException("Cell map cannot be null!");
    }
    this.random = new Random();
    random.setSeed(1);
    this.arrowLocation = null;
    this.cellMap = cellMap;
    this.winFlag = false;
    this.rows = cellMap.length;
    this.cols = cellMap[0].length;
    this.monsterList = new ArrayList<>();
    this.endList = new ArrayList<>();
    start = startHelper();
    end = endHelper();
    if (start[0] < 0 || start[0] >= cellMap.length
            || start[1] < 0 || start[1] >= cellMap[0].length) {
      throw new IllegalArgumentException("Bad start.");
    }
    if (end[0] < 0 || end[0] >= cellMap.length
            || end[1] < 0 || end[1] >= cellMap[0].length) {
      throw new IllegalArgumentException("Bad end.");
    }
    this.player = new Player();
    this.playerLocation = start;
  }


  private int[] startHelper() {
    while (true) {
      int randRows = random.nextInt(rows);
      int randCols = random.nextInt(cols);
      if (cellMap[randRows][randCols].getDirections().size() != 2) {
        return new int[]{randRows, randCols};
      }
    }
  }

  private int[] endHelper() {
    List<Cells> visited = new ArrayList<>();
    List<Cells> queue = new ArrayList<>();
    visited.add(cellMap[start[0]][start[1]]);
    queue.add(cellMap[start[0]][start[1]]);
    Map<Cells, Integer> distanceCnt = new HashMap<>();
    distanceCnt.put(cellMap[start[0]][start[1]], 0);
    while (queue.size() != 0 && visited.size() <= rows * cols) {
      Cells cur = queue.remove(0);
      for (Cells c : cur.dfsHelper()) {
        if (!visited.contains(c)) {
          queue.add(c);
          distanceCnt.put(c, distanceCnt.getOrDefault(cur, 0) + 1);
          visited.add(c);
        } else if (visited.contains(c) && distanceCnt.get(c) < distanceCnt.get(cur)) {
          distanceCnt.put(c, distanceCnt.getOrDefault(cur, 0) + 1);
        }
        if (distanceCnt.get(c) >= 5 && c.getDirections().size() != 2) {
          endList.add(c.getLocation());
        }
      }
    }
    return endList.get(random.nextInt(endList.size()));
  }

  @Override
  public String smellMonster() {
    int cntOne = 0;
    int cntTwo = 0;
    List<Cells> visited = new ArrayList<>();
    List<Cells> queue = new ArrayList<>();
    visited.add(cellMap[getLoc()[0]][getLoc()[1]]);
    queue.add(cellMap[getLoc()[0]][getLoc()[1]]);
    Map<Cells, Integer> distanceCnt = new HashMap<>();
    distanceCnt.put(cellMap[getLoc()[0]][getLoc()[1]], 0);
    while (queue.size() != 0 && visited.size() <= rows * cols) {
      Cells cur = queue.remove(0);
      for (Cells c : cur.dfsHelper()) {
        if (!visited.contains(c)) {
          queue.add(c);
          distanceCnt.put(c, distanceCnt.getOrDefault(cur, 0) + 1);
          visited.add(c);
          if (c.getOtyugh() != null) {
            if (distanceCnt.get(c) == 1) {
              cntOne++;
            }
            if (distanceCnt.get(c) == 2) {
              cntTwo++;
            }
          }
        }
      }
    }
    if (cntOne >= 1 || cntTwo >= 2) {
      return " a more pungent smell ";
    } else if (cntTwo >= 1 && cntOne == 0) {
      return " a less pungent smell ";
    } else {
      return " nothing here ";
    }
  }

  private Cells getCurrentCell() {
    return cellMap[this.getLoc()[0]][this.getLoc()[1]];
  }

  @Override
  public String shootArrow(Directions d, int distance) {
    if (this.player.getArrowNum() == 0) {
      return "No more arrows!";
    }
    if (distance >= 5) {
      throw new IllegalArgumentException("Too far! Shoot between 1 - 5");
    }
    if (d == null) {
      throw new IllegalArgumentException("Direction cannot be null");
    }
    this.player.loseArrow();
    this.arrowLocation = this.getCurrentCell();
    int cnt = distance;
    Directions d1 = d;
    if (!this.getPosDirections().contains(d)) {
      return "You shoot at a wall!";
    }
    while (cnt > 0) {
      if (this.getCurrentCell().getDirections().contains(d1)) {
        this.arrowLocation = this.arrowLocation.getCell(d1);
      }
      d1 = directionHelper(d1);
      cnt--;
    }
    if (arrowLocation.getOtyugh() != null) {
      if (arrowLocation.getOtyugh().isInjured()) {
        arrowLocation.setOtyugh();
        return "you killed a monster!";
      } else {
        arrowLocation.getOtyugh().setInjured();
        return "you injured a monster!";
      }
    } else {
      return "you missed!";
    }
  }

  private Directions directionHelper(Directions d) {
    if (this.arrowLocation.getDirections().size() == 2) {
      Directions incoming = tunnelDirectionHelper(d);
      for (Directions dir : this.arrowLocation.getDirections()) {
        if (dir != incoming) {
          return dir;
        }
      }
    } else {
      Directions incoming = tunnelDirectionHelper(d);
      return this.tunnelDirectionHelper(incoming);
    }
    return null;
  }

  private Directions tunnelDirectionHelper(Directions directions) {
    if (directions == null) {
      throw new IllegalArgumentException("Direction cannot be null");
    }
    switch (directions) {
      case NORTH:
        return Directions.SOUTH;
      case SOUTH:
        return Directions.NORTH;
      case WEST:
        return Directions.EAST;
      case EAST:
        return Directions.WEST;
      default:
        return null;
    }
  }


  @Override
  public Status getPlayerStatus() {
    if (this.getCurrentCell().getOtyugh() != null) {
      if (!this.getCurrentCell().getOtyugh().isInjured()) {
        this.player.setStatus(Status.DEAD);
      } else if (this.getCurrentCell().getOtyugh().isInjured()) {
        float chance = random.nextFloat();
        if (chance > 0.50f) {
          this.player.setStatus(Status.DEAD);
        }
      }
    }
    return this.player.getStatus();
  }

  @Override
  public void addMonster(int number) {
    if (number < 0 || number > rows * cols - 1) {
      throw new IllegalArgumentException("Bad number! Should between 0 to room numbers");
    }

    cellMap[end[0]][end[1]].addMonster(new Otyugh());
    monsterList.add(new int[]{end[0], end[1]});
    while (monsterList.size() <= number - 1) {
      int i = random.nextInt(this.rows);
      int j = random.nextInt(this.cols);
      if (cellMap[start[0]][start[1]] != cellMap[i][j] && !monsterList.contains(new int[]{i, j})) {
        monsterList.add(new int[]{i, j});
        cellMap[i][j].addMonster(new Otyugh());
      }
    }
  }

  @Override
  public String getMonsters() {
    StringBuilder s = new StringBuilder();
    for (int[] t : this.monsterList) {
      s.append(Arrays.toString(t)).append(" ");
    }
    return s.toString();
  }

  @Override
  public int[] getStart() {
    return start;
  }

  @Override
  public int[] getEnd() {
    return end;
  }

  /**
   * Get player's location.
   */
  @Override
  public int[] getLoc() {
    return this.playerLocation;
  }

  /**
   * Get player's current gold.
   */
  @Override
  public int getCurrentDia() {
    return this.player.getDiamondNum();
  }

  @Override
  public int getCurrentRub() {
    return this.player.getRubiesNum();
  }

  @Override
  public int getCurrentSap() {
    return this.player.getSapphiresNum();
  }

  @Override
  public int getCurrentArrow() {
    return this.player.getArrowNum();
  }

  @Override
  public List<Directions> getPosDirections() {
    return this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getDirections();
  }

  @Override
  public void move(String movement) {
    Directions movement1;
    switch (movement) {
      case "north":
        movement1 = Directions.NORTH;
        break;
      case "south":
        movement1 = Directions.SOUTH;
        break;
      case "west":
        movement1 = Directions.WEST;
        break;
      case "east":
        movement1 = Directions.EAST;
        break;
      default:
        throw new IllegalStateException("Unexpected value: " + movement);
    }

    if (!this.getPosDirections().contains(movement1)) {
      throw new IllegalArgumentException("Bad input! Cannot move to this position!");
    }
    Cells cur = this.cellMap[this.getLoc()[0]][this.getLoc()[1]];
    Cells nxt;
    switch (movement1) {
      case NORTH:
        nxt = cur.getNorth();
        break;
      case SOUTH:
        nxt = cur.getSouth();
        break;
      case WEST:
        nxt = cur.getWest();
        break;
      case EAST:
        nxt = cur.getEast();
        break;
      default:
        throw new IllegalArgumentException("Bad movement!");

    }
    if (nxt == null) {
      throw new IllegalArgumentException("Next move cannot be null!");
    }
    this.playerLocation = nxt.getLocation();
    if (this.playerLocation[0] == this.end[0] && this.playerLocation[1] == this.end[1]) {
      this.winFlag = true;
    }
  }

  @Override
  public void pickTreasure() {
    if (this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getDiamondNum() != 0
            || this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getRubiesNum() != 0
            || this.cellMap[this.playerLocation[0]][this.playerLocation[1]]
            .getSapphiresNum() != 0) {
      this.player.pickTreasure(cellMap[playerLocation[0]][playerLocation[1]]);
    }
  }

  @Override
  public void pickArrow() {
    if (this.cellMap[this.playerLocation[0]][this.playerLocation[1]].getArrowNum() != 0) {
      this.player.pickArrow(cellMap[playerLocation[0]][playerLocation[1]]);
    }
  }

  /**
   * Check player arrived the finish point or not.
   */
  @Override
  public boolean checkWin() {
    return this.winFlag;
  }

  @Override
  public String toString() {
    List<String> tmpCellMap = new ArrayList<>();
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        tmpCellMap.add(cellMap[i][j].toString());
      }
      tmpCellMap.add("\n");
    }
    return String.join("", tmpCellMap);
  }

  @Override
  public String graphBuilder() {
    String[] s3 = new String[]{"", "", ""};
    String[] s5 = new String[rows];
    Arrays.fill(s5, "");
    for (int i = 0; i < rows; i++) {
      String s4;
      for (int j = 0; j < cols; j++) {
        String[] s1 = cellMap[i][j].cellGraphHelper().split("\n");
        s3[0] = s3[0] + s1[0];
        s3[1] = s3[1] + s1[1];
        s3[2] = s3[2] + s1[2];
      }
      s4 = String.join("\n", s3);
      s5[i] = s4;
      s3 = new String[]{"", "", ""};
    }
    return String.join("\n", s5);
  }

  @Override
  public int getThisCellDiamond() {
    int tmpD = this.cellMap[this.getLoc()[0]][this.getLoc()[1]].getDiamondNum();
    return tmpD;
  }

  @Override
  public int getThisCellRuby() {
    int tmpD = this.cellMap[this.getLoc()[0]][this.getLoc()[1]].getRubiesNum();
    return tmpD;
  }

  @Override
  public int getThisCellSap() {
    int tmpD = this.cellMap[this.getLoc()[0]][this.getLoc()[1]].getSapphiresNum();
    return tmpD;
  }

  @Override
  public int getThisCellArrow() {
    int tmpD = this.cellMap[this.getLoc()[0]][this.getLoc()[1]].getArrowNum();
    return tmpD;
  }

  @Override
  public String getCellType() {
    if (this.getPosDirections().size() == 2) {
      return "You are in a tunnel.";
    } else {
      return "You are in a cave.";
    }
  }
}

