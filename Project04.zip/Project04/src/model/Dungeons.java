package model;

import java.util.List;

/**
 * This interface represents all the operations to be supported by dungeon. A dungeon has a start
 * point, end point and player's current point. It also supports to show the graph of this dungeon.
 */
public interface Dungeons {
  /**
   * Return the start point of this dungeon.
   *
   * @return the start point
   */
  int[] getStart();

  /**
   * Return the end point of this dungeon.
   *
   * @return the end point
   */
  int[] getEnd();

  /**
   * Return the player's location in this dungeon.
   *
   * @return the player's location
   */
  int[] getLoc();

  /**
   * Return the player's diamond number in this dungeon.
   *
   * @return the player's diamond number
   */
  int getCurrentDia();

  /**
   * Return the player's ruby number in this dungeon.
   *
   * @return the player's ruby number
   */
  int getCurrentRub();

  /**
   * Return the player's sapphires number in this dungeon.
   *
   * @return the player's sapphires number
   */
  int getCurrentSap();

  /**
   * Return the player's possible move direction in this dungeon.
   *
   * @return the player's possible move direction
   */
  List<Directions> getPosDirections();

  /**
   * Move the player to the desired direction in this dungeon.
   *
   * @param movement the player's move direction
   */
  void move(String movement);

  /**
   * Player picks up the treasure in current location.
   */
  void pickTreasure();

  /**
   * Player picks up the arrow in current location.
   */
  void pickArrow();

  /**
   * Return whether the player has reached the goal point.
   *
   * @return whether the player has reached the goal point
   */
  boolean checkWin();

  /**
   * Return a graphic map of the dungeon.
   *
   * @return a graphic map of the dungeon
   */
  String graphBuilder();

  /**
   * Adding the given number monster to the dungeon.
   *
   * @param number the given number monster
   */
  void addMonster(int number);

  /**
   * Return the result of smelling a monster.
   *
   * @return the result of smelling a monster
   */
  String smellMonster();

  /**
   * Return the result of shooting an arrow.
   *
   * @return the result of shooting an arrow
   */
  String shootArrow(Directions d, int distance);

  /**
   * Return the status of the player.
   *
   * @return the status of the player
   */
  Status getPlayerStatus();

  /**
   * Return the current arrow number of the player.
   *
   * @return the current arrow number of the player.
   */
  int getCurrentArrow();

  /**
   * Return the location of monsters in the dungeon.
   *
   * @return the location of monsters in the dungeon
   */
  String getMonsters();

  /**
   * Return the number of diamond in the current cell.
   *
   * @return the number of diamond in the current cell
   */
  int getThisCellDiamond();

  /**
   * Return the number of ruby in the current cell.
   *
   * @return the number of ruby in the current cell
   */
  int getThisCellRuby();

  /**
   * Return the number of sapphire in the current cell.
   *
   * @return the number of sapphire in the current cell
   */
  int getThisCellSap();

  /**
   * Return the number of arrow in the current cell.
   *
   * @return the number of arrow in the current cell
   */
  int getThisCellArrow();

  /**
   * Return the type of the current cell.
   *
   * @return the type of the current cell
   */
  String getCellType();
}
