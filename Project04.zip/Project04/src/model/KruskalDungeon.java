package model;

import java.util.List;
import model.Cells;

/**
 * This interface represents all the operations to be supported by a maze implements Kruskal
 * Algorithm.
 */
public interface KruskalDungeon {
  /**
   * Return the number of rows in this dungeon.
   *
   * @return the number of rows
   */
  int getRowNum();

  /**
   * Return the number of columns in this dungeon.
   *
   * @return the number of columns
   */
  int getColNum();

  /**
   * Return the number of interconnectivity in this dungeon.
   *
   * @return the number of interconnectivity
   */
  int getInterconnectivity();

  /**
   * Add the given percentage of treasure to this dungeon.
   *
   * @param percentage the percentage of all room who has treasure
   */
  void addTreasure(int percentage);

  /**
   * Return the list of all treasure's location in this dungeon.
   *
   * @return the list of all treasure's location
   */
  List<String> getTreasure();

  /**
   * Return the list of all paths in this dungeon.
   *
   * @return the list of all paths
   */
  List<int[]> getAllPath();

  /**
   * Generate the dungeon using kruskal algorithm.
   */
  void generate();

  /**
   * Generate the dungeon using kruskal algorithm.
   *
   * @param allPath           all the edges in the dungeon
   * @param interconnectivity the interconnectivity of this dungeon
   */
  void generateDungeonGraph(List<int[]> allPath, int interconnectivity);

  /**
   * Return all the cells in this dungeon.
   *
   * @return all the cells
   */
  Cells[][] getCellMap();

  /**
   * Return the number of all the paths.
   *
   * @return the number of all the paths
   */
  int getAllPathSize();

  /**
   * Add the given percentage of arrows to this dungeon.
   *
   * @param percentage the percentage of all room who has arrows
   */
  void addArrow(int percentage);

  /**
   * Return the list of all arrow's location in this dungeon.
   *
   * @return the list of all arrow's location
   */
  List<String> getArrow();
}
