package controller;

import java.io.IOException;

/**
 * Represents a Controller for Dungeon Game: handle user moves, shoots and picks by executing them
 * using the model.
 */
public interface Controller {
  /**
   * Execute a single game of Dungeon Game by taking the inputs as dungeon setups. When the game is
   * over, the playGame method ends.
   */
  void playGame() throws IOException;
}
