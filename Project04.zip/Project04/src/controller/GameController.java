package controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import model.Directions;
import model.Dungeon;
import model.Dungeons;
import model.KruskalDungeon;
import model.Status;
import model.UnwrappedDungeon;
import model.WrappedDungeon;

/**
 * Represents a Controller for Dungeon Game: handle user moves, shoots and picks by executing them
 * using the model.
 */
public class GameController implements Controller {
  private final Appendable out;
  private final Scanner scan;
  private final int rows;
  private final int cols;
  private final int interConnect;
  private final int type;
  private final int perTreasure;
  private final int perArrow;
  private final int monsNum;

  /**
   * Constructor for the controller.
   *
   * @param in      the source to read from
   * @param out     the target to print to
   * @param strings the args input from command line
   */
  public GameController(Readable in, Appendable out, String[] strings) {
    if (in == null || out == null) {
      throw new IllegalArgumentException("Readable and Appendable can't be null");
    }
    rows = Integer.parseInt(strings[0]);
    cols = Integer.parseInt(strings[1]);
    if (rows <= 0 || cols <= 0 || rows * cols < 5) {
      throw new IllegalArgumentException("Bad size of dungeon! Should be larger than 4 cells!");
    }
    interConnect = Integer.parseInt(strings[2]);
    if (interConnect < 0) {
      throw new IllegalArgumentException("Bad interconnectivity! Should be larger than 0");
    }
    type = Integer.parseInt(strings[3]);
    if (type != 1 && type != 2) {
      throw new IllegalArgumentException("Wrong type!");
    }
    int tmp = (rows - 1) * cols + (cols - 1) * rows - rows * cols;
    if (type == 1 && (interConnect > tmp + 1 + rows + cols)) {
      throw new IllegalArgumentException("Bad interconnectivity! Should be lesser!");
    }
    if (type == 2 && (interConnect > tmp + 1)) {
      throw new IllegalArgumentException("Bad interconnectivity! Should be lesser!");
    }
    perTreasure = Integer.parseInt(strings[4]);
    if (perTreasure < 20 || perTreasure > 100) {
      throw new IllegalArgumentException("Bad percentage! Should be great than 20 and" +
              " less than 100.");
    }
    perArrow = Integer.parseInt(strings[5]);
    if (perArrow < 0 || perArrow > 100) {
      throw new IllegalArgumentException("Bad percentage! Should be great than 0 and" +
              " less than 100.");
    }
    monsNum = Integer.parseInt(strings[6]);
    if (monsNum <= 0 || monsNum > rows * cols - 1) {
      throw new IllegalArgumentException("The dungeon should have at least 1 monster.");
    }
    this.out = out;
    scan = new Scanner(in);
  }

  @Override
  public void playGame() throws IOException {
    KruskalDungeon dungeonGraph;
    switch (type) {
      case 1:
        dungeonGraph = new WrappedDungeon(rows, cols, interConnect);
        break;
      case 2:
        dungeonGraph = new UnwrappedDungeon(rows, cols, interConnect);
        break;
      default:
        throw new IllegalArgumentException("Wrong type!");
    }
    dungeonGraph.generate();
    dungeonGraph.addTreasure(perTreasure);
    dungeonGraph.addArrow(perArrow);
    Dungeons dungeonGame = new Dungeon(dungeonGraph.getCellMap());
    dungeonGame.addMonster(monsNum);
    try {
      //            out.append("The item map of this dungeon:").append("\n")
      //                    .append(dungeonGame.toString()).append("\n");
      //          out.append("The cave map of this dungeon:").append("\n")
      //                  .append(dungeonGame.graphBuilder()).append("\n");
      //          out.append("The monster position of this dungeon:")
      //                  .append(dungeonGame.getMonsters()).append("\n");
      //          out.append("The player's start point is: ")
      //                  .append(Arrays.toString(dungeonGame.getStart())).append("\n");
      //          out.append("The player's goal point is: ")
      //                  .append(Arrays.toString(dungeonGame.getEnd())).append("\n");
      out.append("Welcome to the dungeon!").append("\n");
      label:
      while (!dungeonGame.checkWin() && dungeonGame.getPlayerStatus() == Status.ALIVE) {
        out.append("You smell").append(dungeonGame.smellMonster()).append("\n");
        if (dungeonGame.getThisCellDiamond() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGame.getThisCellDiamond()))
                  .append(" diamond here").append("\n");
        }
        if (dungeonGame.getThisCellRuby() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGame.getThisCellRuby()))
                  .append(" ruby here").append("\n");
        }
        if (dungeonGame.getThisCellSap() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGame.getThisCellSap()))
                  .append(" sapphire here").append("\n");
        }
        if (dungeonGame.getThisCellArrow() != 0) {
          out.append("You find ").append(String.valueOf(dungeonGame.getThisCellArrow()))
                  .append(" arrow here").append("\n");
        }
        out.append(dungeonGame.getCellType()).append("\n");
        out.append("Doors lead to the ")
                .append(Arrays.toString(dungeonGame.getPosDirections().toArray()).replace("[", "")
                        .replace("]", "")).append("\n");
        out.append("Move, Pickup, or Shoot (M-P-S)?").append("\n");
        String choice = scan.next().toUpperCase();
        switch (choice) {
          case "Q":
            try {
              out.append("Game quit!").append("\n")
                      .append("You collected ").append(String.valueOf(dungeonGame.getCurrentDia()))
                      .append(" diamond(s)").append("\n")
                      .append("You collected ").append(String.valueOf(dungeonGame.getCurrentRub()))
                      .append(" rubie(s)").append("\n")
                      .append("You collected ").append(String.valueOf(dungeonGame.getCurrentSap()))
                      .append(" sapphire(s)").append("\n");
            } catch (IOException ioe) {
              throw new IllegalStateException("Append failed", ioe);
            }
            break label;
          case "MOVE":
          case "MO":
          case "MOV":
          case "MOVING":
            choice = "M";
            break;
          case "PICK":
          case "PIC":
          case "PI":
          case "PICKING":
            choice = "P";
            break;
          case "SHOOT":
          case "SHOT":
          case "SHO":
          case "SHOOTING":
          case "SHOTING":
            choice = "S";
            break;
          default:
        }
        switch (choice) {
          case "M":
            out.append("Enter the direction:").append("\n");
            String tmpDirection = scan.next().toLowerCase().trim();
            try {
              dungeonGame.move(tmpDirection);
            } catch (IllegalStateException illegalStateException) {
              out.append("Invalid direction! Try move again!").append("\n");
            } catch (IllegalArgumentException illegalArgumentException) {
              out.append("Cannot move to this position! Try move again!").append("\n");
            }
            break;
          case "P":
            dungeonGame.pickTreasure();
            dungeonGame.pickArrow();
            break;
          case "S":
            out.append("Direction and distance?").append("\n");
            String tmpDirectionShoot = scan.next().toLowerCase().trim();
            Directions d;
            try {
              switch (tmpDirectionShoot) {
                case "north":
                  d = Directions.NORTH;
                  break;
                case "south":
                  d = Directions.SOUTH;
                  break;
                case "west":
                  d = Directions.WEST;
                  break;
                case "east":
                  d = Directions.EAST;
                  break;
                default:
                  throw new IllegalArgumentException("Invalid direction!");
              }
            } catch (IllegalArgumentException illegalArgumentException) {
              out.append("Invalid direction! Try shoot again!").append("\n");
              break;
            }
            int dis = Integer.parseInt(scan.next());
            try {
              out.append(dungeonGame.shootArrow(d, dis)).append("\n");
              break;
            } catch (IllegalArgumentException illegalArgumentException) {
              out.append("Too far! Shoot between 1 - 5").append("\n");
              break;
            }
          default:
            try {
              out.append("Invalid operation, try again").append("\n");
            } catch (IOException e) {
              throw new IllegalStateException("Append failed", e);
            }
            break;
        }
      }
      if (dungeonGame.getPlayerStatus().equals(Status.DEAD)) {
        try {
          out.append("Chomp, chomp, chomp, you are eaten by an Otyugh!").append("\n");
        } catch (IOException e) {
          throw new IllegalStateException("Append failed", e);
        }
      } else if (dungeonGame.checkWin()) {
        try {
          out.append("Whoa, Whoa, Whoa, you reached the goal point!").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGame.getCurrentDia()))
                  .append(" diamond(s)").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGame.getCurrentRub()))
                  .append(" rubie(s)").append("\n")
                  .append("You collected ").append(String.valueOf(dungeonGame.getCurrentSap()))
                  .append(" sapphire(s)").append("\n");
        } catch (IOException e) {
          throw new IllegalStateException("Append failed", e);
        }
      }
    } catch (IOException e) {
      throw new IllegalStateException("Append failed", e);
    } catch (NumberFormatException e) {
      try {
        out.append("Invalid option!").append("\n");
      } catch (IOException e1) {
        throw new IllegalStateException("Append failed", e1);
      }
    }
  }
}