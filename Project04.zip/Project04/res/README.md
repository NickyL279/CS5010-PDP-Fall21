# CS5010-Project4: Text-Based Adventure Game

Create a dungeon, a network of tunnels and caves that are interconnected so that player can explore
the entire world by traveling from cave to cave through the tunnels that connect them. This dungeon
contains treasures and monsters. In the game, you could either win by killing monster and reaching
the end or lose by eaten by the monsters.

## Overview:

Create a dungeon, a network of tunnels and caves that are interconnected so that player can explore
the entire world by traveling from cave to cave through the tunnels that connect them. This dungeon
contains treasures and monsters. In the game, you could either win by killing monster and reaching
the end or lose by eaten by the monsters.

## Features:

- The dungeon is represented on a 2-D grid.
- There is a path from every cave in the dungeon to every other cave in the dungeon.
- Each dungeon is constructed with a degree of interconnectivity. We define an interconnectivity = 0
  when there is exactly one path from every cave in the dungeon to every other cave in the dungeon.
  Increasing the degree of interconnectivity increases the number of paths between caves.
- Not all dungeons "wrap" from one side to the other (as defined above). There are wrapped and
  non-wrapped dungeons. Both wrapping and non-wrapping dungeons to be created with different degrees
  of interconnectivity.
- One cave is randomly selected as the start and one cave is randomly selected to be the end. The
  path between the start and the end locations should be at least of length 5.
- Treasure to be added to a specified percentage of caves. For example, the client should be able to
  ask the model to add treasure to 20% of the caves and the model should add a random treasure to at
  least 20% of the caves in the dungeon. A cave can have more than one treasure. A player to pick up
  treasure that is located in their same location.
- Arrow to be added to a specified percentage of caves. For example, the client should be able to
  ask the model to add arrow to 20% of the caves and the model should add arrow to at least 20% of
  the caves in the dungeon. A player to pick up arrow that is located in their same location.
- Provided a description of the player that, at a minimum, includes a description of what treasure
  the player has collected. Provided a description of the player's location that at the minimum
  includes a description of treasure in the room and the possible moves (north, east, south, west)
  that the player can make from their current location.
- A player to enter the dungeon at the start and move from their current location.
- There are monsters in the dungeon, the number of monsters will be defined as your input, the first
  monster will always be at the end of the dungeon.
- You will be able to collect arrows in the dungeon.
- You can shoot arrows to kill or injure a monster. Where to shoot the arrow will be determined by
  your inputs.

## How to:

The program will follow the steps of the above function and ask the user to enter multiple
instructions to move around the dungeon.

To run this program, please run the driver file and put in option following the instruction.

## How to Use the Program:

This program is interactive, there are two ways to run the program.

First would be run it in the IDE, you will need to uncomment the lines in the Driver say that use
IDE to run the program.

Second would be run it using the Jar to run the program, you will need to type in the dungeon
attributes in the command line when you run the jar. The usage: java -jar Project04-args.jar --rows
--columns --interconnectivity --dungeon type --treasure percentage --arrow percentage --monster
numbers.

## Description of Examples:

This program navigates a player move around a dungeon. Please refer to the features section for a
step-by-step guide on how the program works.

Run 1 -- run1-win.txt:

1. initialize the dungeon.
2. move player around and kill the monster.
3. move to the end point.

Run 2 -- run2-pick&win.txt:

1. initialize the dungeon.
2. move player around, pick up treasure/arrow and kill the monster.
3. move to the end point.

Run 3 -- run3-eaten.txt:

1. initialize the dungeon.
2. move player around and pick up treasure/arrow.
3. move to the end point and eaten by the monster.

Run 4 -- run4-everyCave.txt:

1. initialize the dungeon.
2. move player to all cells and kill the monster.
3. move to the end point.

Run 5 -- run5-eatenByInjured.txt:

1. initialize the dungeon.
2. move player around and pick up treasure/arrow, then injure the monster.
3. move to the end point and eaten by the monster.

Run 6 -- run6-EscapeFromInjured.txt:

1. initialize the dungeon.
2. move player around and pick up treasure/arrow, then injure the monster.
3. move to the end point and escape from the monster.

## Design/Model Changes:

I only made one change in the original design, I didn't know how to use the args in the first place.
After talking to the TA, I pass the args into the controller's constructor to gather the info of the
dungeon.

## Assumptions:

I assume that the player starts at a certain point which is more than 5 cells away from the end
point.

I assume that there are two types of dungeons.

I assume that after the monster was killed, there will be no more smell in the dungeon.

## Limitations:

This program only support three types of treasures, four directions and one gadget. And the program
requires user to navigate in the dungeon.

## Citations:

CSDN, https://www.csdn.net/. Stack Overflow, https://stackoverflow.com/.
Geeksforgeeks, https://www.geeksforgeeks.org/. Google, https://www.google.com/.