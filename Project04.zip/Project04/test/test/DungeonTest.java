package test;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;

import model.Directions;
import model.Dungeon;
import model.Dungeons;
import model.KruskalDungeon;
import model.UnwrappedDungeon;
import model.WrappedDungeon;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Class that tests the dungeon.
 */
public class DungeonTest {
  Dungeons d1;
  KruskalDungeon kd1;
  Dungeons d2;
  KruskalDungeon kd2;

  @Before
  public void setUp() {
    kd1 = new WrappedDungeon(4, 6, 12);
    kd1.generate();
    d1 = new Dungeon(kd1.getCellMap());
    kd2 = new UnwrappedDungeon(6, 8, 16);
    kd2.generate();
    d2 = new Dungeon(kd2.getCellMap());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidCreate() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 6, 12);
    KruskalDungeon kd4 = new WrappedDungeon(4, 6, 12);
    Dungeons d1 = new Dungeon(null);
    Dungeons d2 = new Dungeon(null);
  }

  @Test
  public void testGetStart() {
    assertEquals(6, Arrays.toString(d1.getStart()).length());
    assertEquals(6, Arrays.toString(d2.getStart()).length());
    assertEquals("[2, 4]", Arrays.toString(d1.getStart()));
    assertEquals("[1, 3]", Arrays.toString(d2.getStart()));
  }

  @Test
  public void testGetEnd() {
    assertEquals(6, Arrays.toString(d1.getEnd()).length());
    assertEquals(6, Arrays.toString(d2.getEnd()).length());
    assertEquals("[2, 2]", Arrays.toString(d1.getEnd()));
    assertEquals("[3, 4]", Arrays.toString(d2.getEnd()));
  }

  @Test
  public void testGetPlayerLocation() {
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
    assertEquals(6, Arrays.toString(d2.getLoc()).length());
    assertEquals("[2, 4]", Arrays.toString(d1.getLoc()));
    assertEquals("[2, 4]", Arrays.toString(d1.getStart()));
    assertEquals("[1, 3]", Arrays.toString(d2.getLoc()));
  }

  @Test
  public void testGetTreasure() {
    assertEquals(0, d1.getCurrentDia());
    assertEquals(0, d2.getCurrentDia());
    assertEquals(0, d1.getCurrentRub());
    assertEquals(0, d2.getCurrentRub());
    assertEquals(0, d1.getCurrentSap());
    assertEquals(0, d2.getCurrentSap());
  }

  @Test
  public void getPossibleMove() {
    boolean flagOne = d1.getPosDirections().size() > 0;
    assertTrue(flagOne);
    boolean flagTwo = d2.getPosDirections().size() > 0;
    assertTrue(flagTwo);
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidMove() {
    d1.move("out");
    d2.move("in");
  }

  @Test
  public void testMove() {
    assertEquals("[2, 4]", Arrays.toString(d1.getLoc()));
    d1.move("east");
    assertEquals("[2, 5]", Arrays.toString(d1.getLoc()));
  }

  @Test (expected = IllegalArgumentException.class)
  public void testMove1() {
    d1.move("south");
    assertEquals(6, Arrays.toString(d1.getLoc()).length());
  }

  @Test(expected = AssertionError.class)
  public void testGetTreasure1() {
    kd1.addTreasure(60);
    d1.pickTreasure();
    kd2.addTreasure(60);
    d2.pickTreasure();
    assertEquals(1, d1.getCurrentDia());
    assertEquals(1, d2.getCurrentDia());
    assertEquals(1, d1.getCurrentRub());
    assertEquals(1, d2.getCurrentRub());
    assertEquals(1, d1.getCurrentSap());
    assertEquals(1, d2.getCurrentSap());
  }

  @Test
  public void moveFromStartToEnd() {
    KruskalDungeon kd3 = new WrappedDungeon(4, 4, 17);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    assertTrue(d3.checkWin());
  }

  @Test
  public void moveFromStartToEnd1() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    //System.out.println(d3.graphBuilder());
    //System.out.println(Arrays.toString(d3.getStart()));
    //System.out.println(Arrays.toString(d3.getEnd()));
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    assertTrue(d3.checkWin());
  }

  @Test
  public void moveToAllCells() {
    KruskalDungeon kd3 = new WrappedDungeon(4, 4, 17);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    System.out.println(d3.graphBuilder());
    System.out.println(Arrays.toString(d3.getStart()));
    System.out.println(Arrays.toString(d3.getEnd()));
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    d3.move("north");
    d3.move("west");
    d3.move("west");
    d3.move("west");
    d3.move("south");
    d3.move("east");
    d3.move("east");
    assertTrue(d3.checkWin());
  }

  @Test
  public void moveToAllCells1() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    //System.out.println(d3.graphBuilder());
    //System.out.println(Arrays.toString(d3.getStart()));
    //System.out.println(Arrays.toString(d3.getEnd()));
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    d3.move("north");
    d3.move("west");
    d3.move("west");
    d3.move("west");
    d3.move("south");
    d3.move("east");
    d3.move("east");
    assertTrue(d3.checkWin());
  }

  @Test
  public void testGetCellType() {
    assertEquals("You are in a cave.", d1.getCellType());
    assertEquals("You are in a cave.", d2.getCellType());
    d1.move("east");
    d1.move("south");
    d1.move("east");
    d1.move("south");
    d1.move("south");
    d1.move("west");
    assertEquals("You are in a tunnel.", d1.getCellType());
  }

  @Test
  public void testGetMonster() {
    d1.addMonster(2);
    d2.addMonster(2);
    assertEquals("[2, 2] [1, 2] ", d1.getMonsters());
    assertEquals("[3, 4] [4, 2] ", d2.getMonsters());
  }

  @Test
  public void testGetCurrentArrow() {
    assertEquals(3, d1.getCurrentArrow());
    assertEquals(3, d2.getCurrentArrow());
  }

  @Test
  public void testGetPlayerStatus() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    d3.addMonster(1);
    assertEquals("ALIVE", d3.getPlayerStatus().toString());
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    d3.move("north");
    d3.move("west");
    d3.move("west");
    d3.move("west");
    d3.move("south");
    d3.move("east");
    d3.move("east");
    assertEquals("DEAD", d3.getPlayerStatus().toString());
  }

  @Test
  public void testSmellMonster() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    d3.addMonster(1);
    d3.move("south");
    assertEquals(" nothing here ", d3.smellMonster());
    d3.move("east");
    d3.move("north");
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    assertEquals(" a more pungent smell ", d3.smellMonster());
    d3.move("north");
    d3.move("west");
    d3.move("west");
    assertEquals(" a less pungent smell ", d3.smellMonster());
    d3.move("west");
    d3.move("south");
    assertEquals(" a less pungent smell ", d3.smellMonster());
    d3.move("east");
    d3.move("east");
  }

  @Test
  public void testShootArrow() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    d3.addMonster(1);
    assertEquals("ALIVE", d3.getPlayerStatus().toString());
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("east");
    d3.move("south");
    d3.move("east");
    d3.move("north");
    d3.move("north");
    d3.move("north");
    d3.move("west");
    d3.move("west");
    d3.move("west");
    d3.move("south");
    d3.move("east");
    assertEquals("you injured a monster!", d3.shootArrow(Directions.EAST, 1));
    assertEquals("you killed a monster!", d3.shootArrow(Directions.EAST, 1));
    d3.move("east");
    assertEquals("ALIVE", d3.getPlayerStatus().toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidShootArrow() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    d3.addMonster(1);
    d3.shootArrow(null, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidShootArrow2() {
    KruskalDungeon kd3 = new UnwrappedDungeon(4, 4, 9);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    d3.addMonster(1);
    d3.shootArrow(Directions.EAST, 61);
  }

  @Test
  public void testGetItemNumber() {
    assertEquals(3, d1.getCurrentArrow());
    assertEquals(3, d2.getCurrentArrow());
    assertEquals(0, d1.getCurrentDia());
    assertEquals(0, d2.getCurrentDia());
    assertEquals(0, d1.getCurrentRub());
    assertEquals(0, d2.getCurrentRub());
    assertEquals(0, d1.getCurrentSap());
    assertEquals(0, d2.getCurrentSap());
  }

  @Test
  public void testGetItemNumber2() {
    assertEquals(0, d1.getThisCellArrow());
    assertEquals(0, d2.getThisCellArrow());
    assertEquals(0, d1.getThisCellDiamond());
    assertEquals(0, d2.getThisCellDiamond());
    assertEquals(0, d1.getThisCellRuby());
    assertEquals(0, d2.getThisCellRuby());
    assertEquals(0, d1.getThisCellSap());
    assertEquals(0, d2.getThisCellSap());
  }

  @Test
  public void testStartToEndLength() {
    KruskalDungeon kd3 = new UnwrappedDungeon(6, 8, 12);
    kd3.generate();
    Dungeons d3 = new Dungeon(kd3.getCellMap());
    assertEquals(7, Math.abs(d3.getStart()[0] - d3.getEnd()[0]) +
            Math.abs(d3.getStart()[1] - d3.getEnd()[1]));
  }

  @Test
  public void testMonsterEndLoc() {
    d1.addMonster(1);
    assertEquals(Arrays.toString(d1.getEnd()) + " ", d1.getMonsters());
  }
}
