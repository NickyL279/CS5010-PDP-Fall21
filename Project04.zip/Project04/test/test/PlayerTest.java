package test;

import org.junit.Before;
import org.junit.Test;

import model.Cell;
import model.Cells;
import model.Dungeon;
import model.Dungeons;
import model.Player;
import model.Treasures;
import model.KruskalDungeon;
import model.UnwrappedDungeon;
import model.WrappedDungeon;

import static org.junit.Assert.assertEquals;

/**
 * Class that tests the player.
 */
public class PlayerTest {
  Player player;
  Dungeons d1;
  KruskalDungeon kd1;
  Dungeons d2;
  KruskalDungeon kd2;

  @Before
  public void setUp() {
    player = new Player();
    kd1 = new WrappedDungeon(4, 6, 12);
    kd1.generate();
    d1 = new Dungeon(kd1.getCellMap());
    kd2 = new UnwrappedDungeon(6, 8, 16);
    kd2.generate();
    d2 = new Dungeon(kd2.getCellMap());
  }

  @Test
  public void testGetDiamond() {
    assertEquals(0, player.getDiamondNum());
    player.addTreasure(Treasures.DIAMONDS);
    assertEquals(1, player.getDiamondNum());
  }

  @Test
  public void testGetRub() {
    assertEquals(0, player.getRubiesNum());
    player.addTreasure(Treasures.RUBIES);
    assertEquals(1, player.getRubiesNum());
  }

  @Test
  public void testGetSap() {
    assertEquals(0, player.getSapphiresNum());
    player.addTreasure(Treasures.SAPPHIRES);
    assertEquals(1, player.getSapphiresNum());
  }

  @Test
  public void testPickTreasure() {
    Cells cells = new Cell(new int[]{1, 1});
    cells.setTreasure();
    player.pickTreasure(cells);
    assertEquals(0, player.getDiamondNum());
    assertEquals(1, player.getRubiesNum());
    assertEquals(0, player.getSapphiresNum());
  }

  @Test (expected = IllegalArgumentException.class)
  public void testPickTreasure1() {
    kd1.addTreasure(20);
    player.pickTreasure(kd1.getCellMap()[3][5]);
  }

  @Test
  public void testPickArrow() {
    Cells cells = new Cell(new int[]{1, 1});
    cells.setArrowNum();
    player.pickArrow(cells);
    assertEquals(4, player.getArrowNum());
  }

  @Test
  public void testPickArrow1() {
    Cells cells = new Cell(new int[]{1, 1});
    player.pickArrow(cells);
    assertEquals(3, player.getArrowNum());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPickArrow2() {
    player.pickArrow(null);
  }

  @Test
  public void testLoseArrow() {
    player.loseArrow();
    assertEquals(2, player.getArrowNum());
  }
}
